<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Branches_model extends CI_Model
{


     //public $table = 'branches_mgmt';
    public $id = 'id';
    public $mapid = 'branch_id';
    public $orders = 'DESC';
    var $table = 'branches_mgmt';
    var $maptable = 'branches_classes_mapping_mgmt';
    var $timetable = 'branches_timings_mgmt';
    var $column_order = array(null, 'name','phone','address','city','status'); //set column field database for datatable orderable
    var $column_search = array('name','phone','address','city','status'); //set column field database for datatable searchable 
    var $order = array('id' => 'asc'); // default order 
 
    function __construct()
    {
        parent::__construct();
         $this->load->database();
    }

    // get all
    function get_all()
    {

        $this->db->order_by($this->id, $this->orders);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('id', $q);

		$this->db->or_like('name', $q);
		$this->db->or_like('photo', $q);
		$this->db->or_like('address', $q);
		$this->db->or_like('city', $q);
		$this->db->or_like('pincode', $q);
		$this->db->or_like('state', $q);
		$this->db->or_like('country', $q);
		$this->db->or_like('phone', $q);
		$this->db->or_like('fax', $q);
		$this->db->or_like('email', $q);
		$this->db->or_like('website', $q);
		$this->db->or_like('status', $q);
		$this->db->from($this->table);

        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {

        $this->db->order_by($this->id, $this->orders);
        $this->db->like('id', $q);
		$this->db->or_like('name', $q);
		$this->db->or_like('photo', $q);
		$this->db->or_like('address', $q);
		$this->db->or_like('city', $q);
		$this->db->or_like('pincode', $q);
		$this->db->or_like('state', $q);
		$this->db->or_like('country', $q);
		$this->db->or_like('phone', $q);
		$this->db->or_like('fax', $q);
		$this->db->or_like('email', $q);
		$this->db->or_like('website', $q);
		$this->db->or_like('status', $q);
		$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }
	private function _get_datatables_query()
    {
         
        $this->db->from($this->table);
        $i = 0;
        foreach ($this->column_search as $item) // loop column 
        {
            if(isset($_POST['search']['value'])) // if datatable send POST for search
            {
                 
                if($i===0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                }
                else
                {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
 
                if(count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
         
        if(isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } 
        else if(isset($this->order))
        {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
 
    function get_datatables()
    {
        $this->_get_datatables_query();
        if(isset($_POST['length']) != -1){
        $this->db->limit($_POST['length'], $_POST['start']);}
        $query = $this->db->get();
        
        return $query->result();
    }
 
    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }
 
    public function count_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }
	// insert data
    function insertclassMap($data)
    {
        $this->db->insert($this->maptable, $data);
    }
    // update data
    function updateclassMap($id,$data)
    {
	
        $this->db->where($this->mapid, $id);
        $result=$this->db->get($this->maptable);
		
		if ($result->num_rows() > 0) {
			$this->db->where($this->mapid, $id);
			$this->db->update($this->maptable, $data);
		}else{
			$data['branch_id']=$id;
			 $this->db->insert($this->maptable, $data);
		}
    }
    // get data by id
    function get_by_classid($id)
    {
        $this->db->where($this->mapid, $id);
        return $this->db->get($this->maptable)->row();
    }
     // get data by id
    function get_by_time($id)
    {
        $this->db->where('id', $id);
		$result=$this->db->get($this->timetable);
		
		if ($result->num_rows() > 0) {
			 return $result->row();
			
		} else {
			return FALSE;
		}
    }
     // get data by id
    function get_alltime($id)
    {
        $this->db->where($this->mapid, $id);
		$result=$this->db->get($this->timetable);
		return $result->result();
    }
    // insert data
    function insertclassTime($branchid,$data)
    {
		$mapeddata = array_map(null, $data['weekday'], $data['from_time'], $data['to_time'], $data['type']);
		$input[]='';
		foreach($mapeddata as $key => $input)
		{  
				$input=array(
					'branch_id' => $branchid,
						'weekday' => $input['0'],
						'from_time' => $input['1'],
						'to_time' => $input['2'],
						'type' => $input['3']
				);
			}
        $this->db->insert($this->timetable, $input);
        $this->db->insert_id();
    }
    // update data
    function updateclassTime($branchid,$data)
    {
		
		$mapeddata = array_map(null, $data['weekday'], $data['from_time'], $data['to_time'], $data['type']);
		if(!empty($data['id'])){
			$mapedid = array_map(null, $data['id']);
		}
		$i=0;
		$input[]='';
		foreach($mapeddata as $key => $input)
		{  
				$input=array(
					'branch_id' => $branchid,
						'weekday' => $input['0'],
						'from_time' => $input['1'],
						'to_time' => $input['2'],
						'type' => $input['3']
				);
			if(!empty($mapedid[$i])){
				$id=$mapedid[$i];
			$this->db->where($this->id,$id);
			if ($this->db->get($this->timetable)->num_rows() > 0) {
				$this->db->where($this->id,$id);
				$this->db->update($this->timetable,$input);
				unset($input);
			}} 
			else {
				$this->db->insert($this->timetable, $input);
				unset($input);
			}
			$i++;
		}
			
    }
    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

}

/* End of file Branches_model.php */
/* Location: ./application/models/Branches_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-18 06:49:30 */
/* http://harviacode.com */

