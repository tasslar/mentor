<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Instructors_model extends CI_Model
{

    public $table = 'users_mgmt';
    public $id = 'id';
    public $orderDefault = 'DESC';

    public $column_order = array(null, 'username','primary_email','firstname','last_name','phone','status'); //set column field database for datatable orderable
    public $column_search = array('username','firstname','last_name','address','phone','primary_email'); //set column field database for datatable searchable 
    //public $order = 'asc'; // default order 
    var $order = array('id' => 'DESC'); // default order 

    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


    //data tables start here    
    private function _get_datatables_query()
    {
         
        $this->db->from($this->table);
        $i = 0;
        foreach ($this->column_search as $item) // loop column 
        {
            if(isset($_POST['search']['value'])) // if datatable send POST for search
            {
                 
                if($i===0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                }
                else
                {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
 
                if(count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
         
        if(isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } 
        else if(isset($this->order))
        {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
 
    function get_datatables()
    {
        $this->_get_datatables_query();
        if(isset($_POST['length']) && $_POST['length'] != -1){
        $this->db->limit($_POST['length'], $_POST['start']);}
        $this->db->where('role_id', 2);
        $query = $this->db->get();
        
        return $query->result();
    }
 
    function count_filtered()
    {
        $this->_get_datatables_query();
        $this->db->where('role_id', 2);
        $query = $this->db->get();
        return $query->num_rows();
    }
 
    public function count_all()
    {
        $this->db->from($this->table);
        $this->db->where('role_id', 2);
        return $this->db->count_all_results();
    }
    //data tablse code end here

    // get all
    function get_instrutor_classes_all($id)
    {
        $this->db->select('class_mgmt.id');
        $this->db->from('class_mgmt');
        $this->db->join('instrutor_classes_mapping_mgmt', 'class_mgmt.id = instrutor_classes_mapping_mgmt.class_id', 'left');      
        $this->db->where('instrutor_classes_mapping_mgmt.instrutor_id', $id);   
        $this->db->group_by('instrutor_classes_mapping_mgmt.class_id'); 
        $query = $this->db->get();
        return $query->result();
    }

    // get instrutor vehicle all
    function get_instrutor_vehicle_all($id)
    {
        $this->db->select('vehicle_mgmt.id');
        $this->db->from('vehicle_mgmt');
        $this->db->join('instrutor_vehicle_mapping_mgmt', 'vehicle_mgmt.id = instrutor_vehicle_mapping_mgmt.vehicle_id', 'left');      
        $this->db->where('instrutor_vehicle_mapping_mgmt.instrutor_id', $id);   
        $this->db->group_by('instrutor_vehicle_mapping_mgmt.vehicle_id'); 
        $query = $this->db->get();
        return $query->result();
    }

    // get instrutor branch all
    function get_instrutor_branch_all($id)
    {
        $this->db->select('branches_mgmt.id');
        $this->db->from('branches_mgmt');
        $this->db->join('instrutor_branch_mapping_mgmt', 'branches_mgmt.id = instrutor_branch_mapping_mgmt.branch_id', 'left');      
        $this->db->where('instrutor_branch_mapping_mgmt.instrutor_id', $id);   
        $this->db->group_by('instrutor_branch_mapping_mgmt.branch_id'); 
        $query = $this->db->get();
        return $query->result();
    }

    // get all
    function get_all()
    {
        $this->db->where('role_id', 2);
        $this->db->order_by($this->id, $this->orderDefault);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where('role_id', 2);
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        /*$this->db->like('id', $q);
    	$this->db->or_like('username', $q);
    	$this->db->or_like('email', $q);
    	$this->db->or_like('firstname', $q);
    	$this->db->or_like('last_name', $q);
    	$this->db->or_like('nickname', $q);
    	$this->db->or_like('photo', $q);
    	$this->db->or_like('address', $q);
    	$this->db->or_like('city', $q);
    	$this->db->or_like('postalcode', $q);
    	$this->db->or_like('state', $q);
    	$this->db->or_like('country_id', $q);
    	$this->db->or_like('phone', $q);
    	$this->db->or_like('mobile', $q);
    	$this->db->or_like('status', $q);  */      
        $this->db->where('role_id', 2);
    	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->orderDefault);
        /*$this->db->like('id', $q);
    	$this->db->or_like('username', $q);
    	$this->db->or_like('email', $q);
    	$this->db->or_like('firstname', $q);
    	$this->db->or_like('last_name', $q);
    	$this->db->or_like('nickname', $q);
    	$this->db->or_like('photo', $q);
    	$this->db->or_like('address', $q);
    	$this->db->or_like('city', $q);
    	$this->db->or_like('postalcode', $q);
    	$this->db->or_like('state', $q);
    	$this->db->or_like('country_id', $q);
    	$this->db->or_like('phone', $q);
    	$this->db->or_like('mobile', $q);
    	$this->db->or_like('status', $q);*/
        $this->db->where('role_id', 2);
	   $this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

}

/* End of file Users_model.php */
/* Location: ./application/models/Users_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-14 06:47:28 */
/* http://harviacode.com */