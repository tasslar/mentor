<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Student_model extends CI_Model
{

    public $table = 'student_mgmt';
    public $id = 'id';
    public $order = 'DESC';
    var $table1 = 'student_mgmt';
      var $column_order = array(null, 'servicetype_name'); //set column field database for datatable orderable
    var $column_search = array('servicetype_name'); //set column field database for datatable searchable 
    var $order1 = array('servicetype_name' => 'asc'); // default order 


    public $student_column_order = array(null, 'username','email','first_name','surname','phone','status'); //set column field database for datatable orderable
    public $student_column_search = array('username','first_name','surname','phone','email'); //set column field database for datatable searchable 
    //public $order = 'asc'; // default order 
    var $student_order = array('id' => 'DESC'); // default order 

    function __construct()
    {
        parent::__construct();
    }



    //data tables start here - for student
    
    private function _get_student_datatables_query()
    {
         
        $this->db->from($this->table);
        $i = 0;
        foreach ($this->student_column_search as $item) // loop column 
        {
            if(isset($_POST['search']['value'])) // if datatable send POST for search
            {
                 
                if($i===0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                }
                else
                {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
 
                if(count($this->student_column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
         
        if(isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->student_column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } 
        else if(isset($this->student_order))
        {
            $order = $this->student_order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
 
    function get_student_datatables()
    {
        $this->_get_student_datatables_query();
        if(isset($_POST['length']) && $_POST['length'] != -1){
        $this->db->limit($_POST['length'], $_POST['start']);}
        $query = $this->db->get();
        
        return $query->result();
    }
 
    function count_student_filtered()
    {
        $this->_get_student_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }
 
    public function count_student_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    //data tablse code end here - for student

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('id', $q);
		$this->db->or_like('username', $q);
		$this->db->or_like('password', $q);
		$this->db->or_like('email', $q);
		$this->db->or_like('instrutor_id', $q);
		$this->db->or_like('branch_id', $q);
		$this->db->or_like('address', $q);
		$this->db->or_like('state', $q);
		$this->db->or_like('country_id', $q);
		$this->db->or_like('photo', $q);
		$this->db->or_like('first_name', $q);
		$this->db->or_like('surname', $q);
		$this->db->or_like('dob', $q);
		$this->db->or_like('placeofbirth', $q);
		$this->db->or_like('phone', $q);
		$this->db->or_like('mobile', $q);
		$this->db->or_like('language', $q);
		$this->db->or_like('note', $q);
		$this->db->or_like('nationality', $q);
		$this->db->or_like('consentezb', $q);
		$this->db->or_like('firstaidcourse', $q);
		$this->db->or_like('physical', $q);
		$this->db->or_like('visiontest', $q);
		$this->db->or_like('visualaid', $q);
		$this->db->or_like('guardian_name', $q);
		$this->db->or_like('g_surname', $q);
		$this->db->or_like('g_dob', $q);
		$this->db->or_like('g_address', $q);
		$this->db->or_like('g_city', $q);
		$this->db->or_like('g_postalcode', $q);
		$this->db->or_like('g_state', $q);
		$this->db->or_like('g_country_id', $q);
		$this->db->or_like('g_email', $q);
		$this->db->or_like('g_phone', $q);
		$this->db->or_like('traning_allocatoion_type', $q);
		$this->db->or_like('payment_debit', $q);
		$this->db->or_like('payment_dunning', $q);
		$this->db->or_like('payment_dunning_level', $q);
		$this->db->or_like('payment_bankcode', $q);
		$this->db->or_like('payment_acc_number', $q);
		$this->db->or_like('payment_iban', $q);
		$this->db->or_like('payment_swiftcode', $q);
		$this->db->or_like('payment_owner', $q);
		$this->db->or_like('opos', $q);
		$this->db->or_like('status', $q);
		$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('id', $q);
		$this->db->or_like('username', $q);
		$this->db->or_like('password', $q);
		$this->db->or_like('email', $q);
		$this->db->or_like('instrutor_id', $q);
		$this->db->or_like('branch_id', $q);
		$this->db->or_like('address', $q);
		$this->db->or_like('state', $q);
		$this->db->or_like('country_id', $q);
		$this->db->or_like('photo', $q);
		$this->db->or_like('first_name', $q);
		$this->db->or_like('surname', $q);
		$this->db->or_like('dob', $q);
		$this->db->or_like('placeofbirth', $q);
		$this->db->or_like('phone', $q);
		$this->db->or_like('mobile', $q);
		$this->db->or_like('language', $q);
		$this->db->or_like('note', $q);
		$this->db->or_like('nationality', $q);
		$this->db->or_like('consentezb', $q);
		$this->db->or_like('firstaidcourse', $q);
		$this->db->or_like('physical', $q);
		$this->db->or_like('visiontest', $q);
		$this->db->or_like('visualaid', $q);
		$this->db->or_like('guardian_name', $q);
		$this->db->or_like('g_surname', $q);
		$this->db->or_like('g_dob', $q);
		$this->db->or_like('g_address', $q);
		$this->db->or_like('g_city', $q);
		$this->db->or_like('g_postalcode', $q);
		$this->db->or_like('g_state', $q);
		$this->db->or_like('g_country_id', $q);
		$this->db->or_like('g_email', $q);
		$this->db->or_like('g_phone', $q);
		$this->db->or_like('traning_allocatoion_type', $q);
		$this->db->or_like('payment_debit', $q);
		$this->db->or_like('payment_dunning', $q);
		$this->db->or_like('payment_dunning_level', $q);
		$this->db->or_like('payment_bankcode', $q);
		$this->db->or_like('payment_acc_number', $q);
		$this->db->or_like('payment_iban', $q);
		$this->db->or_like('payment_swiftcode', $q);
		$this->db->or_like('payment_owner', $q);
		$this->db->or_like('opos', $q);
		$this->db->or_like('status', $q);
		$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

	private function _get_datatables_query()
    {
         
        $this->db->from('student_services_mgmt');
		$this->db->join('power_mgmt', 'power_mgmt.id = student_services_mgmt.power_id');
		$this->db->join('vehicle_mgmt', 'vehicle_mgmt.id = student_services_mgmt.vehicle_id');
		$this->db->join('class_mgmt', 'class_mgmt.id = student_services_mgmt.class_id');
		$this->db->join('users_mgmt', 'users_mgmt.id = student_services_mgmt.instrutor_id');
        $i = 0;
        foreach ($this->column_search as $item) // loop column 
        {
            if(isset($_POST['search']['value'])) // if datatable send POST for search
            {
                 
                if($i===0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                }
                else
                {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
 
                if(count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
         
        if(isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } 
        else if(isset($this->order1))
        {
            $order = $this->order1;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
 
    function get_datatables()
    {
        $this->_get_datatables_query();
        if(isset($_POST['length']) != -1){
        $this->db->limit($_POST['length'], $_POST['start']);}
        $query = $this->db->get();
        
        return $query->result();
    }
 
    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }
 
    public function count_all()
    {
         $this->db->from('student_services_mgmt');
		$this->db->join('power_mgmt', 'power_mgmt.id = student_services_mgmt.power_id');
		$this->db->join('vehicle_mgmt', 'vehicle_mgmt.id = student_services_mgmt.vehicle_id');
		$this->db->join('class_mgmt', 'class_mgmt.id = student_services_mgmt.class_id');
		$this->db->join('users_mgmt', 'users_mgmt.id = student_services_mgmt.instrutor_id');
        return $this->db->count_all_results();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }
    
    function Studentservices() {
		$this->db->select('*');
		$this->db->from('student_services_mgmt');
		$this->db->join('power_mgmt', 'power_mgmt.id = student_services_mgmt.power_id');
		$this->db->join('vehicle_mgmt', 'vehicle_mgmt.id = student_services_mgmt.vehicle_id');
		$this->db->join('class_mgmt', 'class_mgmt.id = student_services_mgmt.class_id');
		$this->db->join('users_mgmt', 'users_mgmt.id = student_services_mgmt.instrutor_id');
		$query = $this->db->get();
		return $query->result(); 
		
	}

    // get student class all
    function get_student_classes_all($id)
    {
        $this->db->select('student_mgmt.id');
        $this->db->from('student_mgmt');
        $this->db->join('student_classes_mapping_mgmt', 'student_mgmt.id = student_classes_mapping_mgmt.class_id', 'left');      
        $this->db->where('student_classes_mapping_mgmt.student_id', $id);   
        $this->db->group_by('student_classes_mapping_mgmt.class_id'); 
        $query = $this->db->get();
        return $query->result();
    }

    // get student branch all
    function get_student_branch_all($id)
    {
        $this->db->select('student_mgmt.id');
        $this->db->from('student_mgmt');
        $this->db->join('student_branch_mapping_mgmt', 'student_mgmt.id = student_branch_mapping_mgmt.branch_id', 'left');      
        $this->db->where('student_branch_mapping_mgmt.student_id', $id);   
        $this->db->group_by('student_branch_mapping_mgmt.branch_id'); 
        $query = $this->db->get();
        return $query->result();
    }


    // insert data
    function student_classes_insert_batch($data)
    {
        $this->db->select('*');
        $this->db->from('student_classes_mapping_mgmt');
        $student_id= $data[0]['student_id'];
        $this->db->where('student_id', $student_id);
        $this->db->delete('student_classes_mapping_mgmt');
        $this->db->insert_batch('student_classes_mapping_mgmt', $data);
    }

}

/* End of file Student_model.php */
/* Location: ./application/models/Student_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-20 07:37:49 */
/* http://harviacode.com */
