<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*$config['protocol'] = 'smtp';
$config['smtp_host'] = 'smtp.zoho.com';
$config['smtp_port'] = '465'; // 8025, 587 and 25 can also be used. Use Port 465 for SSL.
$config['smtp_crypto'] = 'ssl';
$config['smtp_user'] = 'demo@inysol.com';
$config['smtp_pass'] = 'senthil7';
$config['charset'] = 'utf-8';
$config['mailtype'] = 'html';
$config['newline'] = "rn";*/
$config = Array (
    'useragent' => 'CodeIgniter',
    'protocol' => 'smtp',
    '_smtp_auth' =>TRUE,
    'smtp_host' => 'ssl://smtp.zoho.com',
    'smtp_port' => 465,                
	'smtp_user' => 'demo@inysol.com',
	'smtp_pass' => 'senthil7',
    'charset' => 'utf-8',
    'mailtype' => 'html',
    'newline' => "\r\n",
    'wordwrap' => TRUE,
    'wrapchars'=>76,
    'validate' => FALSE,
    'priority' => 3,
    'crlf' => "\r\n",
    'newline' => "\r\n",
    'bcc_batch_mode' => TRUE,
    'bcc_batch_size' => '200',
    'newline' => "\r\n"
);