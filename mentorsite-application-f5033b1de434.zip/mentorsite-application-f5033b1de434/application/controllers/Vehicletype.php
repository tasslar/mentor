<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Vehicletype extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Vehicletype_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'vehicletype/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'vehicletype/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'vehicletype/index.html';
            $config['first_url'] = base_url() . 'vehicletype/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Vehicletype_model->total_rows($q);
        $vehicletype = $this->Vehicletype_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'vehicletype_data' => $vehicletype,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
       $data['title'] = 'Mentor-Manage VehicleType';
        $data['main_content'] ='vehicletype/vehicletype_mgmt_list';
        $this->load->view('includes/template', $data);
    }
	public	function ajax_list()
	{
		$list = $this->Vehicletype_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach($list as $vtype) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $vtype->type;
			$row[] = $vtype->designation;
			$row[] = $vtype->status;
			$row[] = anchor(site_url('vehicletype/update/' . $vtype->id) , 'Update');
			$udpateordelete = ($vtype->status == 'Active') ? 'Delete' : 'Active';
			$row[] = anchor(site_url('vehicletype/' . $udpateordelete . '/' . $vtype->id) , $udpateordelete, 'onclick="javasciprt: return confirm(\'Are You Sure ?\')"');
			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Vehicletype_model->count_all() ,
			"recordsFiltered" => $this->Vehicletype_model->count_filtered() ,
			"data" => $data,
		);

		// output to json format

		echo json_encode($output);
	}
    public function read($id) 
    {
        $row = $this->Vehicletype_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'type' => $row->type,
		'designation' => $row->designation,
		'status' => $row->status,
	    );
            $this->load->view('vehicletype/vehicletype_mgmt_read', $data);
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('vehicletype'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('vehicletype/create_action'),
			'id' => set_value('id'),
			'type' => set_value('type'),
			'designation' => set_value('designation'),
		);
        
        $data['title'] = 'Mentor-Create Vehicle Type';
		$data['main_content'] = 'vehicletype/vehicletype_mgmt_form';
		$this->load->view('includes/template', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
				'type' => $this->input->post('type',TRUE),
				'designation' => $this->input->post('designation',TRUE),
				'status' => 'Active',
				);

            $this->Vehicletype_model->insert($data);
            $this->session->set_flashdata('message', '<span class="text-success">Vehicletype Created Successfully</span>');
            redirect(site_url('vehicletype'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Vehicletype_model->get_by_id($id);

        if ($row) {
            $data = array(
					'button' => 'Update',
					'action' => site_url('vehicletype/update_action'),
					'id' => set_value('id', $row->id),
					'type' => set_value('type', $row->type),
					'designation' => set_value('designation', $row->designation),
				);
           
            $data['title'] = 'Mentor-Update Vehicle Type';
			$data['main_content'] = 'vehicletype/vehicletype_mgmt_form';
			$this->load->view('includes/template', $data);
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('vehicletype'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'type' => $this->input->post('type',TRUE),
		'designation' => $this->input->post('designation',TRUE),
		'status' => $this->input->post('status',TRUE),
	    );

            $this->Vehicletype_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', '<span class="text-success">Updated Vehicletype Successfully</span>');
            redirect(site_url('vehicletype'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Vehicletype_model->get_by_id($id);

        if ($row) {
			$data = array(
				'status' => 'Inactive',
				);
            $this->Vehicletype_model->update($id, $data);
            $this->session->set_flashdata('message', '<span class="text-success">Delete Vehicletype Success</span>');
            redirect(site_url('vehicletype'));
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('vehicletype'));
        }
    }
	public function active($id) 
    {
        $row = $this->Vehicletype_model->get_by_id($id);

        if ($row) {
			$data = array(
				'status' => 'Active',
				);
            $this->Vehicletype_model->update($id, $data);
            $this->session->set_flashdata('message', '<span class="text-success">Delete Record Success</span>');
            redirect(site_url('vehicletype'));
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('vehicletype'));
        }
    }
    public function _rules() 
    {
		$this->form_validation->set_rules('type', 'type', 'trim|required');
		$this->form_validation->set_rules('designation', 'designation', 'trim|required');
		$this->form_validation->set_rules('id', 'id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Vehicletype.php */
/* Location: ./application/controllers/Vehicletype.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-18 06:52:49 */
/* http://harviacode.com */
