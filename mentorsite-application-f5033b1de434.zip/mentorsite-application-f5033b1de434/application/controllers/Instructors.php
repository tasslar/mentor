<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Instructors extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Instructors_model');
        $this->load->model('Instrutor_personal_details_model');
        $this->load->model('Instrutor_classes_model');    
        $this->load->model('Instrutor_vehicle_model');    
        $this->load->model('Instrutor_branch_model');  
        $this->load->model('Roles_model');  
        $this->load->model('Classes_model');   
        $this->load->model('Vehicle_model');    
        $this->load->model('Branches_model');  
        $this->load->model('Country_model');       
        $this->load->library('form_validation');
    }

    public function ajax_list()
    {
        $list = $this->Instructors_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $user) {
        	$roles = $this->Roles_model->get_by_id($user->role_id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $user->username;
            $row[] = $user->primary_email;
            $row[] = $user->firstname;
            $row[] = $user->last_name;
            $row[] = $roles->role_name;
            $row[] = $user->phone;
            $row[] = $user->status;

			$rowaction = anchor(site_url('instructors/update/' . $user->id) , 'Update'). ' | ';
			$udpateordelete = ($user->status == 'Active') ? 'Delete' : 'Active';
			$rowaction .= anchor(site_url('instructors/' . $udpateordelete . '/' . $user->id) , $udpateordelete, 'onclick="javasciprt: return confirm(\'Are You Sure ?\')"');
 			$row[] = $rowaction;
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Instructors_model->count_all(),
                        "recordsFiltered" => $this->Instructors_model->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'instructors/index?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'instructors/index?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'instructors/index';
            $config['first_url'] = base_url() . 'instructors/index';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Instructors_model->total_rows($q);
        $users = $this->Instructors_model->get_limit_data($config['per_page'], $start, $q);
        $data['roles'] = $this->Roles_model->get_all();

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'users_data' => $users,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
       // $this->load->view('instructors/users_mgmt_list', $data);
        //load the view
	    $data['title'] = 'Mentor-Manage Instructors';
        $data['main_content'] = 'instructors/instructors_list';
        $this->load->view('includes/template', $data);  
    }

    public function read($id) 
    {
        $row = $this->Instructors_model->get_by_id($id);
        if ($row) {
        	$dob = date("d-m-Y", strtotime($row->dob));
            $data = array(
				'id' => $row->id,
				'username' => $row->username,
				'password' => $row->password,
				'email' => $row->email,
				'dob' => $dob,
				'note' => $row->note,
				'role_id' => $row->role_id,
				'firstname' => $row->firstname,
				'last_name' => $row->last_name,
				'nickname' => $row->nickname,
				'photo' => $row->photo,
				'address' => $row->address,
				'city' => $row->city,
				'postalcode' => $row->postalcode,
				'state' => $row->state,
				'country_id' => $row->country_id,
				'phone' => $row->phone,
				'mobile' => $row->mobile,
				'status' => $row->status,
				'is_email_sent' => $row->is_email_sent,
				'is_email_verified' => $row->is_email_verified,
				'primary_email' => $row->primary_email,
		    );
            $this->load->view('instructors/instructors_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('instructors'));
        }
    }
  
    
    public function update($id) 
    {
    	//Instrutor_personal_details_model
    	$row = $this->Instrutor_personal_details_model->get_by_id($id);
        if (!$row) {
			$data = array(
				'instrutor_id' => $id,
		    );
            $this->Instrutor_personal_details_model->insert($data);
    		$row = $this->Instrutor_personal_details_model->get_by_id($id);
        }
        if($row){
            $data1 = array(
				'insurance' => set_value('insurance', $row->insurance),
				'teaching_unit' => set_value('teaching_unit', $row->teaching_unit),
				'tax_bracket' => set_value('tax_bracket', $row->tax_bracket),
				'family_status' => set_value('family_status', $row->family_status),
				'basic_wage' => set_value('basic_wage', $row->basic_wage),
				'practice' => set_value('practice', $row->practice),
				'highway' => set_value('highway', $row->highway),
				'overland' => set_value('overland', $row->overland),
				'lighting' => set_value('lighting', $row->lighting),
				'maneuvers' => set_value('maneuvers', $row->maneuvers),
				'surcharge' => set_value('surcharge', $row->surcharge),
				'lessons' => set_value('lessons', $row->lessons),
				'instruction' => set_value('instruction', $row->instruction),
				'exams' => set_value('exams', $row->exams),
				'activities' => set_value('activities', $row->activities),
				'bonus_a1' => set_value('bonus_a1', $row->bonus_a1),
				'bonus_a2' => set_value('bonus_a2', $row->bonus_a2),
				'bonus_a3' => set_value('bonus_a3', $row->bonus_a3),
				'entry_date' => set_value('entry_date', $row->entry_date),
				'holidays' => set_value('holidays', $row->holidays),
				'remaining_holiday' => set_value('remaining_holiday', $row->remaining_holiday),
				'other_activities' => set_value('other_activities', $row->other_activities),
				'credit_institution' => set_value('credit_institution', $row->credit_institution),
				'bank_code' => set_value('bank_code', $row->bank_code),
				'account_number' => set_value('account_number', $row->account_number),
				'iban' => set_value('iban', $row->iban),
				'swift_bic' => set_value('swift_bic', $row->swift_bic),
				'account_owner' => set_value('account_owner', $row->account_owner),
		    );
        }


        //Instructors_model
        $row = $this->Instructors_model->get_by_id($id);
        if ($row) {        	
        	$dob = date("d-m-Y", strtotime($row->dob));
            $data = array(
                'button' => 'Update',
                'action' => site_url('instructors/update_action'),
				'id' => set_value('id', $row->id),
				//'username' => set_value('username', $row->username),
				//'password' => set_value('password', $row->password),
				'email' => set_value('email', $row->email),
				'dob' => set_value('dob', $dob),
				'note' => set_value('note', $row->note),
				'role_id' => set_value('role_id', $row->role_id),
				'firstname' => set_value('firstname', $row->firstname),
				'last_name' => set_value('last_name', $row->last_name),
				'nickname' => set_value('nickname', $row->nickname),
				'photo' => set_value('photo', $row->photo),
				'address' => set_value('address', $row->address),
				'city' => set_value('city', $row->city),
				'postalcode' => set_value('postalcode', $row->postalcode),
				'state' => set_value('state', $row->state),
				'country_id' => set_value('country_id', $row->country_id),
				'phone' => set_value('phone', $row->phone),
				'mobile' => set_value('mobile', $row->mobile),
				//'status' => set_value('status', $row->status),
				//'is_email_sent' => set_value('is_email_sent', $row->is_email_sent),
				//'is_email_verified' => set_value('is_email_verified', $row->is_email_verified),
			    'op_address' => set_value('op_address', $row->op_address),
			    'op_city' => set_value('op_city', $row->op_city),
			    'op_postalcode' => set_value('op_postalcode', $row->op_postalcode),
			    'op_state' => set_value('op_state', $row->op_state),
			    'op_country_id' => set_value('op_country_id', $row->op_country_id),
			    'op_phone' => set_value('op_phone', $row->op_phone),
			    'op_mobile' => set_value('op_phone', $row->op_mobile),
			    'op_email' => set_value('op_email', $row->op_email),
				'primary_email' => $this->input->post('primary_email',TRUE),
		    );
		    $data = array_merge($data,$data1);
		    //print_r($data); die;
        	$data['main_content'] = 'instructors/instructors_form';
       		$data['roles'] = $this->Roles_model->get_all();
       		$data['classes'] = $this->Classes_model->get_all();
       		$data['vehicle'] = $this->Vehicle_model->get_all();
       		$data['branch'] = $this->Branches_model->get_all();
       		$data['country'] = $this->Country_model->get_all();

       		$classSelected = $branchSelected = $vehicleSelected = array();

        	//Instrutor_classes_model
        	foreach($this->Instructors_model->get_instrutor_classes_all($id) as $category)
			{
			    $classSelected[] = $category->id;
			}
        	$data['get_instrutor_classes_all'] = $classSelected;
        	//Instrutor_vehicle_model     
        	foreach($this->Instructors_model->get_instrutor_vehicle_all($id) as $category)
			{
			    $vehicleSelected[] = $category->id;
			}
        	$data['get_instrutor_vehicle_all'] = $vehicleSelected;
        	//Instrutor_branch_model     
        	foreach($this->Instructors_model->get_instrutor_branch_all($id) as $category)
			{
			    $branchSelected[] = $category->id;
			}
        	$data['get_instrutor_branch_all'] = $branchSelected;


	   		$data['title'] = 'Mentor-Manage Instructors update';
        	$this->load->view('includes/template', $data);  
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('instructors'));
        }
    }
    
    public function update_action() 
    {
    	//echo "<pre>";
    	//print_r($this->input->post()); 
        $this->_rules();
        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
        	$dob = date("Y-m-d", strtotime($this->input->post('dob',TRUE)));
            $data = array(
				//'username' => $this->input->post('username',TRUE),
				//'password' => $this->input->post('password',TRUE),
				//'primary_email' => $this->input->post('primary_email',TRUE),
				'email' => $this->input->post('email',TRUE),
				//'role_id' => $this->input->post('role_id',TRUE),
				'firstname' => $this->input->post('firstname',TRUE),
				'last_name' => $this->input->post('last_name',TRUE),
				'nickname' => $this->input->post('nickname',TRUE),
				//'photo' => $this->input->post('photo',TRUE),
				'dob' => $dob,
				'note' => $this->input->post('note',TRUE),
				'address' => $this->input->post('address',TRUE),
				'city' => $this->input->post('city',TRUE),
				'postalcode' => $this->input->post('postalcode',TRUE),
				'state' => $this->input->post('state',TRUE),
				'country_id' => $this->input->post('country_id',TRUE),
				'phone' => $this->input->post('phone',TRUE),
				'mobile' => $this->input->post('mobile',TRUE),
				//'status' => $this->input->post('status',TRUE),
				//'is_email_sent' => $this->input->post('is_email_sent',TRUE),
				//'is_email_verified' => $this->input->post('is_email_verified',TRUE),
				'op_address' => $this->input->post('op_address',TRUE),
				'op_city' => $this->input->post('op_city',TRUE),
				'op_postalcode' => $this->input->post('op_postalcode',TRUE),
				'op_state' => $this->input->post('op_state',TRUE),
				'op_country_id' => $this->input->post('op_country_id',TRUE),
				'op_phone' => $this->input->post('op_phone',TRUE),
				'op_mobile' => $this->input->post('op_mobile',TRUE),
				'op_email' => $this->input->post('op_email',TRUE),
		    );

            $this->Instructors_model->update($this->input->post('id', TRUE), $data);

            $IPDdata = array(
				'instrutor_id' => $this->input->post('id', TRUE),
				'insurance' => $this->input->post('insurance',TRUE),
				'teaching_unit' => $this->input->post('teaching_unit',TRUE),
				'family_status' => $this->input->post('family_status',TRUE),
				'tax_bracket' => $this->input->post('tax_bracket',TRUE),
				'basic_wage' => $this->input->post('basic_wage',TRUE),
				'practice' => $this->input->post('practice',TRUE),
				'highway' => $this->input->post('highway',TRUE),
				'overland' => $this->input->post('overland',TRUE),
				'lighting' => $this->input->post('lighting',TRUE),
				'maneuvers' => $this->input->post('maneuvers',TRUE),
				'surcharge' => $this->input->post('surcharge',TRUE),
				'lessons' => $this->input->post('lessons',TRUE),
				'instruction' => $this->input->post('instruction',TRUE),
				'exams' => $this->input->post('exams',TRUE),
				'activities' => $this->input->post('activities',TRUE),
				'bonus_a1' => $this->input->post('bonus_a1',TRUE),
				'bonus_a2' => $this->input->post('bonus_a2',TRUE),
				'bonus_a3' => $this->input->post('bonus_a3',TRUE),
				'entry_date' => $this->input->post('entry_date',TRUE),
				'holidays' => $this->input->post('holidays',TRUE),
				'remaining_holiday' => $this->input->post('remaining_holiday',TRUE),
				'other_activities' => $this->input->post('other_activities',TRUE),
				'credit_institution' => $this->input->post('credit_institution',TRUE),
				'bank_code' => $this->input->post('bank_code',TRUE),
				'account_number' => $this->input->post('account_number',TRUE),
				'iban' => $this->input->post('iban',TRUE),
				'swift_bic' => $this->input->post('swift_bic',TRUE),
				'account_owner' => $this->input->post('account_owner',TRUE),
		    );

            //instrutor_classes_mapping_mgmt - save
            $ICData = array();
            //print_r($this->input->post());
            if($this->input->post('classes_id',true)){
			    foreach ($this->input->post('classes_id',true) as $key => $value) {
			    	$ICData1 = array(
	            				'instrutor_id'=>$this->input->post('id',true),
	            				'class_id'=>$value
	            			);
			    	array_push($ICData, $ICData1);
			    }
			    $this->Instrutor_classes_model->insert_batch($ICData);
			}

		    //instrutor_vehicle_mapping_mgmt - save
            $IVData = array();
            if($this->input->post('vehicle_id',true)){
			    foreach ($this->input->post('vehicle_id',true) as $key => $value) {
			    	$IVData1 = array(
	            				'instrutor_id'=>$this->input->post('id',true),
	            				'vehicle_id'=>$value
	            			);
			    	array_push($IVData, $IVData1);
			    }
			    $this->Instrutor_vehicle_model->insert_batch($IVData);
			}

			//Instrutor_branch_model - save
            $IBData = array();
            if($this->input->post('branch_id',true)){
			    foreach ($this->input->post('branch_id',true) as $key => $value) {
			    	$IBData1 = array(
	            				'instrutor_id'=>$this->input->post('id',true),
	            				'branch_id'=>$value
	            			);
			    	array_push($IBData, $IBData1);
			    }
			    $this->Instrutor_branch_model->insert_batch($IBData);
			}

        	$row = $this->Instrutor_personal_details_model->get_by_id($id);
       		if ($row) {
            	$this->Instrutor_personal_details_model->insert($IPDdata);
            } else {
          	  $this->Instrutor_personal_details_model->update($this->input->post('id', TRUE), $IPDdata);            	
            }

            $this->session->set_flashdata('message', '<span class="text-success">Instructors has been updated Successfully</span>');
            redirect(site_url('instructors'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Instructors_model->get_by_id($id);

        if ($row) {
           // $this->Instructors_model->delete($id);
             $data = array(
				'status' => 'Inactive',
			);
            $this->Instructors_model->update($id, $data);
            $this->session->set_flashdata('message', '<span class="text-success">Instructors has been Deleted Successfully</span>');
            redirect(site_url('instructors'));
        } else {
            $this->session->set_flashdata('message', 'Instructors Not Found');
            redirect(site_url('instructors'));
        }
    }

    public function active($id) 
    {
        $row = $this->Instructors_model->get_by_id($id);

        if ($row) {
            //$this->Users_model->delete($id);

            $data = array(
				'status' => 'Active',
			);
            $this->Instructors_model->update($id, $data);
            $this->session->set_flashdata('message', '<span class="text-success">Instructors has been Activated Successfully</span>');
            redirect(site_url('instructors'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('instructors'));
        }
    }

    public function _rules() 
    {
		//$this->form_validation->set_rules('username', 'username', 'trim|required');
		//$this->form_validation->set_rules('password', 'password', 'trim|required');
		/*$this->form_validation->set_rules('primary_email', 'email', 'trim|required');
		$this->form_validation->set_rules('role_id', 'role id', 'trim|required');
		$this->form_validation->set_rules('firstname', 'firstname', 'trim|required');
		$this->form_validation->set_rules('last_name', 'last name', 'trim|required');*/
		/*$this->form_validation->set_rules('nickname', 'nickname', 'trim|required');
		//$this->form_validation->set_rules('photo', 'photo', 'trim|required');
		$this->form_validation->set_rules('address', 'address', 'trim|required');
		$this->form_validation->set_rules('city', 'city', 'trim|required');
		$this->form_validation->set_rules('postalcode', 'postalcode', 'trim|required');
		$this->form_validation->set_rules('state', 'state', 'trim|required');
		$this->form_validation->set_rules('country_id', 'country id', 'trim|required');
		$this->form_validation->set_rules('phone', 'phone', 'trim|required');
		$this->form_validation->set_rules('dob', 'dob', 'trim|required');
		$this->form_validation->set_rules('note', 'note', 'trim|required');
		$this->form_validation->set_rules('mobile', 'mobile', 'trim|required');*/
		//$this->form_validation->set_rules('status', 'status', 'trim|required');
		//$this->form_validation->set_rules('is_email_sent', 'is email sent', 'trim|required');
		//$this->form_validation->set_rules('is_email_verified', 'is email verified', 'trim|required');

		$this->form_validation->set_rules('id', 'id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-14 06:47:28 */
/* http://harviacode.com */