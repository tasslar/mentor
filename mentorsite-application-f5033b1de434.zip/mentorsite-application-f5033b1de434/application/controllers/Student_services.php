<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Student_services extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Student_services_model');
        $this->load->model('Student_services_model');
        $this->load->model('Classes_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'student_services/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'student_services/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'student_services/index.html';
            $config['first_url'] = base_url() . 'student_services/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Student_services_model->total_rows($q);
        $student_services = $this->Student_services_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'student_services_data' => $student_services,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('student_services/student_services_mgmt_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Student_services_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'student_id' => $row->student_id,
		'power_id' => $row->power_id,
		'instrutor_id' => $row->instrutor_id,
		'class_id' => $row->class_id,
		'amount' => $row->amount,
		'date' => $row->date,
		'from_time' => $row->from_time,
		'to_time' => $row->to_time,
		'lesson' => $row->lesson,
		'comment' => $row->comment,
	    );
            $this->load->view('student_services/student_services_mgmt_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student_services'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('student_services/create_action'),
			'id' => set_value('id'),
			'student_id' => set_value('student_id'),
			'power_id' => set_value('power_id'),
			'instrutor_id' => set_value('instrutor_id'),
			'vehicle_id' => set_value('vehicle_id'),
			'class_id' => set_value('class_id'),
			'amount' => set_value('amount'),
			'date' => set_value('date'),
			'from_time' => set_value('from_time'),
			'to_time' => set_value('to_time'),
			'lesson' => set_value('lesson'),
			'comment' => set_value('comment'),
		);
		$data['classlist'] = $this->Classes_model->get_all();
	
        $this->load->view('student_services/student_services_mgmt_form', $data);
    }
    
    public function create_action() 
    {
        /*$this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {*/
            $data = array(
						'student_id' => $this->input->post('student_id',TRUE),
						'power_id' => $this->input->post('power_id',TRUE),
						'instrutor_id' => $this->input->post('instrutor_id',TRUE),
						'vehicle_id' => $this->input->post('vehicle_id',TRUE),
						'class_id' => $this->input->post('class_id',TRUE),
						'amount' => $this->input->post('amount',TRUE),
						'date' => $this->input->post('date',TRUE),
						'from_time' => $this->input->post('from_time',TRUE),
						'to_time' => $this->input->post('to_time',TRUE),
						'lesson' => $this->input->post('lesson',TRUE),
						'comment' => $this->input->post('comment',TRUE),
					);
        	//print_r( $data);
            $this->Student_services_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            if($this->input->post('studentservice-popup',TRUE)) {
				redirect(site_url('student'));
			} else {
				redirect(site_url('student_services'));
			}
        //}
    }
    
    public function update($id) 
    {
        $row = $this->Student_services_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('student_services/update_action'),
		'id' => set_value('id', $row->id),
		'student_id' => set_value('student_id', $row->student_id),
		'power_id' => set_value('power_id', $row->power_id),
		'instrutor_id' => set_value('instrutor_id', $row->instrutor_id),
		'class_id' => set_value('class_id', $row->class_id),
		'amount' => set_value('amount', $row->amount),
		'date' => set_value('date', $row->date),
		'from_time' => set_value('from_time', $row->from_time),
		'to_time' => set_value('to_time', $row->to_time),
		'lesson' => set_value('lesson', $row->lesson),
		'comment' => set_value('comment', $row->comment),
	    );
            $this->load->view('student_services/student_services_mgmt_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student_services'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'student_id' => $this->input->post('student_id',TRUE),
		'power_id' => $this->input->post('power_id',TRUE),
		'instrutor_id' => $this->input->post('instrutor_id',TRUE),
		'class_id' => $this->input->post('class_id',TRUE),
		'amount' => $this->input->post('amount',TRUE),
		'date' => $this->input->post('date',TRUE),
		'from_time' => $this->input->post('from_time',TRUE),
		'to_time' => $this->input->post('to_time',TRUE),
		'lesson' => $this->input->post('lesson',TRUE),
		'comment' => $this->input->post('comment',TRUE),
	    );

            $this->Student_services_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('student_services'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Student_services_model->get_by_id($id);

        if ($row) {
            $this->Student_services_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('student_services'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student_services'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('student_id', 'student id', 'trim|required');
	$this->form_validation->set_rules('power_id', 'power id', 'trim|required');
	$this->form_validation->set_rules('instrutor_id', 'instrutor id', 'trim|required');
	$this->form_validation->set_rules('class_id', 'class id', 'trim|required');
	$this->form_validation->set_rules('amount', 'amount', 'trim|required');
	$this->form_validation->set_rules('date', 'date', 'trim|required');
	$this->form_validation->set_rules('from_time', 'from time', 'trim|required');
	$this->form_validation->set_rules('to_time', 'to time', 'trim|required');
	$this->form_validation->set_rules('lesson', 'lesson', 'trim|required');
	$this->form_validation->set_rules('comment', 'comment', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }
    
    function get_powermgmt(){
		$this->load->model('Student_services_model');
		if (isset($_GET['term'])){
			$q = strtolower($_GET['term']);
			$this->Student_services_model->get_powermgmt($q);
		}
	}
	
	function get_studentinfo(){
		$this->load->model('Student_services_model');
		if (isset($_GET['term'])){
			$q = strtolower($_GET['term']);
			$this->Student_services_model->get_studentinfo($q);
		}
	}
	
	function get_instructorinfo(){
		$this->load->model('Student_services_model');
		if (isset($_GET['term'])){
			$q = strtolower($_GET['term']);
			$this->Student_services_model->get_instructorinfo($q);
		}
	}
	
	function get_vehicleinfo(){
		$this->load->model('Student_services_model');
		if (isset($_GET['term'])){
			$q = strtolower($_GET['term']);
			$this->Student_services_model->get_vehicleinfo($q);
		}
	}

}

/* End of file Student_services.php */
/* Location: ./application/controllers/Student_services.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-20 07:49:31 */
/* http://harviacode.com */
