<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Student_bills extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Student_bills_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'student_bills/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'student_bills/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'student_bills/index.html';
            $config['first_url'] = base_url() . 'student_bills/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Student_bills_model->total_rows($q);
        $student_bills = $this->Student_bills_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'student_bills_data' => $student_bills,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('student_bills/student_bills_mgmt_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Student_bills_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'student_id' => $row->student_id,
		'invoice_date' => $row->invoice_date,
		'bill_no' => $row->bill_no,
		'amount' => $row->amount,
		'dude_date' => $row->dude_date,
	    );
            $this->load->view('student_bills/student_bills_mgmt_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student_bills'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('student_bills/create_action'),
	    'id' => set_value('id'),
	    'student_id' => set_value('student_id'),
	    'invoice_date' => set_value('invoice_date'),
	    'bill_no' => set_value('bill_no'),
	    'amount' => set_value('amount'),
	    'dude_date' => set_value('dude_date'),
	);
        $this->load->view('student_bills/student_bills_mgmt_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'student_id' => $this->input->post('student_id',TRUE),
		'invoice_date' => $this->input->post('invoice_date',TRUE),
		'bill_no' => $this->input->post('bill_no',TRUE),
		'amount' => $this->input->post('amount',TRUE),
		'dude_date' => $this->input->post('dude_date',TRUE),
	    );

            $this->Student_bills_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('student_bills'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Student_bills_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('student_bills/update_action'),
		'id' => set_value('id', $row->id),
		'student_id' => set_value('student_id', $row->student_id),
		'invoice_date' => set_value('invoice_date', $row->invoice_date),
		'bill_no' => set_value('bill_no', $row->bill_no),
		'amount' => set_value('amount', $row->amount),
		'dude_date' => set_value('dude_date', $row->dude_date),
	    );
            $this->load->view('student_bills/student_bills_mgmt_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student_bills'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'student_id' => $this->input->post('student_id',TRUE),
		'invoice_date' => $this->input->post('invoice_date',TRUE),
		'bill_no' => $this->input->post('bill_no',TRUE),
		'amount' => $this->input->post('amount',TRUE),
		'dude_date' => $this->input->post('dude_date',TRUE),
	    );

            $this->Student_bills_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('student_bills'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Student_bills_model->get_by_id($id);

        if ($row) {
            $this->Student_bills_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('student_bills'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student_bills'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('student_id', 'student id', 'trim|required');
	$this->form_validation->set_rules('invoice_date', 'invoice date', 'trim|required');
	$this->form_validation->set_rules('bill_no', 'bill no', 'trim|required');
	$this->form_validation->set_rules('amount', 'amount', 'trim|required');
	$this->form_validation->set_rules('dude_date', 'dude date', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Student_bills.php */
/* Location: ./application/controllers/Student_bills.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-20 07:50:22 */
/* http://harviacode.com */