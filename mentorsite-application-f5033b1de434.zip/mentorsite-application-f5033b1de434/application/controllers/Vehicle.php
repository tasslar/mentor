<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Vehicle extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Vehicle_model');
        $this->load->model('Instrutor_vehicle_model');
        $this->load->model('Branches_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'vehicle/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'vehicle/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'vehicle/index.html';
            $config['first_url'] = base_url() . 'vehicle/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Vehicle_model->total_rows($q);
        $vehicle = $this->Vehicle_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'vehicle_data' => $vehicle,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $data['title'] = 'Mentor-Manage Vehicle';
		$data['main_content'] = 'vehicle/vehicle_mgmt_list';
		$this->load->view('includes/template', $data);
    }

    public function read($id) 
    {
        $row = $this->Vehicle_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'vehicletype_id' => $row->vehicletype_id,
		'photo' => $row->photo,
		'pricegroup_id' => $row->pricegroup_id,
		'description' => $row->description,
		'license_plate' => $row->license_plate,
		'designation' => $row->designation,
		'manufauture' => $row->manufauture,
		'model' => $row->model,
		'keynumber' => $row->keynumber,
	    );
            $this->load->view('vehicle/vehicle_mgmt_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('vehicle'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('vehicle/create_action'),
			'id' => set_value('id'),
			'vehicletype_id' => set_value('vehicletype_id'),
			'photo' => set_value('photo'),
			'pricegroup_id' => set_value('pricegroup_id'),
			'description' => set_value('description'),
			'license_plate' => set_value('license_plate'),
			'designation' => set_value('designation'),
			'manufauture' => set_value('manufauture'),
			'model' => set_value('model'),
			'keynumber' => set_value('keynumber'),
			'branch_details' => set_value('branch_details', $this->branch_list()),
	);
       $data['title'] = 'Mentor-Create Vehicle';
		$data['main_content'] = 'vehicle/vehicle_mgmt_form';
		$this->load->view('includes/template', $data);
    }
    public	function ajax_list()
	{
		$list = $this->Vehicle_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach($list as $customers) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $customers->vehicletype_id;
			$row[] = $customers->photo;
			$row[] = $customers->description;
			$row[] = $customers->manufauture;
			$row[] = $customers->model;
			$row[] = $customers->keynumber;
			$row[] = $customers->status;
			$row[] = anchor(site_url('vehicle/update/' . $customers->id) , 'Update');
			$udpateordelete = ($customers->status == 'Active') ? 'Delete' : 'Active';
			$row[] = anchor(site_url('vehicle/' . $udpateordelete . '/' . $customers->id) , $udpateordelete, 'onclick="javasciprt: return confirm(\'Are You Sure ?\')"');
			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Vehicle_model->count_all() ,
			"recordsFiltered" => $this->Vehicle_model->count_filtered() ,
			"data" => $data,
		);

		// output to json format

		echo json_encode($output);
	}
    public	function branch_list()
	{
		$list = $this->Branches_model->get_all();
		$data = array();
		foreach($list as $customers) {
			
			$row = array(
				'branch_id' => $customers->id,
				'branch_name' => $customers->name );
				$data[] = $row;
		}
		// output to json format
		return $data;
		//echo json_encode( $data);
	}
	public	function instructor_list()
	{
		$list = $this->Instrutor_vehicle_model->get_all();
		$data = array();
		foreach($list as $customers) {
			
			$row = array(
				'branch_id' => $customers->id,
				'branch_name' => $customers->name );
				$data[] = $row;
		}
		// output to json format
		return $data;
	}
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
				'vehicletype_id' => $this->input->post('vehicletype_id',TRUE),
				'photo' => $this->input->post('photo',TRUE),
				'pricegroup_id' => $this->input->post('pricegroup_id',TRUE),
				'description' => $this->input->post('description',TRUE),
				'license_plate' => $this->input->post('license_plate',TRUE),
				'designation' => $this->input->post('designation',TRUE),
				'manufauture' => $this->input->post('manufauture',TRUE),
				'model' => $this->input->post('model',TRUE),
				'keynumber' => $this->input->post('keynumber',TRUE),
				);

            $this->Vehicle_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('vehicle'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Vehicle_model->get_by_id($id);
        $list = $this->Branches_model->get_datatables();

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('vehicle/update_action'),
				'id' => set_value('id', $row->id),
				'vehicletype_id' => set_value('vehicletype_id', $row->vehicletype_id),
				'photo' => set_value('photo', $row->photo),
				'pricegroup_id' => set_value('pricegroup_id', $row->pricegroup_id),
				'description' => set_value('description', $row->description),
				'license_plate' => set_value('license_plate', $row->license_plate),
				'designation' => set_value('designation', $row->designation),
				'manufauture' => set_value('manufauture', $row->manufauture),
				'model' => set_value('model', $row->model),
				'keynumber' => set_value('keynumber', $row->keynumber),
				 'branch_details' => set_value('branch_details', $this->branch_list()),
				
	    );
            $this->load->view('vehicle/vehicle_mgmt_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('vehicle'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
			'vehicletype_id' => $this->input->post('vehicletype_id',TRUE),
			'photo' => $this->input->post('photo',TRUE),
			'pricegroup_id' => $this->input->post('pricegroup_id',TRUE),
			'description' => $this->input->post('description',TRUE),
			'license_plate' => $this->input->post('license_plate',TRUE),
			'designation' => $this->input->post('designation',TRUE),
			'manufauture' => $this->input->post('manufauture',TRUE),
			'model' => $this->input->post('model',TRUE),
			'keynumber' => $this->input->post('keynumber',TRUE),
	    );

            $this->Vehicle_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('vehicle'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Vehicle_model->get_by_id($id);
       if ($row) {
			$data = array(
				'status' => 'Inactive',
			);
			$this->Vehicle_model->update($id, $data);
			$this->session->set_flashdata('message', '<span class="text-success">vehicle has been deleted successfully</span>');
			redirect(site_url('vehicle'));
		}
		else {
			$this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
			redirect(site_url('vehicle'));
		}
    }
	public	function active($id)
	{
		$row = $this->Vehicle_model->get_by_id($id);
		if ($row) {
			$data = array(
				'status' => 'Active',
			);
			$this->Vehicle_model->update($id, $data);
			$this->session->set_flashdata('message', '<span class="text-success">Vehicle has been Activated Successfully</span>');
			redirect(site_url('vehicle'));
		}
		else {
			$this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
			redirect(site_url('vehicle'));
		}
	}

    public function _rules() 
    {
		$this->form_validation->set_rules('vehicletype_id', 'vehicletype id', 'trim|required');
		$this->form_validation->set_rules('photo', 'photo', 'trim|required');
		$this->form_validation->set_rules('pricegroup_id', 'pricegroup id', 'trim|required');
		$this->form_validation->set_rules('description', 'description', 'trim|required');
		$this->form_validation->set_rules('license_plate', 'license plate', 'trim|required');
		$this->form_validation->set_rules('designation', 'designation', 'trim|required');
		$this->form_validation->set_rules('manufauture', 'manufauture', 'trim|required');
		$this->form_validation->set_rules('model', 'model', 'trim|required');
		$this->form_validation->set_rules('keynumber', 'keynumber', 'trim|required');

		$this->form_validation->set_rules('id', 'id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Vehicle.php */
/* Location: ./application/controllers/Vehicle.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-18 06:50:05 */
/* http://harviacode.com */
