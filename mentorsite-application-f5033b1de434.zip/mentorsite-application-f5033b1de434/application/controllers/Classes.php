<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Classes extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Classes_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'classes/index?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'classes/index?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'classes/index';
            $config['first_url'] = base_url() . 'classes/index';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Classes_model->total_rows($q);
        $Classes = $this->Classes_model->get_limit_data($config['per_page'], $start, $q);
       // $data['roles'] = $this->Roles_model->get_all();

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'classes_data' => $Classes,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
      
        //load the view
        $data['title'] = 'Mentor-Manage Classes';

        $data['main_content'] = 'classes/classes_mgmt_list';
        $this->load->view('includes/template', $data);
    }
	// Datatables Function
	
	public function ajax_list()
    {
        $list = $this->Classes_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $customers->surname;
            $row[] = $customers->designation;
            $row[] = $customers->tax;
            $row[] = $customers->description;
            $row[] = $customers->status;
            $row[] = anchor(site_url('classes/update/'.$customers->id),'Update');
            $udpateordelete = ($customers->status=='Active') ? 'Delete' : 'Active'; 
            $row[] = anchor(site_url('classes/'.$udpateordelete.'/'.$customers->id),$udpateordelete,'onclick="javasciprt: return confirm(\'Are You Sure ?\')"'); 
        				 
 
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Classes_model->count_all(),
                        "recordsFiltered" => $this->Classes_model->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }
	
	
	// Ends Here
    public function read($id) 
    {
		$data['title'] = 'Mentor-Manage';
        $row = $this->Classes_model->get_by_id($id);
        if ($row) {
            $data = array(
			'id' => $row->id,
			'surname' => $row->surname,
			'designation' => $row->designation,
			'tax' => $row->tax,
			'description' => $row->description,
			'status' => $row->status,
			);
            $this->load->view('classes/classes_mgmt_read', $data);
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('classes'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('classes/create_action'),
		    'id' => set_value('id'),
		    'surname' => set_value('surname'),
		    'designation' => set_value('designation'),
		    'tax' => set_value('tax'),
		    'description' => set_value('description'),
			);

        //$data['roles'] = $this->Roles_model->get_all();
        $data['title'] = 'Mentor-Create classes ';
        $data['main_content'] = 'classes/classes_mgmt_form';
        $this->load->view('includes/template', $data);  
    }
    
    public function create_action() 
    {
        $this->_rules();

    	//$this->load->helper('classes_helper');

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
				'surname' => $this->input->post('surname',TRUE),
				'designation' => $this->input->post('designation',TRUE),
				'tax' => $this->input->post('tax',TRUE),
				'description' => $this->input->post('description',TRUE),
				);

            $result=$this->Classes_model->insert($data);
         
            if($result=='1'){
            $this->session->set_flashdata('message', '<span class="text-success">Class has been Inserted successfully</span>');
            redirect(site_url('classes'));
			}else{
				$this->session->set_flashdata('message', '<span class="text-info">Error : Class name already Exists</span>');
            redirect(site_url('classes'));
			}
		}
    }
    
    public function update($id) 
    {
        $row = $this->Classes_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('Classes/update_action'),
				'id' => set_value('id', $row->id),
				'surname' => set_value('surname', $row->surname),
				'designation' => set_value('state', $row->designation),
				'tax' => set_value('state', $row->tax),
				'description' => set_value('state', $row->description),
		    );
			 $data['title'] = 'Mentor-Update classes';
        	$data['main_content'] = 'classes/classes_mgmt_form';
       		//$data['roles'] = $this->Roles_model->get_all();
        	$this->load->view('includes/template', $data);  
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('classes'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
				'surname' => $this->input->post('surname',TRUE),
				'designation' => $this->input->post('designation',TRUE),
				'tax' => $this->input->post('tax',TRUE),
				'description' => $this->input->post('description',TRUE),
		    );

            $this->Classes_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', '<span class="text-success">Class has been updated successfully</span>');
            redirect(site_url('classes'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Classes_model->get_by_id($id);

        if ($row) {
             $data = array(
				'status' => 'Inactive',
			);
            $this->Classes_model->update($id, $data);
            
            $this->session->set_flashdata('message', '<span class="text-success">class has been deleted successfully</span>');
            redirect(site_url('classes'));
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('classes'));
        }
    }
	public function active($id) 
    {
        $row = $this->Classes_model->get_by_id($id);

        if ($row) {
            //$this->Users_model->delete($id);

            $data = array(
				'status' => 'Active',
			);
            $this->Classes_model->update($id, $data);
            $this->session->set_flashdata('message', '<span class="text-success">Class has been Activated Successfully</span>');
            redirect(site_url('classes'));
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('classes'));
        }
    }
    public function _rules() 
    {
		
		$this->form_validation->set_rules('surname', 'surname', 'trim|required');
		$this->form_validation->set_rules('tax', 'tax', 'trim|required');
		$this->form_validation->set_rules('description', 'description', 'trim|required');
		$this->form_validation->set_rules('designation', 'designation', 'trim|required');
		$this->form_validation->set_rules('id', 'id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Classes.php */
/* Location: ./application/controllers/Classes.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-14 06:47:28 */
/* http://harviacode.com */
