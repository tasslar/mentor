<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Users extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Users_model');
        $this->load->model('Roles_model');
        $this->load->model('Country_model');
        $this->load->library('form_validation');
    }

    public function ajax_list()
    {
        $list = $this->Users_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $user) {
        	$roles = $this->Roles_model->get_by_id($user->role_id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $user->username;
            $row[] = $user->primary_email;
            $row[] = $user->firstname;
            $row[] = $user->last_name;
            $row[] = $roles->role_name;
            $row[] = $user->phone;
            $row[] = $user->status;

			$rowaction = anchor(site_url('users/update/' . $user->id) , 'Update'). ' | ';
			$udpateordelete = ($user->status == 'Active') ? 'Delete' : 'Active';
			$rowaction .= anchor(site_url('users/' . $udpateordelete . '/' . $user->id) , $udpateordelete, 'onclick="javasciprt: return confirm(\'Are You Sure ?\')"');
 			$row[] = $rowaction;
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Users_model->count_all(),
                        "recordsFiltered" => $this->Users_model->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }

    public function index()
    {		

        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'users/index?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'users/index?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'users/index';
            $config['first_url'] = base_url() . 'users/index';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Users_model->total_rows($q);
        $users = $this->Users_model->get_limit_data($config['per_page'], $start, $q);
        $data['roles'] = $this->Roles_model->get_all();

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'users_data' => $users,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
       // $this->load->view('users/users_mgmt_list', $data);
        //load the view
        $data['title'] = 'Mentor-Manage users';
        $data['main_content'] = 'users/users_mgmt_list';
        $this->load->view('includes/template', $data);  
    }

    public function read($id) 
    {
        $data['title'] = 'Mentor-Manage';
        $row = $this->Users_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'username' => $row->username,
		'password' => $row->password,
		'email' => $row->email,
		'dob' => $row->dob,
		'note' => $row->note,
		'role_id' => $row->role_id,
		'firstname' => $row->firstname,
		'last_name' => $row->last_name,
		'nickname' => $row->nickname,
		'photo' => $row->photo,
		'address' => $row->address,
		'city' => $row->city,
		'postalcode' => $row->postalcode,
		'state' => $row->state,
		'country_id' => $row->country_id,
		'phone' => $row->phone,
		'mobile' => $row->mobile,
		'status' => $row->status,
		'is_email_sent' => $row->is_email_sent,
		'primary_email' => $row->primary_email,
	    );
            $this->load->view('users/users_mgmt_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('users'));
        }
    }

    public function create() 
    {
    	$this->load->helper('user_helper');
    	//Load email library
		$this->load->library('email');
    	$username = generateRandomString();
	    $password = get_random_password();
        $data = array(
            'button' => 'Create',
            'action' => site_url('users/create_action'),
		    'id' => set_value('id'),
		    'username' => $username,
		    'password' => $password,
		    'dob' => set_value('dob'),
		    'note' => set_value('note'),
		    'email' => set_value('email'),
		    'role_id' => set_value('role_id'),
		    'firstname' => set_value('firstname'),
		    'last_name' => set_value('last_name'),
		    'nickname' => set_value('nickname'),
		    //'photo' => set_value('photo'),
		    'address' => set_value('address'),
		    'city' => set_value('city'),
		    'postalcode' => set_value('postalcode'),
		    'state' => set_value('state'),
		    'country_id' => set_value('country_id'),
		    'phone' => set_value('phone'),
		    'mobile' => set_value('mobile'),
		    'op_address' => set_value('op_address'),
		    'op_city' => set_value('op_city'),
		    'op_postalcode' => set_value('op_postalcode'),
		    'op_state' => set_value('op_state'),
		    'op_country_id' => set_value('op_country_id'),
		    'op_phone' => set_value('op_phone'),
		    'op_mobile' => set_value('op_mobile'),
		    'op_email' => set_value('op_email'),
		    'primary_email' => set_value('primary_email'),
		);

        $data['roles'] = $this->Roles_model->get_all();
        $data['country'] = $this->Country_model->get_all();
        $data['title'] = 'Mentor-Manage users create';
        $data['main_content'] = 'users/users_mgmt_form';
        $this->load->view('includes/template', $data);  
    }
    
    public function create_action() 
    {
        $this->_rules();

    	$this->load->helper('user_helper');


       if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
        	$dob = date("Y-m-d", strtotime($this->input->post('dob',TRUE)));
            $data = array(		
		    	'username' => $this->input->post('username',TRUE),
			    'password' => $this->input->post('password',TRUE),
				'email' => $this->input->post('email',TRUE),
				'dob' => $dob,
				'note' => $this->input->post('note',TRUE),
				'role_id' => $this->input->post('role_id',TRUE),
				'firstname' => $this->input->post('firstname',TRUE),
				'last_name' => $this->input->post('last_name',TRUE),
				'nickname' => $this->input->post('nickname',TRUE),
				//'photo' => $this->input->post('photo',TRUE),
				'address' => $this->input->post('address',TRUE),
				'city' => $this->input->post('city',TRUE),
				'postalcode' => $this->input->post('postalcode',TRUE),
				'state' => $this->input->post('state',TRUE),
				'country_id' => $this->input->post('country_id',TRUE),
				'phone' => $this->input->post('phone',TRUE),
				'mobile' => $this->input->post('mobile',TRUE),
				'op_address' => $this->input->post('op_address',TRUE),
				'op_city' => $this->input->post('op_city',TRUE),
				'op_postalcode' => $this->input->post('op_postalcode',TRUE),
				'op_state' => $this->input->post('op_state',TRUE),
				'op_country_id' => $this->input->post('op_country_id',TRUE),
				'op_phone' => $this->input->post('op_phone',TRUE),
				'op_mobile' => $this->input->post('op_mobile',TRUE),
				'op_email' => $this->input->post('op_email',TRUE),
				'primary_email' => $this->input->post('primary_email',TRUE),
		    );

            $this->Users_model->insert($data);

			//Load email library
			$this->load->library('email');

	        $this->email->from('demo@inysol.com', 'admin');
	        $this->email->to($this->input->post('primary_email',TRUE)); 

	        $this->email->subject('Your Mentor account has been created successfully');
	        $emaildata = array(
             	'name'=> $this->input->post('firstname',TRUE).' '. $this->input->post('last_name',TRUE),
             	'username'=> $this->input->post('username',TRUE),
             	'password'=> $this->input->post('password',TRUE),
             	'url'=> ''
    	    );

	        $body = $this->load->view('emails/user_register.php',$emaildata,TRUE);
    		$this->email->message($body);  

			try{
	      		$result = $this->email->send();
			}catch(Exception $e){
				echo $e->getMessage();
			}

            $this->session->set_flashdata('message', '<span class="text-success">New user has been added Successfully</span>');
            redirect(site_url('users'));
        }
    }
    
    public function update($id) 
    {     
        $row = $this->Users_model->get_by_id($id);

        if ($row) {
        	$dob = date("d-m-Y", strtotime($row->dob));
            $data = array(
                'button' => 'Update',
                'action' => site_url('users/update_action'),
				'id' => set_value('id', $row->id),
				'username' => set_value('username', $row->username),
				'password' => set_value('password', $row->password),
				'email' => set_value('email', $row->email),
				'dob' => set_value('dob', $dob),
				'note' => set_value('note', $row->note),
				'role_id' => set_value('role_id', $row->role_id),
				'firstname' => set_value('firstname', $row->firstname),
				'last_name' => set_value('last_name', $row->last_name),
				'nickname' => set_value('nickname', $row->nickname),
				'photo' => set_value('photo', $row->photo),
				'address' => set_value('address', $row->address),
				'city' => set_value('city', $row->city),
				'postalcode' => set_value('postalcode', $row->postalcode),
				'state' => set_value('state', $row->state),
				'country_id' => set_value('country_id', $row->country_id),
				'phone' => set_value('phone', $row->phone),
				'mobile' => set_value('mobile', $row->mobile),
				//'status' => set_value('status', $row->status),
				//'is_email_sent' => set_value('is_email_sent', $row->is_email_sent),
				'primary_email' => set_value('primary_email', $row->primary_email),
			    'op_address' => set_value('op_address', $row->op_address),
			    'op_city' => set_value('op_city', $row->op_city),
			    'op_postalcode' => set_value('op_postalcode', $row->op_postalcode),
			    'op_state' => set_value('op_state', $row->op_state),
			    'op_country_id' => set_value('op_country_id', $row->op_country_id),
			    'op_phone' => set_value('op_phone', $row->op_phone),
			    'op_mobile' => set_value('op_phone', $row->op_mobile),
			    'op_email' => set_value('op_email', $row->op_email),
		    );

        	$data['main_content'] = 'users/users_mgmt_form';
       		$data['roles'] = $this->Roles_model->get_all();
        	$data['country'] = $this->Country_model->get_all();
   		    $data['title'] = 'Mentor-Manage users update';
        	$this->load->view('includes/template', $data);  
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('users'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules('update');

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
        	$dob = date("Y-m-d", strtotime($this->input->post('dob',TRUE)));
            $data = array(
				//'username' => $this->input->post('username',TRUE),
				//'password' => $this->input->post('password',TRUE),
				'primary_email' => $this->input->post('primary_email',TRUE),
				'role_id' => $this->input->post('role_id',TRUE),
				'firstname' => $this->input->post('firstname',TRUE),
				'last_name' => $this->input->post('last_name',TRUE),
				'nickname' => $this->input->post('nickname',TRUE),
				//'photo' => $this->input->post('photo',TRUE),
				'dob' => $dob,
				'note' => $this->input->post('note',TRUE),
				'address' => $this->input->post('address',TRUE),
				'city' => $this->input->post('city',TRUE),
				'postalcode' => $this->input->post('postalcode',TRUE),
				'state' => $this->input->post('state',TRUE),
				'country_id' => $this->input->post('country_id',TRUE),
				'phone' => $this->input->post('phone',TRUE),
				'mobile' => $this->input->post('mobile',TRUE),
				//'status' => $this->input->post('status',TRUE),
				//'is_email_sent' => $this->input->post('is_email_sent',TRUE),
				//'is_email_verified' => $this->input->post('is_email_verified',TRUE),
				'op_address' => $this->input->post('op_address',TRUE),
				'op_city' => $this->input->post('op_city',TRUE),
				'op_postalcode' => $this->input->post('op_postalcode',TRUE),
				'op_state' => $this->input->post('op_state',TRUE),
				'op_country_id' => $this->input->post('op_country_id',TRUE),
				'op_phone' => $this->input->post('op_phone',TRUE),
				'op_mobile' => $this->input->post('op_mobile',TRUE),
				'op_email' => $this->input->post('op_email',TRUE),
				'email' => $this->input->post('email',TRUE),
		    );

            $this->Users_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', '<span class="text-success">User has been updated Successfully</span>');
            redirect(site_url('users'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Users_model->get_by_id($id);

        if ($row) {
            //$this->Users_model->delete($id);

            $data = array(
				'status' => 'Inactive',
			);
            $this->Users_model->update($id, $data);
            $this->session->set_flashdata('message', '<span class="text-success">User has been Deleted Successfully</span>');
            redirect(site_url('users'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('users'));
        }
    }
    public function active($id) 
    {
        $row = $this->Users_model->get_by_id($id);

        if ($row) {
            //$this->Users_model->delete($id);

            $data = array(
				'status' => 'Active',
			);
            $this->Users_model->update($id, $data);
            $this->session->set_flashdata('message', '<span class="text-success">User has been Activated Successfully</span>');
            redirect(site_url('users'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('users'));
        }
    }

    public function _rules($where='') 
    {
		//$this->form_validation->set_rules('username', 'username', 'trim|required');
		//$this->form_validation->set_rules('password', 'password', 'trim|required');
		//$this->form_validation->set_rules('primary_email', 'email', 'trim|required');
		if(!$where)	$this->form_validation->set_rules('primary_email', 'Email', 'required|valid_email|is_unique[users_mgmt.primary_email]');
		$this->form_validation->set_rules('role_id', 'role id', 'trim|required');
		$this->form_validation->set_rules('firstname', 'firstname', 'trim|required');
		$this->form_validation->set_rules('last_name', 'last name', 'trim|required');
		/*$this->form_validation->set_rules('nickname', 'nickname', 'trim|required');
		//$this->form_validation->set_rules('photo', 'photo', 'trim|required');
		$this->form_validation->set_rules('address', 'address', 'trim|required');
		$this->form_validation->set_rules('city', 'city', 'trim|required');
		$this->form_validation->set_rules('postalcode', 'postalcode', 'trim|required');
		$this->form_validation->set_rules('state', 'state', 'trim|required');
		$this->form_validation->set_rules('country_id', 'country id', 'trim|required');
		$this->form_validation->set_rules('phone', 'phone', 'trim|required');
		$this->form_validation->set_rules('dob', 'dob', 'trim|required');
		$this->form_validation->set_rules('note', 'note', 'trim|required');
		$this->form_validation->set_rules('mobile', 'mobile', 'trim|required');*/
		//$this->form_validation->set_rules('status', 'status', 'trim|required');
		//$this->form_validation->set_rules('is_email_sent', 'is email sent', 'trim|required');
		//$this->form_validation->set_rules('is_email_verified', 'is email verified', 'trim|required');

		$this->form_validation->set_rules('id', 'id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
		$this->form_validation->set_message('is_unique', 'User account email already exists ,try again');

    }

}

/* End of file Users.php */
/* Location: ./application/controllers/Users.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-14 06:47:28 */
/* http://harviacode.com */