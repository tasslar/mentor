<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pricegroup extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Pricegroup_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'pricegroup/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'pricegroup/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'pricegroup/index.html';
            $config['first_url'] = base_url() . 'pricegroup/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Pricegroup_model->total_rows($q);
        $pricegroup = $this->Pricegroup_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'pricegroup_data' => $pricegroup,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
       $data['title'] = 'Mentor-Create Price Group';
		$data['main_content'] = 'pricegroup/pricegroup_mgmt_list';
		$this->load->view('includes/template', $data);
    }
	public	function ajax_list()
	{
		$list = $this->Pricegroup_model->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach($list as $customers) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $customers->name;
			$row[] = $customers->description;
			$row[] = $customers->status;
			$row[] = anchor(site_url('pricegroup/update/' . $customers->id) , 'Update');
			$udpateordelete = ($customers->status == 'Active') ? 'Delete' : 'Active';
			$row[] = anchor(site_url('pricegroup/' . $udpateordelete . '/' . $customers->id) , $udpateordelete, 'onclick="javasciprt: return confirm(\'Are You Sure ?\')"');
			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Pricegroup_model->count_all() ,
			"recordsFiltered" => $this->Pricegroup_model->count_filtered() ,
			"data" => $data,
		);

		// output to json format

		echo json_encode($output);
	}
    public function read($id) 
    {
        $row = $this->Pricegroup_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'name' => $row->name,
		'description' => $row->description,
		'status' => $row->status,
	    );
            $this->load->view('pricegroup/pricegroup_mgmt_read', $data);
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('pricegroup'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('pricegroup/create_action'),
			'id' => set_value('id'),
			'name' => set_value('name'),
			'description' => set_value('description'),
			'classid' => set_value('classid'),
			'status' => set_value('status'),
		);
       
        $data['title'] = 'Mentor-Create Price Group';
		$data['main_content'] = 'pricegroup/pricegroup_mgmt_form';
		$this->load->view('includes/template', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
			'name' => $this->input->post('name',TRUE),
			'description' => $this->input->post('description',TRUE),
			'status' => 'Active',
	    );

            $priceid=$this->Pricegroup_model->insert($data);
            $mapdata = array(
				'pricegroup_id' => $priceid,
				'class_id' => $this->input->post('classid',TRUE)
			);
			$this->Pricegroup_model->classmapInsert($mapdata);
            $this->session->set_flashdata('message', '<span class="text-success">Create Record Success</span>');
            redirect(site_url('pricegroup'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Pricegroup_model->get_by_id($id);
		$classid = $this->Pricegroup_model->getmapclassId($row->id);
        if ($row) {
            $data = array(
					'button' => 'Update',
					'action' => site_url('pricegroup/update_action'),
					'id' => set_value('id', $row->id),
					'name' => set_value('name', $row->name),
					'description' => set_value('description', $row->description),
					'classid' => set_value('classid', $classid->class_id),
					'status' => set_value('status', $row->status),
				);
            $data['title'] = 'Mentor-Update Price Group';
			$data['main_content'] = 'pricegroup/pricegroup_mgmt_form';
			$this->load->view('includes/template', $data);
        } else {
            $this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
            redirect(site_url('pricegroup'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
					'name' => $this->input->post('name',TRUE),
					'description' => $this->input->post('description',TRUE),
					'status' => 'Active',
				);
			$mapdata = array(
				'class_id' => $this->input->post('classid',TRUE)
			);
			
			$this->Pricegroup_model->updatemapclassId($this->input->post('id', TRUE),$mapdata);
            $this->Pricegroup_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', '<span class="text-success">Update Record Success</span>');
            redirect(site_url('pricegroup'));
        }
    }
    
    public function delete($id)
	{
		$row = $this->Pricegroup_model->get_by_id($id);
		if ($row) {
			$data = array(
				'status' => 'Inactive',
			);
			$this->Pricegroup_model->update($id, $data);
			$this->session->set_flashdata('message', '<span class="text-success">Pricegroup has been deleted successfully</span>');
			redirect(site_url('pricegroup'));
		}
		else {
			$this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
			redirect(site_url('pricegroup'));
		}
	}

	public function active($id)
	{
		$row = $this->Pricegroup_model->get_by_id($id);
		if ($row) {
			$data = array(
				'status' => 'Active',
			);
			$this->Pricegroup_model->update($id, $data);
			$this->session->set_flashdata('message', '<span class="text-success">Pricegroup has been Activated Successfully</span>');
			redirect(site_url('pricegroup'));
		}
		else {
			$this->session->set_flashdata('message', '<span class="text-info">Record Not Found</span>');
			redirect(site_url('pricegroup'));
		}
	}

    public function _rules() 
    {
		$this->form_validation->set_rules('name', 'name', 'trim|required');
		$this->form_validation->set_rules('description', 'description', 'trim|required');
		$this->form_validation->set_rules('id', 'id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Pricegroup.php */
/* Location: ./application/controllers/Pricegroup.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-18 06:51:34 */
/* http://harviacode.com */
