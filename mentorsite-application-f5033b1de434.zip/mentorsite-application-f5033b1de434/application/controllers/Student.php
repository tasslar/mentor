<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Student extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Student_model');
        $this->load->model('Vehicle_model');
        $this->load->model('Classes_model');
        $this->load->model('Student_services_model');
        $this->load->model('Country_model');
        $this->load->library('form_validation');
    }

    /* student functionality*/
    public function ajax_student_list()
    {
        $list = $this->Student_model->get_student_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $student) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $student->first_name.' '.$student->surname;
            $row[] = $student->email;
            $row[] = $student->address;
            $row[] = $student->phone;
            $row[] = $student->status;

			$rowaction = anchor(site_url('student/update/' . $student->id) , 'Update'). ' | ';
			$udpateordelete = ($student->status == 'Active') ? 'Delete' : 'Active';
			$rowaction .= anchor(site_url('student/' . $udpateordelete . '/' . $student->id) , $udpateordelete, 'onclick="javasciprt: return confirm(\'Are You Sure ?\')"');
 			$row[] = $rowaction;
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Student_model->count_student_all(),
                        "recordsFiltered" => $this->Student_model->count_student_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }


    public function listall()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'student/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'student/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'student/index.html';
            $config['first_url'] = base_url() . 'student/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Student_model->total_rows($q);
        $student = $this->Student_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'student_data' => $student,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );

    	$data['main_content'] = 'student/student_ajax_mgmt_list';
   		$data['title'] = 'Mentor-Manage student list';
   		$data['classlist'] = $this->Classes_model->get_all();
   		//$data['studservicemgmt'] = $this->Student_services_model->get_all();
   		$data['studservicemgmt'] = $this->Student_model->Studentservices();
   	
    	$this->load->view('includes/template', $data);  
        //$this->load->view('student/student_mgmt_list', $data);
    }
    /* student functionality*/

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'student/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'student/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'student/index.html';
            $config['first_url'] = base_url() . 'student/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Student_model->total_rows($q);
        $student = $this->Student_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'student_data' => $student,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );

    	$data['main_content'] = 'student/student_ajax_mgmt_list';
   		$data['title'] = 'Mentor-Manage student list';
   		$data['classlist'] = $this->Classes_model->get_all();
   		//$data['studservicemgmt'] = $this->Student_services_model->get_all();
   		$data['studservicemgmt'] = $this->Student_model->Studentservices();
   	
    	$this->load->view('includes/template', $data);  
        //$this->load->view('student/student_mgmt_list', $data);
    }
	public	function ajax_list()
	{
		$list = $this->Student_model->Studentservices();
		$data = array();
		$no = $_POST['start'];
		foreach($list as $customers) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $customers->servicetype_name;
			$row[] = $customers->date;
			$row[] = $customers->from_time;
			$row[] = $customers->to_time;
			$row[] = $customers->username;
			$row[] = $customers->vehicle_name;
			$row[] = $customers->surname;
			$row[] = $customers->amount;
			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Student_model->count_all() ,
			"recordsFiltered" => $this->Student_model->count_filtered() ,
			"data" => $data,
		);

		// output to json format

		echo json_encode($output);
	}

    public function read($id) 
    {
        $row = $this->Student_model->get_by_id($id);
        if ($row) {
            $data = array(
				'id' => $row->id,
				'username' => $row->username,
				'password' => $row->password,
				'email' => $row->email,
				'instrutor_id' => $row->instrutor_id,
				'branch_id' => $row->branch_id,
				'address' => $row->address,
				'state' => $row->state,
				'country_id' => $row->country_id,
				'photo' => $row->photo,
				'first_name' => $row->first_name,
				'surname' => $row->surname,
				'dob' => $row->dob,
				'placeofbirth' => $row->placeofbirth,
				'phone' => $row->phone,
				'mobile' => $row->mobile,
				'language' => $row->language,
				'note' => $row->note,
				'nationality' => $row->nationality,
				'consentezb' => $row->consentezb,
				'firstaidcourse' => $row->firstaidcourse,
				'physical' => $row->physical,
				'visiontest' => $row->visiontest,
				'visualaid' => $row->visualaid,
				'guardian_name' => $row->guardian_name,
				'g_surname' => $row->g_surname,
				'g_dob' => $row->g_dob,
				'g_address' => $row->g_address,
				'g_city' => $row->g_city,
				'g_postalcode' => $row->g_postalcode,
				'g_state' => $row->g_state,
				'g_country_id' => $row->g_country_id,
				'g_email' => $row->g_email,
				'g_phone' => $row->g_phone,
				'traning_allocatoion_type' => $row->traning_allocatoion_type,
				'payment_debit' => $row->payment_debit,
				'payment_dunning' => $row->payment_dunning,
				'payment_dunning_level' => $row->payment_dunning_level,
				'payment_bankcode' => $row->payment_bankcode,
				'payment_acc_number' => $row->payment_acc_number,
				'payment_iban' => $row->payment_iban,
				'payment_swiftcode' => $row->payment_swiftcode,
				'payment_owner' => $row->payment_owner,
				'opos' => $row->opos,
				'status' => $row->status,
		    );
            //$this->load->view('student/student_mgmt_read', $data);

    		$data['main_content'] = 'student/student_mgmt_read';
   			$data['title'] = 'Mentor-Manage student read';
   			$this->load->view('includes/template', $data);  
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student'));
        }
    }

    public function create() 
    {
    	$this->load->helper('user_helper');
    	//Load email library
		$this->load->library('email');
    	$username = generateRandomString();
	    $password = get_random_password();
        $data = array(
            'button' => 'Create',
            'action' => site_url('student/create_action'),
		    'id' => set_value('id'),
		    'username' => $username,
		    'password' => $password,
		    'email' => set_value('email'),
		    'instrutor_id' => set_value('instrutor_id'),
		    'branch_id' => set_value('branch_id'),
		    'address' => set_value('address'),
		    'city' => set_value('city'),
		    'postalcode' => set_value('postalcode'),
		    'state' => set_value('state'),
		    'country_id' => set_value('country_id'),
		    'photo' => set_value('photo'),
		    'first_name' => set_value('first_name'),
		    'surname' => set_value('surname'),
		    'abbreviation' => set_value('abbreviation'),
		    'dob' => set_value('dob'),
		    'placeofbirth' => set_value('placeofbirth'),
		    'phone' => set_value('phone'),
		    'mobile' => set_value('mobile'),
		    'language' => set_value('language'),
		    'note' => set_value('note'),
		    'nationality' => set_value('nationality'),
		    'consentezb' => set_value('consentezb'),
		    'firstaidcourse' => set_value('firstaidcourse'),
		    'physical' => set_value('physical'),
		    'visiontest' => set_value('visiontest'),
		    'visualaid' => set_value('visualaid'),
		    'guardian_name' => set_value('guardian_name'),
		    'g_surname' => set_value('g_surname'),
		    'g_dob' => set_value('g_dob'),
		    'g_address' => set_value('g_address'),
		    'g_city' => set_value('g_city'),
		    'g_postalcode' => set_value('g_postalcode'),
		    'g_state' => set_value('g_state'),
		    'g_country_id' => set_value('g_country_id'),
		    'g_email' => set_value('g_email'),
		    'g_phone' => set_value('g_phone'),
		    'g_mobile' => set_value('g_mobile'),
		    'traning_allocatoion_type' => set_value('traning_allocatoion_type'),
		    'payment_debit' => set_value('payment_debit'),
		    'payment_dunning' => set_value('payment_dunning'),
		    'payment_dunning_level' => set_value('payment_dunning_level'),
		    'payment_bankcode' => set_value('payment_bankcode'),
		    'payment_acc_number' => set_value('payment_acc_number'),
		    'payment_iban' => set_value('payment_iban'),
		    'payment_swiftcode' => set_value('payment_swiftcode'),
		    'payment_owner' => set_value('payment_owner'),
		    'opos' => set_value('opos'),
		    'learner_birth_name' => set_value('learner_birth_name'),
		    'learner_native_country' => set_value('learner_native_country'),
		    'learner_citizenship' => set_value('learner_citizenship'),
		    'learner_drivers_id' => set_value('learner_drivers_id'),
		    'status' => set_value('status'),
		    'primary_email' => set_value('primary_email'),

		);
       // $this->load->view('student/student_mgmt_form', $data);

		$data['main_content'] = 'student/student_mgmt_form';
   		$data['classes'] = $this->Classes_model->get_all();
        $data['country'] = $this->Country_model->get_all();
		$data['title'] = 'Mentor-Manage student create';
		$this->load->view('includes/template', $data);  
    }
    
    public function create_action() 
    {
        $this->_rules();
        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
        	$dob = date("Y-m-d", strtotime($this->input->post('dob',TRUE)));
            $data = array(
				'username' => $this->input->post('username',TRUE),
				'password' => $this->input->post('password',TRUE),
				'email' => $this->input->post('email',TRUE),
				'instrutor_id' => $this->input->post('instrutor_id',TRUE),
				'branch_id' => $this->input->post('branch_id',TRUE),
				'address' => $this->input->post('address',TRUE),
				'city' => $this->input->post('city',TRUE),
				'postalcode' => $this->input->post('postalcode',TRUE),
				'state' => $this->input->post('state',TRUE),
				'country_id' => $this->input->post('country_id',TRUE),
				'photo' => $this->input->post('photo',TRUE),
				'first_name' => $this->input->post('first_name',TRUE),
				'surname' => $this->input->post('surname',TRUE),
				'abbreviation' => $this->input->post('abbreviation',TRUE),
				'dob' => $dob,
				'placeofbirth' => $this->input->post('placeofbirth',TRUE),
				'phone' => $this->input->post('phone',TRUE),
				'mobile' => $this->input->post('mobile',TRUE),
				'language' => $this->input->post('language',TRUE),
				'note' => $this->input->post('note',TRUE),
				'nationality' => $this->input->post('nationality',TRUE),
				'consentezb' => $this->input->post('consentezb',TRUE),
				'firstaidcourse' => $this->input->post('firstaidcourse',TRUE),
				'physical' => $this->input->post('physical',TRUE),
				'visiontest' => $this->input->post('visiontest',TRUE),
				'visualaid' => $this->input->post('visualaid',TRUE),
				'guardian_name' => $this->input->post('guardian_name',TRUE),
				'g_surname' => $this->input->post('g_surname',TRUE),
				'g_dob' => $this->input->post('g_dob',TRUE),
				'g_address' => $this->input->post('g_address',TRUE),
				'g_city' => $this->input->post('g_city',TRUE),
				'g_postalcode' => $this->input->post('g_postalcode',TRUE),
				'g_state' => $this->input->post('g_state',TRUE),
				'g_country_id' => $this->input->post('g_country_id',TRUE),
				'g_email' => $this->input->post('g_email',TRUE),
				'g_phone' => $this->input->post('g_phone',TRUE),
				'g_mobile' => $this->input->post('g_mobile',TRUE),
				'traning_allocatoion_type' => $this->input->post('traning_allocatoion_type',TRUE),
				'payment_debit' => $this->input->post('payment_debit',TRUE),
				'payment_dunning' => $this->input->post('payment_dunning',TRUE),
				'payment_dunning_level' => $this->input->post('payment_dunning_level',TRUE),
				'payment_bankcode' => $this->input->post('payment_bankcode',TRUE),
				'payment_acc_number' => $this->input->post('payment_acc_number',TRUE),
				'payment_iban' => $this->input->post('payment_iban',TRUE),
				'payment_swiftcode' => $this->input->post('payment_swiftcode',TRUE),
				'payment_owner' => $this->input->post('payment_owner',TRUE),
				'opos' => $this->input->post('opos',TRUE),
				'learner_birth_name' => $this->input->post('learner_birth_name',TRUE),
				'learner_native_country' => $this->input->post('learner_native_country',TRUE),
				'learner_citizenship' => $this->input->post('learner_citizenship',TRUE),
				'learner_drivers_id' => $this->input->post('learner_drivers_id',TRUE),
				'status' => $this->input->post('status',TRUE),
				'primary_email' => $this->input->post('primary_email',TRUE),
		    );
            $this->Student_model->insert($data);

			//Load email library
			$this->load->library('email');

	        $this->email->from('demo@inysol.com', 'admin');
	        $this->email->to($this->input->post('primary_email',TRUE)); 

	        $this->email->subject('Your Mentor/Student account has been created successfully');
	        $emaildata = array(
             	'name'=> $this->input->post('first_name',TRUE).' '. $this->input->post('surname',TRUE),
             	'username'=> $this->input->post('username',TRUE),
             	'password'=> $this->input->post('password',TRUE),
             	'url'=> ''
    	    );

	        $body = $this->load->view('emails/student_register.php',$emaildata,TRUE);
    		$this->email->message($body);  

			try{
	      		$result = $this->email->send();
			}catch(Exception $e){
				echo $e->getMessage();
			}

            $this->session->set_flashdata('message', '<span class="text-success">New Student has been added Successfully</span>');
            redirect(site_url('student'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Student_model->get_by_id($id);

        if ($row) {
        	$dob = date("d-m-Y", strtotime($row->dob));
            $data = array(
                'button' => 'Update',
                'action' => site_url('student/update_action'),
				'id' => set_value('id', $row->id),
				'username' => set_value('username', $row->username),
				'password' => set_value('password', $row->password),
				'email' => set_value('email', $row->email),
				'instrutor_id' => set_value('instrutor_id', $row->instrutor_id),
				'branch_id' => set_value('branch_id', $row->branch_id),
				'address' => set_value('address', $row->address),
				'city' => set_value('city', $row->city),
				'postalcode' => set_value('postalcode', $row->postalcode),
				'state' => set_value('state', $row->state),
				'country_id' => set_value('country_id', $row->country_id),
				'photo' => set_value('photo', $row->photo),
				'first_name' => set_value('first_name', $row->first_name),
				'surname' => set_value('surname', $row->surname),
				'abbreviation' => set_value('abbreviation', $row->abbreviation),
				'dob' => set_value('dob', $dob),
				'placeofbirth' => set_value('placeofbirth', $row->placeofbirth),
				'phone' => set_value('phone', $row->phone),
				'mobile' => set_value('mobile', $row->mobile),
				'language' => set_value('language', $row->language),
				'note' => set_value('note', $row->note),
				'nationality' => set_value('nationality', $row->nationality),
				'consentezb' => set_value('consentezb', $row->consentezb),
				'firstaidcourse' => set_value('firstaidcourse', $row->firstaidcourse),
				'physical' => set_value('physical', $row->physical),
				'visiontest' => set_value('visiontest', $row->visiontest),
				'visualaid' => set_value('visualaid', $row->visualaid),
				'guardian_name' => set_value('guardian_name', $row->guardian_name),
				'g_surname' => set_value('g_surname', $row->g_surname),
				'g_dob' => set_value('g_dob', $row->g_dob),
				'g_address' => set_value('g_address', $row->g_address),
				'g_city' => set_value('g_city', $row->g_city),
				'g_postalcode' => set_value('g_postalcode', $row->g_postalcode),
				'g_state' => set_value('g_state', $row->g_state),
				'g_country_id' => set_value('g_country_id', $row->g_country_id),
				'g_email' => set_value('g_email', $row->g_email),
				'g_phone' => set_value('g_phone', $row->g_phone),
				'g_mobile' => set_value('g_mobile', $row->g_mobile),
				'traning_allocatoion_type' => set_value('traning_allocatoion_type', $row->traning_allocatoion_type),
				'payment_debit' => set_value('payment_debit', $row->payment_debit),
				'payment_dunning' => set_value('payment_dunning', $row->payment_dunning),
				'payment_dunning_level' => set_value('payment_dunning_level', $row->payment_dunning_level),
				'payment_bankcode' => set_value('payment_bankcode', $row->payment_bankcode),
				'payment_acc_number' => set_value('payment_acc_number', $row->payment_acc_number),
				'payment_iban' => set_value('payment_iban', $row->payment_iban),
				'payment_swiftcode' => set_value('payment_swiftcode', $row->payment_swiftcode),
				'payment_owner' => set_value('payment_owner', $row->payment_owner),
				'opos' => set_value('opos', $row->opos),
				'learner_birth_name' => set_value('learner_birth_name', $row->learner_birth_name),
				'learner_native_country' => set_value('learner_native_country', $row->learner_native_country),
				'learner_citizenship' => set_value('learner_citizenship', $row->learner_citizenship),
				'learner_drivers_id' => set_value('learner_drivers_id', $row->learner_drivers_id),
				'status' => set_value('status', $row->status),
				'primary_email' => set_value('primary_email', $row->primary_email),
		    );

            //$this->load->view('student/student_mgmt_form', $data);
            $data['main_content'] = 'student/student_mgmt_form';
   			$data['classlist'] = $this->Classes_model->get_all();
   			$data['vehiclelist'] = $this->Vehicle_model->get_all();
        	$data['country'] = $this->Country_model->get_all();
   			$data['studservicemgmt'] = $this->Student_model->Studentservices();
   			$data['get_student_classes_all'] = $this->Student_model->Studentservices();


        	//Instrutor_classes_model
        	foreach($this->Student_model->get_student_classes_all($id) as $category)
			{
			    $classSelected[] = $category->id;
			}
        	$data['get_student_classes_all'] = $classSelected;

        	//Instrutor_branch_model     
        	foreach($this->Student_model->get_student_branch_all($id) as $category)
			{
			    $branchSelected[] = $category->id;
			}
        	$data['get_student_branch_all'] = $branchSelected;



   			$data['title'] = 'Mentor-Manage student update';
    		$this->load->view('includes/template', $data); 
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules('update');

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
        	$dob = date("Y-m-d", strtotime($this->input->post('dob',TRUE)));
            $data = array(
				'username' => $this->input->post('username',TRUE),
				'password' => $this->input->post('password',TRUE),
				'email' => $this->input->post('email',TRUE),
				'instrutor_id' => $this->input->post('instrutor_id',TRUE),
				'branch_id' => $this->input->post('branch_id',TRUE),
				'address' => $this->input->post('address',TRUE),
				'city' => $this->input->post('city',TRUE),
				'postalcode' => $this->input->post('postalcode',TRUE),
				'state' => $this->input->post('state',TRUE),
				'country_id' => $this->input->post('country_id',TRUE),
				'photo' => $this->input->post('photo',TRUE),
				'first_name' => $this->input->post('first_name',TRUE),
				'surname' => $this->input->post('surname',TRUE),
				'abbreviation' => $this->input->post('abbreviation',TRUE),
				'dob' => $dob,
				'placeofbirth' => $this->input->post('placeofbirth',TRUE),
				'phone' => $this->input->post('phone',TRUE),
				'mobile' => $this->input->post('mobile',TRUE),
				'language' => $this->input->post('language',TRUE),
				'note' => $this->input->post('note',TRUE),
				'nationality' => $this->input->post('nationality',TRUE),
				'consentezb' => $this->input->post('consentezb',TRUE),
				'firstaidcourse' => $this->input->post('firstaidcourse',TRUE),
				'physical' => $this->input->post('physical',TRUE),
				'visiontest' => $this->input->post('visiontest',TRUE),
				'visualaid' => $this->input->post('visualaid',TRUE),
				'guardian_name' => $this->input->post('guardian_name',TRUE),
				'g_surname' => $this->input->post('g_surname',TRUE),
				'g_dob' => $this->input->post('g_dob',TRUE),
				'g_address' => $this->input->post('g_address',TRUE),
				'g_city' => $this->input->post('g_city',TRUE),
				'g_postalcode' => $this->input->post('g_postalcode',TRUE),
				'g_state' => $this->input->post('g_state',TRUE),
				'g_country_id' => $this->input->post('g_country_id',TRUE),
				'g_email' => $this->input->post('g_email',TRUE),
				'g_phone' => $this->input->post('g_phone',TRUE),
				'g_mobile' => $this->input->post('g_mobile',TRUE),
				'traning_allocatoion_type' => $this->input->post('traning_allocatoion_type',TRUE),
				'payment_debit' => $this->input->post('payment_debit',TRUE),
				'payment_dunning' => $this->input->post('payment_dunning',TRUE),
				'payment_dunning_level' => $this->input->post('payment_dunning_level',TRUE),
				'payment_bankcode' => $this->input->post('payment_bankcode',TRUE),
				'payment_acc_number' => $this->input->post('payment_acc_number',TRUE),
				'payment_iban' => $this->input->post('payment_iban',TRUE),
				'payment_swiftcode' => $this->input->post('payment_swiftcode',TRUE),
				'payment_owner' => $this->input->post('payment_owner',TRUE),
				'opos' => $this->input->post('opos',TRUE),
				'learner_birth_name' => $this->input->post('learner_birth_name',TRUE),
				'learner_native_country' => $this->input->post('learner_native_country',TRUE),
				'learner_citizenship' => $this->input->post('learner_citizenship',TRUE),
				'learner_drivers_id' => implode(',', $this->input->post('learner_drivers_id',TRUE)),
				'status' => $this->input->post('status',TRUE),
				'primary_email' => $this->input->post('primary_email',TRUE),
		    );
		    /*echo "<pre>";
            print_r($this->input->post());*/
            $this->Student_model->update($this->input->post('id', TRUE), $data);

            //Student_classes_mapping_mgmt - save
            $ICData = array();
            //print_r($this->input->post());
            if($this->input->post('classes_id',true)){
			    foreach ($this->input->post('classes_id',true) as $key => $value) {
			    	$ICData1 = array(
	            				'student_id'=>$this->input->post('id',true),
	            				'class_id'=>$value
	            			);
			    	array_push($ICData, $ICData1);
			    }
			    $this->Student_model->student_classes_insert_batch($ICData);
			}
            $this->session->set_flashdata('message', '<span class="text-success">Student has been updated Successfully</span>');
            redirect(site_url('student'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Student_model->get_by_id($id);

        if ($row) {
            //$this->Student_model->delete($id);

            $data = array(
				'status' => 'Inactive',
			);
            $this->Student_model->update($id, $data);
            $this->session->set_flashdata('message', '<span class="text-success">Student has been Deleted Successfully</span>');
            redirect(site_url('student'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student'));
        }
    }

    public function active($id) 
    {
        $row = $this->Student_model->get_by_id($id);

        if ($row) {
            //$this->Users_model->delete($id);

            $data = array(
				'status' => 'Active',
			);
            $this->Student_model->update($id, $data);
            $this->session->set_flashdata('message', '<span class="text-success">Student has been Activated Successfully</span>');
            redirect(site_url('student'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('student'));
        }
    }

    public function _rules($where='') 
    {
		if(!$where)	$this->form_validation->set_rules('primary_email', 'Email', 'required|valid_email|is_unique[student_mgmt.primary_email]');
		$this->form_validation->set_rules('first_name', 'first name', 'trim|required');
		$this->form_validation->set_rules('surname', 'surname', 'trim|required');
		/*$this->form_validation->set_rules('username', 'username', 'trim|required');
		$this->form_validation->set_rules('password', 'password', 'trim|required');
		$this->form_validation->set_rules('email', 'email', 'trim|required');
		$this->form_validation->set_rules('instrutor_id', 'instrutor id', 'trim|required');
		$this->form_validation->set_rules('branch_id', 'branch id', 'trim|required');
		$this->form_validation->set_rules('address', 'address', 'trim|required');
		$this->form_validation->set_rules('state', 'state', 'trim|required');
		$this->form_validation->set_rules('country_id', 'country id', 'trim|required');
		$this->form_validation->set_rules('photo', 'photo', 'trim|required');
		$this->form_validation->set_rules('first_name', 'first name', 'trim|required');
		$this->form_validation->set_rules('surname', 'surname', 'trim|required');
		$this->form_validation->set_rules('dob', 'dob', 'trim|required');
		$this->form_validation->set_rules('placeofbirth', 'placeofbirth', 'trim|required');
		$this->form_validation->set_rules('phone', 'phone', 'trim|required');
		$this->form_validation->set_rules('mobile', 'mobile', 'trim|required');
		$this->form_validation->set_rules('language', 'language', 'trim|required');
		$this->form_validation->set_rules('note', 'note', 'trim|required');
		$this->form_validation->set_rules('nationality', 'nationality', 'trim|required');
		$this->form_validation->set_rules('consentezb', 'consentezb', 'trim|required');
		$this->form_validation->set_rules('firstaidcourse', 'firstaidcourse', 'trim|required');
		$this->form_validation->set_rules('physical', 'physical', 'trim|required');
		$this->form_validation->set_rules('visiontest', 'visiontest', 'trim|required');
		$this->form_validation->set_rules('visualaid', 'visualaid', 'trim|required');
		$this->form_validation->set_rules('guardian_name', 'guardian name', 'trim|required');
		$this->form_validation->set_rules('g_surname', 'g surname', 'trim|required');
		$this->form_validation->set_rules('g_dob', 'g dob', 'trim|required');
		$this->form_validation->set_rules('g_address', 'g address', 'trim|required');
		$this->form_validation->set_rules('g_city', 'g city', 'trim|required');
		$this->form_validation->set_rules('g_postalcode', 'g postalcode', 'trim|required');
		$this->form_validation->set_rules('g_state', 'g state', 'trim|required');
		$this->form_validation->set_rules('g_country_id', 'g country id', 'trim|required');
		$this->form_validation->set_rules('g_email', 'g email', 'trim|required');
		$this->form_validation->set_rules('g_phone', 'g phone', 'trim|required');
		$this->form_validation->set_rules('traning_allocatoion_type', 'traning allocatoion type', 'trim|required');
		$this->form_validation->set_rules('payment_debit', 'payment debit', 'trim|required');
		$this->form_validation->set_rules('payment_dunning', 'payment dunning', 'trim|required');
		$this->form_validation->set_rules('payment_dunning_level', 'payment dunning level', 'trim|required');
		$this->form_validation->set_rules('payment_bankcode', 'payment bankcode', 'trim|required');
		$this->form_validation->set_rules('payment_acc_number', 'payment acc number', 'trim|required');
		$this->form_validation->set_rules('payment_iban', 'payment iban', 'trim|required');
		$this->form_validation->set_rules('payment_swiftcode', 'payment swiftcode', 'trim|required');
		$this->form_validation->set_rules('payment_owner', 'payment owner', 'trim|required');
		$this->form_validation->set_rules('opos', 'opos', 'trim|required');
		$this->form_validation->set_rules('status', 'status', 'trim|required');

		$this->form_validation->set_rules('id', 'id', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');*/
    }

}

/* End of file Student.php */
/* Location: ./application/controllers/Student.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2017-12-20 07:37:49 */
/* http://harviacode.com */
