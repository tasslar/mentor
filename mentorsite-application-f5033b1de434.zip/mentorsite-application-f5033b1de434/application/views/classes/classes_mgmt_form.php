
<h2 style="margin-top:0px">Classes_mgmt <?php echo $button ?></h2>
<div class="tab-pill">
	<form action="<?php echo $action; ?>" method="post">
	
	<div class="container">
		<div class="create_new">
			<div class="row">
				<div class="col-lg-12">
					<div class="col-lg-7">
						<h5><i class="fa fa-arrow-right"></i> Mein Konto</h5>
					</div>
					<div class="col-lg-4 text-right">						
						<button type="submit" class="btn btn-success"><i class="fa fa-hdd-o"></i> <?php echo $button ?></button> 
					</div>
                    <div class="col-lg-1">
						<a href="<?php echo site_url('classes') ?>" class="btn btn-danger"><i class="fa fa-ban"></i> Cancel</a>
					</div>
				</div>
            </div>
		</div>
	
		<div class="section1">
			<div class="container">
				<div class="row">
					<br>
					<ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#home">Allgemein</a></li>
<!--
						<li><a data-toggle="tab" href="#menu1">Konteneinstellungen</a></li>
						<li><a data-toggle="tab" href="#menu2">Rechteverwaltung</a></li>
-->
					</ul>
					<br>
					<div class="tab-content">
						<div id="home" class="tab-pane fade in active">
							<div class="section1">
								<div class="container">
									<div class="row">
									   <div role="tabpanel">
										  <div class="col-sm-9">
											 <div class="tab-content">
												<div role="tabpanel" class="tab-pane active" id="tab1">
												   <div class="row">
													  <div class="col-lg-12">
														 <div class="general">
															<p>Allgemein</p>
															<div class="form-horizontal">
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="surname">Anrede/Titel:</label>
																  <div class="col-sm-4">
																	 <input type="text" class="form-control" id="surname" name="surname" value="<?php echo $surname; ?>" >
																	 <?php echo form_error('surname') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="designation">Vorname:</label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="designation" name="designation" value="<?php echo $designation; ?>" > 
																	 <?php echo form_error('designation') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="tax">Nachname: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="tax" name="tax" value="<?php echo $tax; ?>">
																	 <?php echo form_error('tax') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="description">Kürzel: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="description" name="description" value="<?php echo $description; ?>">
																	 <?php echo form_error('description') ?>
																  </div>
															   </div>
															</div>
														 </div>
													  </div>
												   </div>
												</div>
									   </div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	</form>
	
</div>
