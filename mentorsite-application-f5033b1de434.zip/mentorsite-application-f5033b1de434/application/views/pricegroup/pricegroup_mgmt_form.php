
<h2 style="margin-top:0px">Pricegroup <?php echo $button ?></h2>
<div class="tab-pill">
	<form action="<?php echo $action; ?>" method="post">
		<div class="container">
			<div class="create_new">
				<div class="row">
					<div class="col-lg-12">
						<div class="col-lg-7">
							<h5><i class="fa fa-arrow-right"></i> Mein Konto</h5>
						</div>
						<div class="col-lg-4 text-right">						
							<button type="submit" class="btn btn-success"><i class="fa fa-hdd-o"></i> <?php echo $button ?></button> 
						</div>
						<div class="col-lg-1">
							<a href="<?php echo site_url('pricegroup') ?>" class="btn btn-danger"><i class="fa fa-ban"></i> Cancel</a>
						</div>
					</div>
				</div>
			</div>
			<div class="section1">
				<div class="container">
					<div class="row">
						<div class="col-lg-6">
							<div class="form-horizontal general">
								<div class="form-group ">
									<label for="char">Name <?php echo form_error('name') ?></label>
									<input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?php echo $name; ?>" />
								</div>
								<div class="form-group">
									<label for="description">Description <?php echo form_error('description') ?></label>
									<textarea class="form-control" rows="3" name="description" id="description" placeholder="Description"><?php echo $description; ?></textarea>
								</div>
								<input type="hidden" name="id" value="<?php echo $id; ?>" /> 
								</div>
						</div>
						<div class="col-lg-6 ">
							<div class="form-horizontal general">
								<div class="form-group">
									<div class="col-lg-3">
									   <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#classesModel">Classes Selection </button>
									   <!-- Modal -->
									   <div class="modal fade" id="classesModel" role="dialog">
										  <div class="modal-dialog modal-lg">
											 <div class="modal-content">
												<div class="modal-header">
												   <button type="button" class="close" data-dismiss="modal">&times;</button>
												   <h4 class="modal-title">Classes
												   </h4>
												</div>
												<div class="modal-body">
												   <p>Select your class</p>
													<table class="table table-bordered" id="table-branch-class" style="margin-bottom: 10px">
														<thead>
															 <tr>
																 <th></th>
																<th>Surname</th>
																<th>Designation</th>
																<th>Tax</th>
																<th>Description</th>
															</tr>
														</thead>
														<tbody>
														</tbody>
													</table>
												</div>
												<div class="modal-footer">
												   <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												   <button type="button" class="btn btn-default classSubmit" data-dismiss="modal">Submit</button>
												</div>
											 </div>
											
										  </div>
										
									   </div>
									
									
									</div>
									 <div class="col-md-12">
										<div id="selected-class"></div>
										<input type="hidden" class="form-control" id="classid" name="classid" value="<?php echo $classid; ?>">
									</div>
								 </div>
							</div>
						</div>
				</div>
				</div>
			</div>
			</div>
		</div>
	</form>
</div>
<script type="text/javascript">
jQuery(document).ready(function() {
		 
	var table;
	var arrA = [];
	clsids="<?php echo $classid; ?>";
	selectedclasses   = clsids.split(',');

		//datatables
		table = jQuery('#table-branch-class').DataTable({ 
	 
			"processing": true, //Feature control the processing indicator.
			"serverSide": true, //Feature control DataTables' server-side processing mode.
			"order": [], //Initial no order.
	 
			// Load data for the table's content from an Ajax source
			"ajax": {
				"url": "<?php echo site_url('branches/class_ajax_list')?>",
				"type": "POST"
			},
			
			//Set column definition initialisation properties.
			"columnDefs": [
			{ 
				"targets": [ 0 ], //first column / numbering column
				"orderable": false, //set not orderable
				 'render': function (data, type, full, meta , selectedclasses){
					
				return '<input type="checkbox" name="classsid[]" id="selectclass-'+data+'" value="' 
					+ $('<div/>').text(data).html() + '">';
				}
			},
			],
			"rowCallback": function(row, data, dataIndex){
			 // Get row ID
			 var rowId = data[0]++;
			
			 // If row ID is in the list of selected row IDs
			 if(rowId==selectedclasses[rowId]){
				jQuery(row).find('#selectclass-'+arrA).prop('checked', true);
				//jQuery(row).addClass('selected');
			 }
		  }
	 
		});
	
		
		jQuery(".classSubmit").click(function(){
			var checkboxValues = jQuery('#classesModel input:checkbox:checked').map(function() { return $(this).val(); } ).get().join();
			
			jQuery.ajax({
				url : "<?php echo site_url('branches/getclasses') ?>",
				type: "POST",
				data : {id:checkboxValues},
				success: function(response, textStatus, jqXHR)
				{
					var json_obj = $.parseJSON(response);
						 var output = "<h3> Selected Classes </h3>";
						  output += "<ul>";
							var id ='';
						  for (i=0; i < json_obj.length; i++)
						  {
							var name = json_obj[i];
							output += "<li>" + name.surname +  "</li>";
							id += name.id+",";
						  }
						  output += "</ul>";
						  $('#selected-class').html(output);
						   id = id.slice(0, -1);
						  jQuery('#classid').val(id);
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
			 
				}
			});
		});
	});
</script>

