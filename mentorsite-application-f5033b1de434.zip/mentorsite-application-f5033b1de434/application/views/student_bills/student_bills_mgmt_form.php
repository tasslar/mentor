<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Student_bills_mgmt <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Student Id <?php echo form_error('student_id') ?></label>
            <input type="text" class="form-control" name="student_id" id="student_id" placeholder="Student Id" value="<?php echo $student_id; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Invoice Date <?php echo form_error('invoice_date') ?></label>
            <input type="text" class="form-control" name="invoice_date" id="invoice_date" placeholder="Invoice Date" value="<?php echo $invoice_date; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Bill No <?php echo form_error('bill_no') ?></label>
            <input type="text" class="form-control" name="bill_no" id="bill_no" placeholder="Bill No" value="<?php echo $bill_no; ?>" />
        </div>
	    <div class="form-group">
            <label for="mediumint">Amount <?php echo form_error('amount') ?></label>
            <input type="text" class="form-control" name="amount" id="amount" placeholder="Amount" value="<?php echo $amount; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Dude Date <?php echo form_error('dude_date') ?></label>
            <input type="text" class="form-control" name="dude_date" id="dude_date" placeholder="Dude Date" value="<?php echo $dude_date; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('student_bills') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>