<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Tax_mgmt <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="char">Keyy <?php echo form_error('keyy') ?></label>
            <input type="text" class="form-control" name="keyy" id="keyy" placeholder="Keyy" value="<?php echo $keyy; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Taxrate <?php echo form_error('taxrate') ?></label>
            <input type="text" class="form-control" name="taxrate" id="taxrate" placeholder="Taxrate" value="<?php echo $taxrate; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Validfrom <?php echo form_error('validfrom') ?></label>
            <input type="text" class="form-control" name="validfrom" id="validfrom" placeholder="Validfrom" value="<?php echo $validfrom; ?>" />
        </div>
	    <div class="form-group">
            <label for="designation">Designation <?php echo form_error('designation') ?></label>
            <textarea class="form-control" rows="3" name="designation" id="designation" placeholder="Designation"><?php echo $designation; ?></textarea>
        </div>
	    <div class="form-group">
            <label for="comments">Comments <?php echo form_error('comments') ?></label>
            <textarea class="form-control" rows="3" name="comments" id="comments" placeholder="Comments"><?php echo $comments; ?></textarea>
        </div>
	    <div class="form-group">
            <label for="enum">Status <?php echo form_error('status') ?></label>
            <input type="text" class="form-control" name="status" id="status" placeholder="Status" value="<?php echo $status; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('tax') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>