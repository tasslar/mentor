<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Vehicle_mgmt Read</h2>
        <table class="table">
	    <tr><td>Vehicletype Id</td><td><?php echo $vehicletype_id; ?></td></tr>
	    <tr><td>Photo</td><td><?php echo $photo; ?></td></tr>
	    <tr><td>Pricegroup Id</td><td><?php echo $pricegroup_id; ?></td></tr>
	    <tr><td>Description</td><td><?php echo $description; ?></td></tr>
	    <tr><td>License Plate</td><td><?php echo $license_plate; ?></td></tr>
	    <tr><td>Designation</td><td><?php echo $designation; ?></td></tr>
	    <tr><td>Manufauture</td><td><?php echo $manufauture; ?></td></tr>
	    <tr><td>Model</td><td><?php echo $model; ?></td></tr>
	    <tr><td>Keynumber</td><td><?php echo $keynumber; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('vehicle') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>