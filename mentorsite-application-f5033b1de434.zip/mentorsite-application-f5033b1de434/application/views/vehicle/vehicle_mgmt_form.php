<div class="tab-pill vehicle">
	<form action="<?php echo $action; ?>" method="post">
	<div class="container">
		<div class="create_new">
			<div class="row">
				<div class="col-lg-12">
					<div class="col-lg-2">
						<h5><i class="fa fa-arrow-right"></i> Vehicles</h5>
					</div>
					<div class="col-lg-7">
						 <?php echo form_error('type') ?>
						 <?php echo form_error('designation') ?>
						 <div style="margin-top: 8px" id="message">
							<?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
						</div>
					</div>
					<div class="col-lg-3 text-right navigation-btns">	
						<ul>				
						<li>						
							<button type="submit" class="btn btn-success"><i class="fa fa-hdd-o"></i> <?php echo $button ?></button> 
						</li>
						<li class="text-right"><a href="<?php echo site_url('vehicle') ?>" class="btn btn-danger"><i class="fa fa-ban"></i> Cancel</a></li>
						</ul>
					</div>
				</div>
            </div>
		</div>
		<div class="section1">
			<div class="container">
				<div class="row">
					<br>
					<ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#general">General</a></li>
						<li><a data-toggle="tab" href="#details">Details</a></li>
						<li><a data-toggle="tab" href="#adminstration">Administration</a></li>
						<li class="disabled"><a href="#logbook">Logbook</a></li>
						<li class="disabled"><a href="#event">Events</a></li>
					</ul>
					<br>
				<div class="tab-content">
						<div id="general" class="tab-pane fade in active">
							<div class="section1">
								<div class="container">
									<div class="row">
									   <div role="tabpanel">
										  <div class="col-sm-9">
											 <div class="tab-content">
												<div role="tabpanel" class="tab-pane active" id="tab1">
												   <div class="row">
													  <div class="col-lg-12">
														 <div class="general">
															<p>General Details</p>
															<div class="form-horizontal">
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="type">Type:</label>
																  <div class="col-sm-4">
																	 <select class="form-control" name="type">
																		<option>sir</option>
																		<option>Mrs</option>
																	 </select>
																  </div>
																  <div class="col-md--2">
																	<span style="color:#999">ID (will be generated automatically)</span>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="lplate">License plate *</label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="lplate" name="lplate" value="" required>
																	<?php echo form_error('lplate') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="designation">Designation: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="designation" name="designation" value="" required>
																	<?php echo form_error('designation') ?>
																  </div>
															   </div>
															   <div class="form-group">
																   <label class="control-label col-sm-2" for="price_group">Price Group: </label>
																    <div class="col-sm-6"> 
																   <select class="form-control" name="price_group" >
																		<option>sir</option>
																		<option>Mrs</option>
																	 </select>
																	  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="manufacturer">Manufacturer: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="manufacturer" name="manufacturer" value="">
																	 <?php echo form_error('manufacturer') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="model">Model: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="model" name="model" value="">
																	 <?php echo form_error('model') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="key_number">Key Number: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="key_number" name="key_number" value="">
																	 <?php echo form_error('key_number') ?>
																  </div>
															   </div>
															    <div class="form-group">
																  <label class="control-label col-sm-2" for="description">Description: </label>
																  <div class="col-sm-6"> 
																	 <textarea type="text" class="form-control" id="description" name="description" value="">
																	 <?php echo form_error('description') ?>
																	 </textarea>
																  </div>
															   </div>
															</div>
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane" id="tab2">
												   <div class="col-lg-12">
													  <div class="image">
														 <div class="row">
															<p>Images</p>
															<div>
															   <div class="col-sm-6"> 
																  <span></span><input type="file" multiple name="photo" class="form-control"/>
															   </div>
															   <div class="col-sm-6 text-center"> 
																  <br>
																  <img src="images/im.png" width="55%">
															   </div>
																<?php echo form_error('photo') ?>
															</div>
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane" id="tab3">
												   <div class="col-lg-12">
													  <div class="image">
														 <div class="row">
															<p>Branches</p>
														   <div class="col-lg-6">
																<?php foreach($branch_details as $details):?>
																<div class="form-check">
																<label>
																	<input type="checkbox" name="check" value="<?php echo $details['branch_id'];?>" checked> <span class="label-text"><?php echo $details['branch_name'];?></span>
																</label>
																</div>
																<?php endforeach;?>
															</div>
															  <div class="col-lg-6">
																 <div class="form-group">
																  <label class="control-label col-sm-3" for="instructor">Instructor: </label>
																  <div class="col-sm-9"> 
																	<?php  
																		echo form_input('name','','id="instructor"');  
																	?>  
																	<ul>  
																		<div class="well" id="result"></div>  
																	</ul>  
																	 <input type="text" class="form-control" id="instructor" name="instructor" value="">
																	 <?php echo form_error('instructor') ?>
																	 </input>
																  </div>
															   </div> 
															  </div>
														 </div>
													  </div>
												   </div>	   
											   </div>
											</div>
										 </div>
											<div class="col-sm-3">
											 <ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
												<li role="presentation" class="brand-nav active"><a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab">General</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Image</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">Branches & Instructors</a></li>
												</ul>
										  </div>
									  </div>
								   </div>
								</div>
							</div>
						
							
					   </div>
						<div id="details" class="tab-pane fade">
							<div class="row">
								<div class="col-lg-5">
									<div class="account">
										<div class="form-horizontal">
											<div class="form-group">
											  <label class="control-label col-sm-2" for="type">Fuel:</label>
											  <div class="col-sm-4">
												 <select class="form-control" name="fuel">
													<option value="">Select fuel</option>
													<option value="1">Petrol</option>
													<option value="2">Diesel</option>
													<option value="3">Natural Gas</option>
													<option value="4">LPG</option>
													<option value="5">Electric</option>
												 </select>
											  </div>
										   </div>
											 <div class="form-group">
											  <label class="control-label col-sm-2" for="power">Power: </label>
											  <div class="col-sm-2"> 
												 <input type="text" class="form-control" id="powerk" name="powerk" value="">
												 <?php echo form_error('power') ?>
											  </div>
											  <div class="col-md--2">
												<span style="color:#999">ID</span>
											  </div>
											  <div class="col-sm-2"> 
												<input type="text" class="form-control" id="powerps" name="powerps" value="">
												 <?php echo form_error('power') ?>
											  </div>
											  <div class="col-md--2">
												<span style="color:#999">ID </span>
											  </div>
										   </div>
											<div class="form-group">
																  <label class="control-label col-sm-2" for="capacity">Capacity: </label>
																  <div class="col-sm-7"> 
																	 <input type="text" class="form-control" id="capacity" name="capacity" value="">
																	 																  </div>
															   </div>
										  <div class="form-group">
																   <label class="control-label col-sm-2" for="emission_category">Emission category: </label>
																    <div class="col-sm-7"> 
																   <select class="form-control" name="emission_category">
																		<option value="">Select pollutant class</option>
																		<option value="1">Euro 1</option>
																		<option value="2">Euro 2</option>
																		<option value="3">Euro 3</option>
																		<option value="4">Euro 4</option>
																		<option value="5">Euro 5</option>
																		<option value="6">Euro 6</option>
																		<option value="7">Euro 7</option>
																	 </select>
																	  </div>
															   </div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="gearbox">Gearbox: </label>
											<div class="col-sm-7"> 
										   <select class="form-control" name="gearbox">
												<option value="">Select gearbox type</option>
												<option value="1">automatic</option>
												<option value="2">manual gearshift</option>																		
											 </select>
											  </div>
									   </div>
										<div class="form-group">
											   <label class="control-label col-sm-2" for="axes">Axes: </label>
												<div class="col-sm-7"> 
											   <select class="form-control" name="axes">
													<option value="">Select axes</option>
													<option value="1">2</option>
													<option value="2">3</option>
													<option value="3">4</option>
													<option value="4">5</option>																		
												 </select>
												  </div>
										   </div>
										<div class="form-group">
											   <label class="control-label col-sm-2" for="doors">Doors: </label>
												<div class="col-sm-7"> 
											   <select class="form-control" name="doors">
													<option value="">Choose doors</option>
													<option value="1">2</option>
													<option value="2">3</option>
													<option value="3">4</option>
													<option value="4">5</option>																		
												 </select>
												  </div>
										   </div>
										
										</div>
									</div>
								</div>
								<div class="col-lg-5">
									<div class="account">
										<div class="form-horizontal">
											<div class="form-group">
											  <label class="control-label col-sm-3" for="year">Year: </label>
											  <div class="col-sm-6"> 
												 <input type="text" class="form-control" id="year" name="year" value="">
												 <?php echo form_error('year') ?>
											  </div>
										   </div>														  
										 <div class="form-group">
										  <label class="control-label col-sm-3" for="construction_year">Construction year: </label>
										  <div class="col-sm-6"> 
											 <input type="text" class="form-control" id="construction_year" name="construction_year" value="">
											 <?php echo form_error('construction_year') ?>
										  </div>
										</div>
									   <div class="form-group">
										  <label class="control-label col-sm-3" for="next_hu">Next HU: </label>
										  <div class="col-sm-6"> 
											 <input type="text" class="form-control" id="next_hu" name="next_hu" value="">
											 <?php echo form_error('next_hu') ?>
										  </div>
									   </div>
										<div class="form-group">
										  <label class="control-label col-sm-3" for="next_inspection_date">Next inspection date: </label>
										  <div class="col-sm-6"> 
											 <input type="text" class="form-control" id="next_inspection_date" name="next_inspection_date" value="">
											 <?php echo form_error('next_inspection_date') ?>
										  </div>
									   </div>
										<div class="form-group">
										  <label class="control-label col-sm-3" for="or_at">Or at: </label>										 
									   </div>
										<div class="form-group">
										  <label class="control-label col-sm-3" for="next_inspection_in_km">Next inspection in km: </label>
										  <div class="col-sm-6"> 
											 <input type="text" class="form-control" id="next_inspection_in_km" name="next_inspection_in_km" value="">
											 <?php echo form_error('next_inspection_in_km') ?>
										  </div>
									   </div>
										<div class="form-group">
											   <label class="control-label col-sm-3" for="memory">Memory: </label>
												<div class="col-sm-7"> 
											   <select class="form-control" name="memory">
													<option value="">Select reminder</option>
													<option value="1">No</option>
													<option value="2">Message</option>
													<option value="3">PopUP</option>																													
												 </select>
												  </div>
										   </div>
										</div>
									</div>
								</div>
							
							</div>
						</div>
						<div id="adminstration" class="tab-pane fade">
							<div class="row">
								<div class="col-lg-6">
									<div class="account">
										<div class="form-horizontal">
									<div class="form-group">
									   <label class="control-label col-sm-4" for="financing">Financing: </label>
										<div class="col-sm-7"> 
									   <select class="form-control" name="financing">											
											<option value="1">leasing</option>
											<option value="2">loan</option>
											<option value="3">bar</option>											
										 </select>
										  </div>
								   </div>
								<div class="form-group">
								  <label class="control-label col-sm-4" for="lessor">Lessor: </label>
								  <div class="col-sm-7"> 
									 <input type="text" class="form-control" id="lessor" name="lessor" value="">
																									  </div>
							   </div>
								<div class="form-group">
								  <label class="control-label col-sm-4" for="contract">Contract#: </label>
								  <div class="col-sm-7"> 
									 <input type="text" class="form-control" id="contract" name="contract" value="">
																									  </div>
							   </div>
							   <div class="form-group">
								  <label class="control-label col-sm-4" for="total_vehicle_price">Total vehicle price: </label>
								  <div class="col-sm-4"> 
									 <input type="text" class="form-control" id="total_vehicle_price" name="total_vehicle_price" value="">
																				 
								  <span>€  </span>
								
								
								  </div>
								  <div class="col-sm-3"> 
									 <select class="form-control" name="total_vehicle_price">											
											<option value="1">VAT included.</option>
											<option value="2">excl. VAT</option>																
										 </select>
									  </div>
								  
										   </div>
								 <div class="form-group">
								  <label class="control-label col-sm-4" for="mietsonderzahlung">Mietsonderzahlung </label>
								  <div class="col-sm-4"> 
									 <input type="text" class="form-control" id="mietsonderzahlung" name="mietsonderzahlung" value="">
																				 
								  <span>€  </span>
								
								
								  </div>
								  <div class="col-sm-3"> 
									 <select class="form-control" name="mietsonderzahlung">											
											<option value="1">VAT included.</option>
											<option value="2">excl. VAT</option>																
										 </select>
									  </div>
								  
										   </div>
								
								<div class="form-group">
								  <label class="control-label col-sm-4" for="first_rate">First rate: </label>
								  <div class="col-sm-7"> 
									 <input type="text" class="form-control" id="first_rate" name="first_rate" value="">
																									  </div>
							   </div>
							<div class="form-group">
								  <label class="control-label col-sm-4" for="last_installment">Last installment: </label>
								  <div class="col-sm-7"> 
									 <input type="text" class="form-control" id="last_installment" name="last_installment" value="">
																									  </div>
							   </div>
							<div class="form-group">
								  <label class="control-label col-sm-4" for="running_time">Running time: </label>
								  <div class="col-sm-7"> 
									 <input type="text" class="form-control" id="running_time" name="running_time" value="">
									 <span>months</span>
																									  </div>
							   </div>
							<div class="form-group">
								  <label class="control-label col-sm-4" for="mileage">Mileage pa: </label>
								  <div class="col-sm-7"> 
									 <input type="text" class="form-control" id="mileage" name="mileage" value="">
									 <span>km</span>
																									  </div>
							   </div>
							
							
							<div class="form-group">
								  <label class="control-label col-sm-4" for="rest">Rest: </label>
								  <div class="col-sm-7"> 
									 <input type="text" class="form-control" id="rest" name="rest" value="">
																									  </div>
							   </div>
							<div class="form-group">
								  <label class="control-label col-sm-4" for="leasing_rate_pm">Leasing rate pme: </label>
								  <div class="input"> 
									 <input type="text" class="form-control" id="leasing_rate_pm" name="leasing_rate_pm" value="">
																				 
								  <span>€  </span>
								
								  </div>
								  <div class="col-sm-3"> 
									 <select class="form-control" name="leasing_rate_pm">											
											<option value="1">VAT included.</option>
											<option value="2">excl. VAT</option>																
										 </select>
									  </div>
								  
										   </div>
								
							
							</div></div></div>
							<div class="col-lg-6">
								<div class="account">
										<div class="form-horizontal">
											<div class="form-group">
									  <label class="control-label col-sm-4" for="date_of_purchase">Date of purchase: </label>
									  <div class="col-sm-7"> 
										 <input type="text" class="form-control" id="date_of_purchase" name="date_of_purchase" value="">
																										  </div>
								   </div>
								   <div class="form-group">
									  <label class="control-label col-sm-4" for="date_of_approval">Date of approval: </label>
									  <div class="col-sm-7"> 
										 <input type="text" class="form-control" id="date_of_approval" name="date_of_approval" value="">
																										  </div>
								   </div>
											<div class="form-group">
									  <label class="control-label col-sm-4" for="gross_list_price">Gross List Price: </label>
									  <div class="col-sm-7"> 
										 <input type="text" class="form-control" id="gross_list_price" name="gross_list_price" value="">
										 
																										  </div>
								   </div>
								<div class="form-group">
									  <label class="control-label col-sm-4" for="amount_car_tax">Amount car tax: </label>
									  <div class="col-sm-7"> 
										 <input type="text" class="form-control" id="amount_car_tax" name="amount_car_tax" value="">
										 <font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> €
											</font></font>
																										  </div>
								   </div>
								
								</div></div></div>
							
							</div>
						</div>
					</div>
				
			<input type="hidden" name="id" value="<?php echo $id; ?>" />
	</form>
 </div>

<style>
<style>  
     
            .ui-menu {  
                list-style:none;  
                padding: 2px;  
                margin: 0;  
                display:block;  
            }  
            .ui-menu .ui-menu {  
                margin-top: -3px;  
            }  
            .ui-menu .ui-menu-item {  
                margin:0;  
                padding: 0;  
                zoom: 1;  
                float: left;  
                clear: left;  
                width: 100%;  
                font-size:80%;  
            }  
            .ui-menu .ui-menu-item a {  
                text-decoration:none;  
                display:block;  
                padding:.2em .4em;  
                line-height:1.5;  
                zoom:1;  
            }  
            .ui-menu .ui-menu-item a.ui-state-hover,  
            .ui-menu .ui-menu-item a.ui-state-active {  
                font-weight: normal;  
                margin: -1px;  
            }  
        </style>  
</style>
