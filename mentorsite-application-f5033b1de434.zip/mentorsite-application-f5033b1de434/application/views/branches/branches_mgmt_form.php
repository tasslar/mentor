<h2 style="margin-top:0px">Users_mgmt <?php echo $button ?></h2>
<div class="tab-pill">
	
	<form action="<?php echo $action; ?>" method="post">
	
	<div class="container">
		<div class="create_new">
			<div class="row">
				<div class="col-lg-12">
					<div class="col-lg-2">
						<h5><i class="fa fa-arrow-right"></i> Branches</h5>
					</div>
					<div class="col-lg-7">
						 <?php //echo form_error('name') ?>
						 <?php //echo form_error('rule') ?>
						 <?php //echo form_error('primary_email') ?>
						 <div style="margin-top: 8px" id="message">
							<?php echo 'uyfgewfgweuyfewgwyfu'.$this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
						</div>
					</div>
					<div class="col-lg-3 text-right navigation-btns">	
						<ul>				
						<li><button type="submit" class="btn btn-success"><i class="fa fa-hdd-o"></i> <?php echo $button ?></button></li> 
						
						<li><a href="<?php echo site_url('branches') ?>" class="btn btn-danger"><i class="fa fa-ban"></i> Cancel</a></li>
						</ul>
					</div>
				</div>
            </div>
		</div>
	
		<div class="section1">
			<div class="container">
				<div class="row">
					<br>
					<ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#home">General</a></li>
						<li><a data-toggle="tab" href="#menu1">Contact Details</a></li>
						<li><a data-toggle="tab" href="#menu2">Training Classes</a></li>
					</ul>
					<br>
					<div class="tab-content">
						<div id="home" class="tab-pane fade in active">
							<div class="section1">
								<div class="container">
									<div class="row">
									   <div role="tabpanel">
										  <div class="col-sm-9">
											 <div class="tab-content">
												<div role="tabpanel" class="tab-pane active" id="tab1">
												   <div class="row">
													  <div class="col-lg-12">
														 <div class="general">
															<p>General Details</p>
															<div class="form-horizontal">
															   <div class="form-group hide">
																  <label class="control-label col-sm-2" for="name1">General Details:</label>
																  <div class="col-sm-2">
																	 <select class="form-control">
																		<option>sir</option>
																		<option>Mrs</option>
																	 </select>
																  </div>
																  <div class="col-sm-4">
																	 <input type="text" class="form-control" id="name1" >
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="name">Name:</label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" > 
																	 <?php echo form_error('name') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="address">Street and house number: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="address" name="address" value="<?php echo $address; ?>">
																	 <?php echo form_error('address') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="pincode">Postal code: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="pincode" name="pincode" value="<?php echo $pincode; ?>">
																	 <?php echo form_error('pincode') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="city">City: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="city" name="city" value="<?php echo $city; ?>">
																	 <?php echo form_error('city') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="state">Federal State: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="state" name="state" value="<?php echo $state; ?>">
																	 <?php echo form_error('state') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="country">Country: </label>
																  <div class="col-sm-6"> 
																	<select name="country" class="form-control">
																	 <option value="2">Germany</option>
																  </select> <?php echo form_error('country') ?>
																  </div>
															   </div>

															
															</div>
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane" id="tab2">
												   <div class="col-lg-12">
													  <div class="image">
														 <div class="row">
															<p>Bild</p>
															<div>
															   <div class="col-sm-6"> 
																  <span></span><input type="file" multiple name="photo" class="form-control"/>
															   </div>
															   <div class="col-sm-6 text-center"> 
																  <br>
																  <img src="images/im.png" width="55%">
															   </div>
																<?php echo form_error('photo') ?>
															</div>
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane" id="tab3">
												   <div class="col-lg-12">
													  <div class="image">
														 <div class="row">
															<div class="col-md-8"><p>Opening Hours</p></div>
															 <div class="col-md-4 text-right">
																 <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#timeModel">Opening Hours</button>
															</div>
															<div>
															   <div class="col-lg-6">
																   <table class="table table-bordered" id="table-branch-timedis" style="margin-bottom: 10px">
																	<thead>
																		 <tr>
																			<th>Weekdays</th>
																			<th>From Time</th>
																			<th>To Time</th>
																			<th>Type</th>
																			
																		</tr>
																	</thead>
																	<tbody>
																	<?php
																		foreach($timedata as $data){?>
																		<tr>
																			<td><?php echo $data->weekday;?></td>
																			<td><?php echo $data->from_time;?></td>
																			<td><?php echo $data->to_time;?></td>
																			<td><?php echo $data->type;?></td>
																		
																		</tr>
																		<?php }?>
																	</tbody>
																</table>

												   <!-- New Time Modal -->
												   <div class="modal fade" id="timeModel" role="dialog">
													  <div class="modal-dialog modal-lg">
														 <div class="modal-content">
															<div class="modal-header">
															   <button type="button" class="close" data-dismiss="modal">&times;</button>
															   <h4 class="modal-title">Time Management
															   </h4>
															</div>
															<div class="modal-body">
															   <p>Update Opening Hours</p>
															   <div class="form-group">
															   	 <table class="table table-bordered" id="table-branch-timeis" style="margin-bottom: 10px">
																	<thead>
																		 <tr>
																			<th>Weekdays</th>
																			<th>From Time</th>
																			<th>To Time</th>
																			<th>Type</th>
																		
																		</tr>
																	</thead>
																	<tbody>
																	<?php
																	foreach($timedata as $data){?>
																	<tr>
																		<td>
																	  <select class="selectpicker" id="weekday" name="weekday[]">
																		  <option  <?php if($data->weekday=='Monday'){?>selected<?php } ?>>Monday</option>
																		  <option <?php if($data->weekday=='Tuesday'){?>selected<?php } ?>>Tuesday</option>
																		  <option <?php if($data->weekday=='Wednesday'){?>selected<?php } ?>>Wednesday</option>
																		  <option <?php if($data->weekday=='Thursday'){?>selected<?php } ?>>Thursday</option>
																		  <option <?php if($data->weekday=='Friday'){?>selected<?php } ?>>Friday</option>
																		  <option <?php if($data->weekday=='Saturday'){?>selected<?php } ?>>Saturday</option>
																		  <option <?php if($data->weekday=='Sunday'){?>selected<?php } ?>>Sunday</option>
																		</select>
																	</td>
																	<td><input size="12" data-format="hh:mm:ss" id="timepicker" name="from_time[]" type="text" value="<?php echo $data->from_time;?>"></input><div class="col-md--2">	<span style="color:#999;font-size:12px;">Format (00:00:00)</span> </div></td>
																	<td><input size="12" data-format="hh:mm:ss" id="timepicker" name="to_time[]" type="text" value="<?php echo $data->to_time;?>"></input><div class="col-md--2">	<span style="color:#999;font-size:12px;">Format (00:00:00)</span> </div></td>
																	<input size="12" id="type" name="timeid[]" type="hidden"  value="<?php echo $data->id;?>"></input>
																	<td><input size="12" id="type" name="type[]" type="text"  value="<?php echo $data->type;?>"></input></td>
																	
<!--
																	<span class="add-on">
																	  <i data-time-icon="icon-time" data-date-icon="icon-calendar">
																	  </i>
																	</span>
-->
	
<input type="hidden" id="items" name="items" value="1" /> 
																	</tr>
																	<?php }?>
																	</tbody>
																</table>
																</div>
															</div>
															<div class="modal-footer">
															   <button type="button" class="btn btn-default" id="addnew" name="addnew">Add New</button>
															   <button type="button" class="btn btn-default timeSubmit" data-dismiss="modal">Submit</button>
															</div>
														 </div>
													  </div>
												   </div>
												
												
																   
															   </div>
															</div>
														 </div>
													  </div>
												   </div>
												</div>
											</div>
										  </div>
										  <div class="col-sm-3">
											 <ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
												<li role="presentation" class="brand-nav active"><a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab">General</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Branch Photo</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">Opening Hours</a></li>
												</ul>
										  </div>
									   </div>
									</div>
								</div>
							</div>
						</div>
						<div id="menu1" class="tab-pane fade">
							<div class="row">
								<div class="col-lg-6">
									<div class="account">
										<div class="form-horizontal">
											<div class="form-group">
												<label class="control-label col-sm-3" for="phone">Phone:</label>
												<div class="col-sm-6"> 
												   <input type="text" class="form-control" id="phone" name="phone"  value="<?php echo $phone; ?>">
												   <?php echo form_error('phone') ?>
												</div>
											</div>
											<div class="form-group">
												<label class="control-label col-sm-3" for="fax">Fax:</label>
												<div class="col-sm-6"> 
												   <input type="text" class="form-control" id="fax" name="fax"  value="<?php echo $fax; ?>" >
												   <?php echo form_error('fax') ?>
												</div>
											</div>
											<div class="form-group">
												<label class="control-label col-sm-3" for="email">Email:</label>
												<div class="col-sm-6"> 
												   <input type="text" class="form-control" id="email" name="email"  value="<?php echo $email; ?>" >
												   <?php echo form_error('email') ?>
												</div>
											</div>
											<div class="form-group">
												<label class="control-label col-sm-3" for="website">Website:</label>
												<div class="col-sm-6"> 
												   <input type="text" class="form-control" id="website" name="website"  value="<?php echo $website; ?>" >
												   <?php echo form_error('website') ?>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div id="menu2" class="tab-pane fade">
							<div class="row">
								<div class="col-lg-6">
									<div class="account">
										<div class="form-horizontal">
											<div class="form-group">
												<div class="col-lg-6 cdata">
													<div id="selected-class"></div>
													<div class="cdata-inner" id="selected-oldclass">
														<h4>Selected Classes</h4>
														<ul>
															<?php foreach($classdata as $key => $data) { 
																echo '<li>'.$data->surname.'</li>';
															 }?>
														</ul>
													</div>
													</div>
													<div class="col-lg-3">
												   <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#classesModel">Classes Selection </button>
												   <!-- Modal -->
												   <div class="modal fade" id="classesModel" role="dialog">
													  <div class="modal-dialog modal-lg">
														 <div class="modal-content">
															<div class="modal-header">
															   <button type="button" class="close" data-dismiss="modal">&times;</button>
															   <h4 class="modal-title">Classes
															   </h4>
															</div>
															<div class="modal-body">
															   <p>Select your class</p>
																<table class="table table-bordered" id="table-branch-class" style="margin-bottom: 10px">
																	<thead>
																		 <tr>
																			 <th></th>
																			<th>Surname</th>
																			<th>Designation</th>
																			<th>Tax</th>
																			<th>Description</th>
																		</tr>
																	</thead>
																	<tbody>
																	</tbody>
																</table>
															</div>
															<div class="modal-footer">
															   <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
															   <button type="button" class="btn btn-default classSubmit" data-dismiss="modal">Submit</button>
															</div>
														 </div>
														
													  </div>
													
												   </div>
												
												
												</div>
												 <div class="col-md-12">
													
													<input type="hidden" class="form-control" id="classid" name="classid" value="<?php echo $classid; ?>">
												</div>
											 </div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	</form>
	
</div>
<script type="text/javascript">
jQuery(document).ready(function() {
	
	// Add new time 
	var currentItem = 1;
  $('#addnew').click(function(){
   currentItem++;
   $('#items').val(currentItem);
var strToAdd = '<tr><td><select name="weekday[]" class ="weekdays'+currentItem+'"><option value="Sunday">Sunday</option><option value="Monday">Monday</option><option value="Tuesday">Tuesday</option><option value="Wednesday">Wednesday</option><option value="Thursday">Thursday</option><option value="Friday">Friday</option><option value="Saturday">Saturday</option></select></td><td><input name= "from_time[]" class ="from_time[]" type="text" /><div class="col-md--2">	<span style="color:#999;font-size:12px;">Format (00:00:00)</span> </div></td><td><input name="to_time[]" class ="to_time" type="text" /><div class="col-md--2">	<span style="color:#999;font-size:12px;">Format (00:00:00)</span> </div></td><td><input name="type[]" class ="type" type="text" /></td></tr>';
   $('#table-branch-timeis').append(strToAdd);
   
  });
  
  // Add Ends Here
	 
	var table;
	var arrA = [];
	clsids="<?php echo $classid; ?>";
	selectedclasses   = clsids.split(',');

		//datatables
		table = jQuery('#table-branch-class').DataTable({ 
	 
			"processing": true, //Feature control the processing indicator.
			"serverSide": true, //Feature control DataTables' server-side processing mode.
			"order": [], //Initial no order.
	 
			// Load data for the table's content from an Ajax source
			"ajax": {
				"url": "<?php echo site_url('branches/class_ajax_list')?>",
				"type": "POST"
			},
			
			//Set column definition initialisation properties.
			"columnDefs": [
			{ 
				"targets": [ 0 ], //first column / numbering column
				"orderable": false, //set not orderable
				 'render': function (data, type, full, meta , selectedclasses){
					
				return '<input type="checkbox" name="classsid[]" id="selectclass-'+data+'" value="' 
					+ $('<div/>').text(data).html() + '">';
				}
			},
			],
			"rowCallback": function(row, data, dataIndex){
			 // Get row ID
			 var rowId = data[0]++;
			
			 // If row ID is in the list of selected row IDs
			 if(rowId==selectedclasses[rowId]){
				jQuery(row).find('#selectclass-'+arrA).prop('checked', true);
				//jQuery(row).addClass('selected');
			 }
		  }
	 
		});
	
		
		jQuery(".classSubmit").click(function(){
			var checkboxValues = jQuery('#classesModel input:checkbox:checked').map(function() { return $(this).val(); } ).get().join();
			
			jQuery.ajax({
				url : "<?php echo site_url('branches/getclasses') ?>",
				type: "POST",
				data : {id:checkboxValues},
				success: function(response, textStatus, jqXHR)
				{
					var json_obj = $.parseJSON(response);
						 var output = "<h4> Selected Classes </h4>";
						  output += "<ul>";
							var id ='';
						  for (i=0; i < json_obj.length; i++)
						  {
							var name = json_obj[i];
							output += "<li>" + name.surname +  "</li>";
							id += name.id+",";
						  }
						  output += "</ul>";
						  $('#selected-oldclass').hide();
						  $('#selected-class').html(output);
						  
						   id = id.slice(0, -1);
						  jQuery('#classid').val(id);
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
			 
				}
			});
		});
	});
</script>
