<html>
   <head>
      <title>DRIVING | SCHOOL</title>
      <meta charset="utf-8">
      <meta name="author" content="Dexel Designs">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <meta name="description" content="">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css" rel="stylesheet" type="text/css">
      <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/base.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/style.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/service_trans.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/bootstrap_changes.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/responsive.css" rel="stylesheet" type="text/css">
	  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	  <script type="text/javascript" src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/js/jquery-3.2.1.min.js"></script>
	   <script  src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/js/jquery-ui.min.js"></script>
	   <script type="text/javascript" src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/js/bootstrap.min.js"></script>
	   <script type="text/javascript" src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/js/main.js"></script>
	   <script src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/datatables/js/datatables.min.js"></script>
   </head>
   <body>
      <div class="instructor_pos">
         <div class="instructor">
            <div class="container-fluid">
               <ul class="header1">
                  <li class="active"><a href="#">MENTOR</a></li>
                  <li class="update"><input type="text" name="messgae" class="form-control"></li>
                  <li class="search"><i class="fa fa-search"></i></li>
                  <li><a href=""><i class="fa fa-bell-o"></i><span class="label label-danger">8</span></a></a></li>
                  <li class="active"><a href="#"><i class="fa fa-hdd-o"></i> save</a></li>
                  <li><a href="">My account <i class="fa fa-user-o"></i></a></li>
                  <li><a href=""><i class="fa fa-envelope-o"></i><span class="label label-success">4</span></a></li>
                  <li></li>
               </ul>
               <div class="clear"></div>
            </div>
         </div>
         <div class="show_id" id="show" style="display: none;">
            <div class="instructor instructor2">
               <div class="container-fluid">
                  <ul class="header1 header2">
                     <li class="active"><a href="#">Menu</a></li>
                     <li><a href="">Manage</a></li>
                     <li><a href=""><i class="fa fa-pencil"></i> Edit</a></li>
                     <li><a href=""><i class="fa fa-eye"></i> View</a></li>
                     <li><a href=""><i class="fa fa-cog"></i> Setting</a></li>
                  </ul>
                  <div class="clear"></div>
               </div>
            </div>
            <div class="instructor instructor3">
               <div class="container-fluid">
                  <ul class="header1 header2">
                     <li><a href="#"><i class="fa fa-ban"></i> Cancel</a></li>
                     <li><label></label></li>
                     <li><label></label></li>
                     <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-plus"></i> New</a>
                        <ul class="dropdown-menu">
                           <li><a href="#">Page 1-1</a></li>
                           <li><a href="#">Page 1-2</a></li>
                           <li><a href="#">Page 1-3</a></li>
                        </ul>
                     </li>
                  </ul>
                  <div class="clear"></div>
               </div>
            </div>
         </div>
         <div class="hide_id" id="hide">
            <h4 id="down"><i class="fa fa-arrow-down"></i></h4>
            <h4 id="up" style="display: none;"><i class="fa fa-arrow-up"></i></h4>
         </div>
      </div>


<div class="tab-pill">
	<form action="<?php echo $action; ?>" method="post">
		<div class="container">
			<div class="create_new">
				<div class="row">
					<div class="col-lg-6">
						<h5><i class="fa fa-arrow-right"></i> Leistungen</h5>
					</div>
					<div class="col-lg-4 text-right">
						<button type="submit" class="btn btn-success"><i class="fa fa-hdd-o"></i> Save</button>
					</div>
					<div class="col-lg-1">
						<button type="button" class="btn btn-danger"><i class="fa fa-ban"></i> Cancel</button>
					</div>
				</div>
			</div>
			<br>
			<ul class="nav nav-tabs">
				<li class="active"><a data-toggle="pill" href="#home"><i class="fa fa-folder-open-o"></i> Erfassung</a></li>
				<li><a data-toggle="pill" href="#menu1"><i class="fa fa-plus"></i> Verwaltung</a></li>
				<li><a data-toggle="pill" href="#menu2"><i class="fa fa-plus"></i> Preisliste</a></li>
			</ul>
			<br>
			<div class="tab-content">
				<div id="home" class="tab-pane fade in active">
					<ul class="nav nav-tabs">
						<li class="active"><a data-toggle="pill" href="#home_sub"><i class="fa fa-folder-open-o"></i> Einzelerfassung</a></li>
						<li><a data-toggle="pill" href="#menu1_sub"><i class="fa fa-plus"></i> Gruppenerfassung</a></li>
					</ul>
					<br>
					<div class="tab-content">
						<div id="home_sub" class="tab-pane fade in active">
							<div class="section1">
								<div class="container">
									<div class="row">
										<div role="tabpanel">
											<div class="col-sm-9">
												<div class="tab-content">
													<div role="tabpanel" class="tab-pane active" id="tab1">
														<div class="row">
															<div class="col-lg-12">
																<div class="col-sm-12 text-right">
																	<label class="control-label text-right">Eingaben merken</label>
																	<input type="checkbox" name="">
																</div>
																<br>
																<div class="general">
																	<p>Datenerfassung</p>
																	<div class="form-horizontal">
																		<div class="form-group">
																			<label class="control-label col-sm-2">Leistung <br>( * = Auswahl )</label>
																			<div class="col-sm-6">
																				<input type="text" class="form-control" id="powercode"  value="<?php echo $power_id; ?>" >
																				<input type="hidden" class="form-control" id="powercodeval" name="power_id" value="" >
																				<?php echo form_error('power_id') ?>
																			</div>
																		</div>
																		<div class="form-group">
																			<label class="control-label col-sm-2" for="pwd">Betrag:</label>
																			<div class="col-sm-6"> 
																				<input type="text" class="form-control"  id="firstname" name="amount" value="<?php echo $amount; ?>">
																				<?php echo form_error('amount') ?>
																			</div>
																			<div class="col-sm-2 text-left"> 
																				<span>€</span>
																			</div>
																		</div>
																		<div class="form-group">
																			<label class="control-label col-sm-2" for="pwd">Fahrschüler <br>( * = Auswahl )</label>
																			<div class="col-sm-4"> 
																				<input type="text" class="form-control" id="Surename" value="<?php echo $student_id; ?>" >
																				<input type="hidden" class="form-control" id="student_id" name="student_id" value="" >
																				<?php echo form_error('student_id') ?>
																			</div>
																			<label class="control-label col-sm-3" for="pwd">Nur aktive FS anzeigen Check_on</label>
																			<div class="col-sm-2"> 
																				<input type="checkbox"  id="Surename" >
																			</div>
																		</div>
																		<div class="form-group">
																			<label class="control-label col-sm-2" for="pwd">Bemerkung: </label>
																			<div class="col-sm-6"> 
																				<textarea class="form-control" name="comment" value="<?php echo $comment ?>"></textarea>
																				<?php echo form_error('comment') ?>
																			</div>
																		</div>
																		<div class="form-group">
																			<label class="control-label col-sm-2" for="pwd">Datum:</label>
																			<div class="col-sm-2"> 
																				<input class="datepicker form-control" data-date-format="mm/dd/yyyy" name="date" value="<?php echo $date; ?>">
																				<?php echo form_error('date') ?>
																			</div>
																			<label class="control-label col-sm-1" for="pwd">Von:</label>
																			<div class="col-sm-2"> 
																				<input type="text" class="form-control" id="Surename" name="from_time" value="<?php echo $from_time; ?>">
																				<?php echo form_error('from_time') ?>
																			</div>
																			<label class="control-label col-sm-1" for="pwd">Bis:</label>
																			<div class="col-sm-2"> 
																				<input type="text" class="form-control" id="Surename" name="to_time" value="<?php echo $to_time; ?>">
																				<?php echo form_error('to_time') ?>
																			</div>
																		</div>
																		<div class="form-group">
																			<label class="control-label col-sm-2" for="pwd">Fahrlehrer <br>( * = Auswahl )</label>
																			<div class="col-sm-6"> 
																				<input type="text" class="form-control" id="instrutor_val" value="<?php echo $instrutor_id; ?>" >
																				<input type="hidden" class="form-control" id="instrutor_id" name="instrutor_id" value="" >
																				<?php echo form_error('instrutor_id') ?>
																			</div>
																		 </div>
																		 <div class="form-group">
																			<label class="control-label col-sm-2" for="pwd">Fahrzeug <br>( * = Auswahl )</label>
																			<div class="col-sm-6"> 
																				<input type="text" class="form-control" id="vehicle_val" value="<?php echo $vehicle_id; ?>" >
																				<input type="hidden" class="form-control" id="vehicle_id" name="vehicle_id" value="" >
																				<?php echo form_error('vehicle_id') ?>
																			</div>
																		 </div>
																		<div class="form-group">
																			<label class="control-label col-sm-2" for="pwd">Klasse</label>
																			<div class="col-sm-6">
																				<select class="form-control" name="class_id">
																					<?php foreach($classlist as $key => $value) { ?>
																						 <option value="<?php echo $value->id; ?>"><?php echo $value->surname; ?></option>
																					 <?php } ?>
																				</select>
																				<?php echo form_error('class_id') ?>
																			</div>
																		</div>
																		<div class="form-group">
																			<label class="control-label col-sm-2" for="pwd">Lektion</label>
																			<div class="col-sm-6"> 
																				<input type="text" class="form-control" id="Surename" name="lesson" value="<?php echo $lesson; ?>" >
																				<?php echo form_error('lesson') ?>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div role="tabpanel" class="tab-pane" id="tab2">
														<div class="col-lg-12">
															<div class="image">
																<div class="row">
																	<p>Fahrschüler-Info</p>
																	<div>
																		<div class="col-sm-6"> 
																			<span>Fahrschüler nicht gefunden</span>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div role="tabpanel" class="tab-pane" id="tab3">
														<div class="col-lg-12">
															<div class="image">
																<div class="row">
																	<p>Tagesprotokoll Fahrlehrer</p>
																	<div>
																		<div class="col-lg-6">
																			<span>Fahrlehrer nicht gefunden</span>
																			<br>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div role="tabpanel" class="tab-pane" id="tab4">
														<div class="col-lg-12">
															<div class="private">
																<p>Logbuch</p>
																<div class="form-horizontal">
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="email">Sortieren nach :</label>
																		<div class="col-sm-6">
																		<select class="form-control">
																			<option>datum</option>
																			<option>Fahrschüler</option>
																			<option>Fahrlehrer</option>
																		</select>
																	</div>
																</div>
																<div class="form-group">
																	<label class="control-label col-sm-2" for="email">Sortieren nach:</label>
																	<div class="col-sm-4">
																		<input  class="datepicker form-control" data-date-format="mm/dd/yyyy">
																	</div>
																	<label class="control-label col-sm-1" for="email">bis :</label>
																	<div class="col-sm-4">
																		<input  class="datepicker form-control" data-date-format="mm/dd/yyyy">
																	</div>
																</div>
																<div class="form-group">
																	<label class="control-label col-sm-2" for="email">Fahrschüler :</label>
																	<div class="col-sm-6">
																		<input type="text" class="form-control" name="">
																	</div>
																	<button class="btn btn-primary"><i class="fa fa-search col-sm-1"></i></button> 
																</div>
																<div class="form-group">
																	<label class="control-label col-sm-2" for="email">Fahrlehrer :</label>
																	<div class="col-sm-6">
																		<input type="text" class="form-control" name="">
																	</div>
																	<button class="btn btn-primary"><i class="fa fa-search col-sm-1"></i></button> 
																</div>
																<table class="table table-responsive">
																	<thead>
																		<tr>
																			<th>Leistung</th>
																			<th>Fahrschüler</th>
																			<th>Datum</th>
																			<th>Von</th>
																			<th>Bis</th>
																			<th>Fahrlehrer</th>
																			<th>Fahrzeug</th>
																			<th>Kl.</th>
																			<th>Thema</th>
																			<th>Betrag</th>
																			<th>Rechnung</th>
																			<th>&nbsp;</th>
																		</tr>
																	</thead>
																	<tbody></tbody>
																</table>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="col-sm-3">
											<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
												<li role="presentation" class="brand-nav active"><a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab">Datenerfassung</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Fahrschüler-Info</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">Tagesprotokoll Fahrlehrer</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab4" aria-controls="tab4" role="tab" data-toggle="tab">Logbuch</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div id="menu1_sub" class="tab-pane fade in">
						<div class="section1">
							<div class="container">
								<div class="row">
									<div role="tabpanel">
										<div class="col-sm-9">
											<div class="tab-content">
												<div role="tabpanel" class="tab-pane active" id="ser1">
													<div class="row">
														<div class="col-lg-12">
															<div class="col-sm-12 text-right">
																<label class="control-label text-right">Eingaben merken</label>
																<input type="checkbox" name="">
															</div>
															<br>
															<div class="general">
																<p>Datenerfassung</p>
																<div class="form-horizontal">
																	<div class="form-group">
																		<label class="control-label col-sm-2">Leistung <br>( * = Auswahl )</label>
																		<div class="col-sm-6">
																			<input type="text" class="form-control" id="name1" >
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Lektion <br>( * = Auswahl )</label>
																		<div class="col-sm-4"> 
																			<input type="text" class="form-control" id="Surename" >
																		</div>
																		<label class="control-label col-sm-3" for="pwd">Amtl. Lehrplan verwenden Check_on</label>
																		<div class="col-sm-2"> 
																			<input type="checkbox"  id="Surename" >
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Fahrschüler <br>( * = Auswahl )</label>
																		<div class="col-sm-6">
																			<div class="name_user">
																				<span style="color: white;">John doe</span> 
																				<i class="fa fa-close" id="close_user"></i>
																			</div>
																			<div class="show_user">
																				<input type="text" name="" class="form-control">
																			</div>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Klasse</label>
																		<div class="col-sm-6">
																			<select class="form-control">
																				<option>Bitte wahlen</option>
																			</select>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Fahrzeug  <br>( * = Auswahl )</label>
																		<div class="col-sm-6"> 
																			<input type="text" class="form-control" id="Surename" >
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Betrag:</label>
																		<div class="col-sm-6"> 
																			<input type="text" class="form-control" id="firstname" >
																		</div>
																		<div class="col-sm-2 text-left"> 
																			<span>€</span>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Datum:</label>
																		<div class="col-sm-2"> 
																			<input class="datepicker form-control" data-date-format="mm/dd/yyyy">
																		</div>
																		<label class="control-label col-sm-1" for="pwd">Von:</label>
																		<div class="col-sm-2"> 
																			<input type="text" class="form-control" id="Surename">
																		</div>
																		<label class="control-label col-sm-1" for="pwd">Bis:</label>
																		<div class="col-sm-2"> 
																			<input type="text" class="form-control" id="Surename">
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Bemerkung: </label>
																		<div class="col-sm-6"> 
																			<textarea class="form-control"></textarea>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="ser2">
													<div class="col-lg-12">
														<div class="image">
															<div class="row">
																<p>Teilnehmer</p>
																<div class="form-horizontal">
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="email">Fahrschüler:</label>
																		<div class="col-sm-4">
																			<input type="text" class="form-control" name="">
																		</div>
																		<div class="col-sm-1">
																			<button class="btn btn-primary"><i class="fa fa-search"></i></button>
																		</div>
																		<div class="col-sm-4">
																			<button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal">Teilnehmer</button>
																			<!-- Modal -->
																			<div class="modal fade" id="myModal" role="dialog">
																				<div class="modal-dialog modal-lg">
																					<div class="modal-content">
																						<div class="modal-header">
																							<button type="button" class="close" data-dismiss="modal">×</button>
																							<h4 class="modal-title">Fahrschülerauswahl</h4>
																						</div>
																						<div class="modal-body">
																							<div class="col-sm-12 text-right">
																								<label class="control-label text-right">Alle Fahrschüler auflisten</label>
																								<input type="checkbox" name="">
																							</div>
																							<table id="index" class="table-responsive table">
																								<thead>
																									<tr>
																										<th>Fahrschüler</th>
																										<th>Kundennummer</th>
																										<th>Filiale</th>
																										<th>Klasse</th>
																										<th>&nbsp;</th>
																									</tr>
																								</thead>
																								<tbody>
																									<tr>
																										<td style="text-align:left" colspan="16">Keine Teilnehmer vorhanden</td>
																									</tr>
																								</tbody>
																							</table>
																						</div>
																						<div class="modal-footer">
																							<div class="col-sm-12 text-center">
																								<div class="col-sm-4 text-right">
																									<button type="submit" class="btn btn-warning btn-sm">Abbrechen </button>
																								</div>
																								<div class="col-sm-4">
																									<button type="submit" class="btn btn-success btn-sm">Speichern </button>
																								</div>
																							</div>
																							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																	<table id="index" class="table-responsive table">
																		<thead>
																			<tr>
																				<th>Fahrschüler</th>
																				<th>Klasse</th>
																				<th>TU</th>
																				<th>TS</th>
																				<th>ÜST</th>
																				<th>AB</th>
																				<th>ÜL</th>
																				<th>NF</th>
																				<th>GF</th>
																				<th>UW</th>
																				<th>VT</th>
																				<th>PF</th>
																				<th>T1</th>
																				<th>T2</th>
																				<th>T3</th>
																				<th>&nbsp;</th>
																			</tr>
																		</thead>
																		<tbody>
																			<tr>
																				<td style="text-align:left" colspan="16">Keine Teilnehmer vorhanden</td>
																			</tr>
																		</tbody>
																	</table>
																</div>
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="ser3">
													<div class="col-lg-12">
														<div class="private">
															<p>Tagesprotokoll Fahrlehrer</p>
															<div class="form-horizontal">
																<div class="form-group">
																	<span>Fahrlehrer nicht gefunden</span>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="col-sm-3">
											<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
												<li role="presentation" class="brand-nav active"><a href="#ser1" aria-controls="ser1" role="tab" data-toggle="tab">Veranstaltung</a></li>
												<li role="presentation" class="brand-nav"><a href="#ser2" aria-controls="ser2" role="tab" data-toggle="tab">Teilnehmer</a>  </li>
												<li role="presentation" class="brand-nav"><a href="#ser3" aria-controls="ser3" role="tab" data-toggle="tab">Tagesprotokoll Fahrlehrer</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="menu1" class="tab-pane fade">
				<div class="section1">
					<div class="container">
						<div class="row">
							<div role="tabpanel">
								<div class="col-sm-12">
									<div class="tab-content">
										<div role="tabpanel" class="tab-pane active" id="ta1">
											<div class="row">
												<div class="col-lg-12">
													<div class="general">
														<p>Leistungen</p>
														<div class="form-horizontal">
															<div class="form-group">
																<div class="col-sm-6">
																	<button class="btn btn-primary" data-href=""><i class="fa fa-file"></i> Neue Leistung erstellen</button>
																</div>
															</div>
															<div class="form-group">
																<div class="col-sm-3">
																	<select class="form-control">
																		<option>Alle Typen</option>
																		<option>Externe Leistungen</option>
																		<option>Fahrstunde</option>
																		<option>Gebühr</option>
																		<option>Kurs</option>
																		<option>Lehrmaterial</option>
																		<option>Prüfung</option>
																		<option>Sonstige (FL)</option>
																		<option>Unterricht</option>
																	</select>
																</div>
																<div class="form-group">
																	<div class="col-sm-6">
																		<div class="col-sm-6">
																			<input type="text" class="form-control" name="">
																		</div>
																		<button class="btn btn-primary"><i class="fa fa-search col-sm-1"></i></button> 
																	</div>
																</div>
															</div>
															<div class="form-group">
																<table id="index" class="table-responsive table">
																	<thead>
																		<tr>
																			<th>Leistung</th>
																			<th>Kürzel</th>
																			<th>Typ</th>
																			<th>Beschreibung</th>
																			<th>&nbsp;</th>
																		</tr>
																	</thead>
																	<tbody>
																		<tr>
																			<td style="text-align:left" colspan="16">Keine Teilnehmer vorhanden</td>
																		</tr>
																	</tbody>
																</table>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div id="menu2" class="tab-pane fade">
				<div class="col-lg-12">
					<div class="panel-group" id="accordion">
						<div class="panel panel-default">
							<div class="panel-heading" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" style="cursor: pointer;">
								<h4 class="panel-title">
									<a class="accordion-toggle collapsed" >Preisliste drucken</a>
								</h4>
							</div>
							<div id="collapseTwo" class="panel-collapse collapse" aria-expanded="false">
								<div class="panel-body">
									<div class="tab-content">
										<div role="tabpanel" class="tab-pane active fade in" id="drucken1">
											<div class="col-sm-9">
												<div class="section1">
													<div class="row">
														<div class="col-lg-12">
															<div class="general">
																<p>Filiale und Datum wählen</p>
																<div class="form-horizontal">
																	<div class="form-group">
																		<div class="col-sm-3">
																			<select class="form-control">
																				<option>alle Filialen</option>
																				<option>Fahrschule Mentor George Sood</option>
																			</select>
																		</div>
																		<div class="form-group">
																			<div class="col-sm-6">
																				<label class="control-label col-sm-3" for="pwd">Klasse ausgeben</label>
																				<div class="col-sm-3">
																					<input type="text" class="form-control" name="">
																				</div>
																			</div>
																		</div>
																	</div>
																	<div class="form-group">
																		<div class="selected_drivers_licenses" style="max-height: 94px; overflow: auto;">
																			<div class="clearfix">
																				<div class="classesSelected ActivateEntry">
																					<div>Mofa</div>
																					<div class="description">Mofa</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>B</div>
																					<div class="description">PKW</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>A</div>
																					<div class="description">KRAD über 50 ccm</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>A1</div>
																					<div class="description">LKRAD</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>T</div>
																					<div class="description">Zugmasch. über 32 km/h...</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>L</div>
																					<div class="description">Zugmasch. Land/Forstw.</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>M</div>
																					<div class="description">Kleinkrafträder</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>C</div>
																					<div class="description">KFZ ab 3,5 t zG außer ...</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>D</div>
																					<div class="description">Busse</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>D1</div>
																					<div class="description">Busse bis 16 Plätze</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>C1</div>
																					<div class="description">KFZ 3,5-7,5 t zG</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>CE</div>
																					<div class="description">LKW-Anhänger</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>S</div>
																					<div class="description">Dreirädrige Krafträder</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>BE</div>
																					<div class="description">Anhänger</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>C1E</div>
																					<div class="description">zZG max. 12 t</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>DE</div>
																					<div class="description">Bus-Anhänger</div>
																				</div>
																				<div class="classesSelected ActivateEntry">
																					<div>D1E</div>
																					<div class="description">Anhänger zu D1</div>
																				</div>
																			</div>
																		</div>
																	</div>
																	<div class="form-group">
																		<div class="col-lg-3">
																		<br>
																			<button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModasl">Klassenauswahl </button>
																			<!-- Modal -->
																			<div class="modal fade" id="myModasl" role="dialog" style="display: none;">
																				<div class="modal-dialog modal-lg">
																					<div class="modal-content">
																						<div class="modal-header">
																							<button type="button" class="close" data-dismiss="modal">×</button>
																							<h4 class="modal-title">Klassenauswahl   </h4>
																						</div>
																						<div class="modal-body">
																							<p>This is a large modal.</p>
																						</div>
																						<div class="modal-footer">
																							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div role="tabpanel" class="tab-pane fade in" id="drucken2">
											<div class="col-sm-9">
												<div class="section1">
													<div class="row">
														<div class="col-lg-12">
															<div class="general">
																<p>Druckparameter</p>
																<div class="form-horizontal">
																	<div class="form-group">
																		<label class="control-label col-sm-3" for="pwd">Klasse ausgeben</label>
																		<div class="col-sm-2"> 
																			<input type="checkbox"  id="Surename" >
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-3" for="pwd">Fußzeile drucken</label>
																		<div class="col-sm-2"> 
																			<input type="checkbox"  id="Surename" >
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-3" for="pwd">Preise</label>
																		<div class="col-sm-3">
																			<select class="form-control">
																				<option>inkl. MwSt.</option>
																				<option>zzgl. MwSt.</option>
																			</select>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="col-sm-3">
										<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
											<li role="presentation" class="brand-nav active"><a href="#drucken1" aria-controls="ser1" role="tab" data-toggle="tab">Filiale und Datum wählen</a></li>
											<li role="presentation" class="brand-nav"><a href="#drucken2" aria-controls="ser2" role="tab" data-toggle="tab">Druckparameter</a></li>
										</ul>
									</div>
									<div class="col-sm-12 text-right">
										<button class="btn btn-primary"><i class="fa fa-print"></i> Drucken</button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		</div>
	</form>
</div>



<div class="footer">
         <div class="container-fluid">
            <ul class="header1">
               <li class="active"><a href="#"><img src="images/Opel-logo.png" class="logo" width="50px"></a></li>
               <li>© YOU-DRIVE GmbH 2017 Alle Rechte vorbehalten</li>
               <li><a href="">contact</a></li>
               <li><a href="">terms and condition</a></li>
            </ul>
            <div class="clear"></div>
         </div>
      </div>
      </div>
    
   </body>
</html>

<script>
$(function(){
	$("#powercode").autocomplete({
		source: "get_powermgmt", // path to the get_powermgmt method
		select: function(event, ui){
			$('#powercodeval').val(ui.item.id);
		}
	});
	$("#Surename").autocomplete({
		source: "get_studentinfo", // path to the get_studentinfo method
		select: function(event, ui){
			$('#student_id').val(ui.item.id);
		}
	});
	$("#instrutor_val").autocomplete({
		source: "get_instructorinfo", // path to the get_studentinfo method
		select: function(event, ui){
			$('#instrutor_id').val(ui.item.id);
		}
	});
	$("#vehicle_val").autocomplete({
		source: "get_vehicleinfo", // path to the get_studentinfo method
		select: function(event, ui){
			$('#vehicle_id').val(ui.item.id);
		}
	});
});
</script>
