<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Student_services_mgmt Read</h2>
        <table class="table">
	    <tr><td>Student Id</td><td><?php echo $student_id; ?></td></tr>
	    <tr><td>Power Id</td><td><?php echo $power_id; ?></td></tr>
	    <tr><td>Instrutor Id</td><td><?php echo $instrutor_id; ?></td></tr>
	    <tr><td>Class Id</td><td><?php echo $class_id; ?></td></tr>
	    <tr><td>Amount</td><td><?php echo $amount; ?></td></tr>
	    <tr><td>Date</td><td><?php echo $date; ?></td></tr>
	    <tr><td>From Time</td><td><?php echo $from_time; ?></td></tr>
	    <tr><td>To Time</td><td><?php echo $to_time; ?></td></tr>
	    <tr><td>Lesson</td><td><?php echo $lesson; ?></td></tr>
	    <tr><td>Comment</td><td><?php echo $comment; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('student_services') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>