<div class="tab-pill">
    <div class="container">
        <div class="create_new">
            <div class="row">
              <div class="col-md-3">
                 <h5><i class="fa fa-arrow-right"></i> Vehicle Type Management</h5>
                  <ol class="breadcrumb breadcrumb-arrow create_bread">
                    <li><a href="#"><i class="fa fa-tachometer"></i> Vehicles</a></li>
                    <li class="active"><span>Data</span></li>
                 </ol>
              </div>
              <div class="col-md-6">
				<div style="margin-top: 8px" id="message">
						<?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
					</div>
              </div>
              <div class="col-md-3  text-right">
					<?php echo anchor(site_url('vehicletype/create'),'Create', 'class="btn btn-primary"'); ?>
				</div>
           </div>
            
        </div>
        <div class="section1">
       
        <table class="table table-bordered" id="table-vehicletype" style="margin-bottom: 10px">
            <thead><tr>
                <th>No</th>
		<th>Type</th>
		<th>Designation</th>
		<th>Status</th>
		<th>Update</th>
		<th>Action</th>
		
            </tr></thead>
             <tbody>
				 
            </tbody>

        </table>
        <div class="row">
            <div class="col-md-6">
                <a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
	    </div>
           
        </div>
       </div>
			
    </div>
    </div>


 
 
<script type="text/javascript">

 
jQuery(document).ready(function() {
  
var table;
    //datatables
    table = jQuery('#table-vehicletype').DataTable({ 
 
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.
 
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('vehicletype/ajax_list')?>",
            "type": "POST"
        },
 
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": [ 0 ], //first column / numbering column
            "orderable": false, //set not orderable
        },
        ],
 
    });
 
});
</script>

