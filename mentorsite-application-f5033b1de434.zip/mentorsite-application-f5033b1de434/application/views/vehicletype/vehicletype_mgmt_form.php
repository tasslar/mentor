<div class="tab-pill">
	<div class="container">
		<div class="create_new">
			<div class="row">
				<div class="col-lg-12">
					<div class="col-lg-2">
						<h5><i class="fa fa-arrow-right"></i> Update Branches</h5>
					</div>
					<div class="col-lg-7">
						 <?php echo form_error('type') ?>
						 <?php echo form_error('designation') ?>
						 <div style="margin-top: 8px" id="message">
							<?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
						</div>
					</div>
					<div class="col-lg-3 text-right navigation-btns">	
						<ul>				
		
						
						<li><a href="<?php echo site_url('vehicletype') ?>" class="btn btn-danger"><i class="fa fa-ban"></i> Cancel</a></li>
						</ul>
					</div>
				</div>
            </div>
		</div>
		<div class="section1">
			
			<form action="<?php echo $action; ?>" method="post">
				<div class="form-group">
					<label for="char">Type <?php echo form_error('type') ?></label>
					<input type="text" class="form-control" name="type" id="type" placeholder="Type" value="<?php echo $type; ?>" />
				</div>
				<div class="form-group">
					<label for="designation">Designation <?php echo form_error('designation') ?></label>
					<textarea class="form-control" rows="3" name="designation" id="designation" placeholder="Designation"><?php echo $designation; ?></textarea>
				</div>
				<input type="hidden" name="id" value="<?php echo $id; ?>" /> 
				<button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
				<a href="<?php echo site_url('vehicletype') ?>" class="btn btn-default">Cancel</a>
			</form>
		</div>
	</div>
 </div> 
