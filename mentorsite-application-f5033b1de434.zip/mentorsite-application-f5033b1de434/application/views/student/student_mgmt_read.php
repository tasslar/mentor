<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Student_mgmt Read</h2>
        <table class="table">
	    <tr><td>Username</td><td><?php echo $username; ?></td></tr>
	    <tr><td>Password</td><td><?php echo $password; ?></td></tr>
	    <tr><td>Email</td><td><?php echo $email; ?></td></tr>
	    <tr><td>Instrutor Id</td><td><?php echo $instrutor_id; ?></td></tr>
	    <tr><td>Branch Id</td><td><?php echo $branch_id; ?></td></tr>
	    <tr><td>Address</td><td><?php echo $address; ?></td></tr>
	    <tr><td>State</td><td><?php echo $state; ?></td></tr>
	    <tr><td>Country Id</td><td><?php echo $country_id; ?></td></tr>
	    <tr><td>Photo</td><td><?php echo $photo; ?></td></tr>
	    <tr><td>First Name</td><td><?php echo $first_name; ?></td></tr>
	    <tr><td>Surname</td><td><?php echo $surname; ?></td></tr>
	    <tr><td>Dob</td><td><?php echo $dob; ?></td></tr>
	    <tr><td>Placeofbirth</td><td><?php echo $placeofbirth; ?></td></tr>
	    <tr><td>Phone</td><td><?php echo $phone; ?></td></tr>
	    <tr><td>Mobile</td><td><?php echo $mobile; ?></td></tr>
	    <tr><td>Language</td><td><?php echo $language; ?></td></tr>
	    <tr><td>Note</td><td><?php echo $note; ?></td></tr>
	    <tr><td>Nationality</td><td><?php echo $nationality; ?></td></tr>
	    <tr><td>Consentezb</td><td><?php echo $consentezb; ?></td></tr>
	    <tr><td>Firstaidcourse</td><td><?php echo $firstaidcourse; ?></td></tr>
	    <tr><td>Physical</td><td><?php echo $physical; ?></td></tr>
	    <tr><td>Visiontest</td><td><?php echo $visiontest; ?></td></tr>
	    <tr><td>Visualaid</td><td><?php echo $visualaid; ?></td></tr>
	    <tr><td>Guardian Name</td><td><?php echo $guardian_name; ?></td></tr>
	    <tr><td>G Surname</td><td><?php echo $g_surname; ?></td></tr>
	    <tr><td>G Dob</td><td><?php echo $g_dob; ?></td></tr>
	    <tr><td>G Address</td><td><?php echo $g_address; ?></td></tr>
	    <tr><td>G City</td><td><?php echo $g_city; ?></td></tr>
	    <tr><td>G Postalcode</td><td><?php echo $g_postalcode; ?></td></tr>
	    <tr><td>G State</td><td><?php echo $g_state; ?></td></tr>
	    <tr><td>G Country Id</td><td><?php echo $g_country_id; ?></td></tr>
	    <tr><td>G Email</td><td><?php echo $g_email; ?></td></tr>
	    <tr><td>G Phone</td><td><?php echo $g_phone; ?></td></tr>
	    <tr><td>Traning Allocatoion Type</td><td><?php echo $traning_allocatoion_type; ?></td></tr>
	    <tr><td>Payment Debit</td><td><?php echo $payment_debit; ?></td></tr>
	    <tr><td>Payment Dunning</td><td><?php echo $payment_dunning; ?></td></tr>
	    <tr><td>Payment Dunning Level</td><td><?php echo $payment_dunning_level; ?></td></tr>
	    <tr><td>Payment Bankcode</td><td><?php echo $payment_bankcode; ?></td></tr>
	    <tr><td>Payment Acc Number</td><td><?php echo $payment_acc_number; ?></td></tr>
	    <tr><td>Payment Iban</td><td><?php echo $payment_iban; ?></td></tr>
	    <tr><td>Payment Swiftcode</td><td><?php echo $payment_swiftcode; ?></td></tr>
	    <tr><td>Payment Owner</td><td><?php echo $payment_owner; ?></td></tr>
	    <tr><td>Opos</td><td><?php echo $opos; ?></td></tr>
	    <tr><td>Status</td><td><?php echo $status; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('student') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>