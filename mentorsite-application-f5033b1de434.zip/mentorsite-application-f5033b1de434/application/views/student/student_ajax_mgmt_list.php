<div class="tab-pill">
    <div class="container">
        <div class="create_new">
            <div class="row">
              <div class="col-lg-3">
                 <h5><i class="fa fa-arrow-right"></i> Benutzer anlegen</h5>
              </div>

                <div class="col-md-5 text-center">
                    <div style="margin-top: 8px" id="message">
                        <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                    </div>
                </div>
                <div class="col-lg-1">
                        <?php echo anchor(site_url('student/create'),'Create', 'class="btn btn-primary"'); ?>
                </div>
                <div class="col-lg-3 text-right">
                 <ol class="breadcrumb breadcrumb-arrow create_bread text-right">
                    <li><a href="<?php echo site_url('student') ?>"><i class="fa fa-tachometer"></i> student</a></li>
                    <li class="active"><span>Data</span></li>
                 </ol>
              </div>
           </div>
        </div>
        <div class="section1">
        <div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                <?php //echo anchor(site_url('users/create'),'Create', 'class="btn btn-primary"'); ?>
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 8px" id="message">
                    <?php //echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
            <div class="col-md-1 text-right">
            </div>
            <div class="col-md-3 text-right hide">
                <form action="<?php echo site_url('student/index'); ?>" class="form-inline" method="get">
                    <div class="input-group">
                        <input type="text" class="form-control" name="q" value="<?php echo $q; ?>">
                        <span class="input-group-btn">
                            <?php 
                                if ($q <> '')
                                {
                                    ?>
                                    <a href="<?php echo site_url('student'); ?>" class="btn btn-default">Reset</a>
                                    <?php
                                }
                            ?>
                          <button class="btn btn-primary" type="submit">Search</button>
                        </span>
                    </div>
                </form>
            </div>
        </div>
        <table class="table table-bordered" id="user-table" style="margin-bottom: 10px">
            <thead>
                <tr>
                    <th>No</th>
            		<th>Firstname</th>
                    <th>Email</th>
                    <th>Address</th>
            		<th>Phone</th>
            		<th>Status</th>
            		<th>Action</th>

                    <!--<th>Role</th>
                    <th>Nickname</th>
                    <th>Photo</th>-->
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        </div>
    </div>
</div>
<script type="text/javascript">
 
var table;
 
$(document).ready(function() {
 
    //datatables
    table = $('#user-table').DataTable({ 
 
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.
 
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('student/ajax_student_list')?>",
            "type": "POST"
        },
        "aoColumns":[
            {"bSortable": true},
            {"bSortable": true},
            {"bSortable": true},
            {"bSortable": true},
            {"bSortable": true},
            {"bSortable": false},
            {"bSortable": false},
        ],
 
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": [ 0 ], //first column / numbering column
            "orderable": false, //set not orderable
        },
        ],
 
    });
 
});
</script>