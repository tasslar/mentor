<!--<head>
      <title>DRIVING | SCHOOL</title>
      <meta charset="utf-8">
      <meta name="author" content="Dexel Designs">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <meta name="description" content="">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css" rel="stylesheet" type="text/css">
      <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/base.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/style.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/service_trans.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/bootstrap_changes.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	  <link href="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/admin/css/responsive.css" rel="stylesheet" type="text/css">
	  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	  <script type="text/javascript" src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/js/jquery-3.2.1.min.js"></script>
	   <script  src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/js/jquery-ui.min.js"></script>
	   <script type="text/javascript" src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/js/bootstrap.min.js"></script>
	   <script type="text/javascript" src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/js/main.js"></script>
	   <script src="http://mentor-elb-1901199011.eu-central-1.elb.amazonaws.com/assets/datatables/js/datatables.min.js"></script>
   </head> -->
<div class="tab-pill">
	<div class="container">
		<h2 style="margin-top:0px">Student_mgmt List</h2>
		<div class="row" style="margin-bottom: 10px">
			<div class="col-md-3 text-right">
				<form action="<?php echo site_url('student/index'); ?>" class="form-inline" method="get">
					<div class="input-group">
						<input type="text" class="form-control" name="q" value="<?php echo $q; ?>">
						<span class="input-group-btn">
							<?php 
								if ($q <> '')
								{
									?>
									<a href="<?php echo site_url('student'); ?>" class="btn btn-default">Reset</a>
									<?php
								}
							?>
						  <button class="btn btn-primary" type="submit">Search</button>
						</span>
					</div>
				</form>
			</div>
		</div>
		<div class="create_new">
			<div class="row">
				<div class="col-lg-6">
					<h5><i class="fa fa-arrow-right"></i> Fahrschüler</h5>
				</div>
				<div class="col-lg-6">
					<ol class="breadcrumb breadcrumb-arrow create_bread text-right">
						<li><a href="#"><i class="fa fa-tachometer"></i> instructor</a></li>
						<li class="active"><span>Data</span></li>
					</ol>
				</div>
			</div>
		</div>
		<br>
		<ul class="nav nav-tabs">
			<li class="active"><a data-toggle="pill" href="#student1">Verwaltung</a></li>
			<li><a data-toggle="pill" href="#student2">Formulare</a></li>
			<li><a data-toggle="pill" href="#student3">Lernfortschritt</a></li>
			<li><a data-toggle="pill" href="#student4">Benutzerkonto</a></li>
		</ul>
		<br>
		<form action="<?php echo $action; ?>">
		<div class="tab-content">
			<div id="student1" class="tab-pane fade in active">
				<ul class="nav nav-tabs">
					<li class="active"><a data-toggle="pill" href="#home"><i class="fa fa-folder-open-o"></i> Allgemein</a></li>
					<li><a data-toggle="pill" href="#menu1"><i class="fa fa-plus"></i> Details</a></li>
					<li><a data-toggle="pill" href="#menu2"><i class="fa fa-plus"></i> Führerschein</a></li>
					<li><a data-toggle="pill" href="#menu3"><i class="fa fa-plus"></i> Zahlungsinfo</a></li>
					<li><a data-toggle="pill" href="#menu4"><i class="fa fa-plus"></i> Vertrag</a></li>
					<li><a data-toggle="pill" href="#menu5"><i class="fa fa-plus"></i> Leistungen</a></li>
					<li><a data-toggle="pill" href="#menu6"><i class="fa fa-plus"></i> Rechnungen</a></li>
					<li><a data-toggle="pill" href="#menu7"><i class="fa fa-plus"></i> Zahlungen</a></li>
					<li><a data-toggle="pill" href="#menu8"><i class="fa fa-plus"></i> OPOS</a></li>
				</ul>
				<br>
				<div class="tab-content">
					<div id="home" class="tab-pane fade in active">
						<div class="section1">
							<div class="container">
								<div class="row">
									<div role="tabpanel">
										<div class="col-sm-9">
											<div class="tab-content">
												<div role="tabpanel" class="tab-pane active" id="tab1">
													<div class="row">
														<div class="col-lg-12">
															<div class="general">
																<p>Allgemein</p>
																<div class="form-horizontal">
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="email">Anrede/Titel:</label>
																		<div class="col-sm-2">
																			<select class="form-control">
																				<option>sir</option>
																				<option>Mrs</option>
																			</select>
																		</div>
																		<div class="col-sm-4">
																			<input type="text" class="form-control" id="name1" value="<?php echo $username; ?>" >
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Vorname:</label>
																		<div class="col-sm-6"> 
																			<input type="text" class="form-control" id="firstname" >
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Nachname:</label>
																		<div class="col-sm-6"> 
																			<input type="text" class="form-control" id="Surename" >
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Kürzel: </label>
																		<div class="col-sm-6"> 
																			<input type="text" class="form-control" id="Surename">
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-sm-2" for="pwd">Geburtsdatum:</label>
																		<div class="col-sm-6"> 
																			<input type="text" class="form-control" id="Surename">
																		</div>
																	</div>
																</div>	
															</div>
														</div>
													</div>
												</div>
												<div role="tabpanel" class="tab-pane" id="tab2">
													<div class="col-lg-12">
														<div class="image">
															<div class="row">
																<p>Bild</p>
															<div>
															<div class="col-sm-6"> 
																<span></span>
																<input type="file" multiple class="form-control"/>
															</div>
															<div class="col-sm-6 text-center"> 
																<br>
																<img src="images/im.png" width="55%">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div role="tabpanel" class="tab-pane" id="tab3">
											<div class="col-lg-12">
												<div class="image">
													<div class="row">
														<p>Notiz</p>
													<div>
													<div class="col-lg-6">
														<textarea class="form-control"></textarea>
														<br>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="tab4">
									<div class="col-lg-12">
										<div class="private">
											<p>Privat</p>
											<div class="form-horizontal">
												<div class="form-group">
													<label class="control-label col-sm-2" for="email">Strasse und Hausnr*:</label>
													<div class="col-sm-6">
														<input type="text" class="form-control" id="name1" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">PLZ und Ort:</label>
													<div class="col-sm-2"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
													<div class="col-sm-4"> 
														<input type="text" class="form-control" id="firstname" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Land:</label>
													<div class="col-sm-6">
														<select class="form-control">
															<option></option>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Bundesland: </label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Telefon:</label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Handy:</label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">E-mail:</label>
													<div class="col-sm-6"> 
														<input type="email" class="form-control" id="email">
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="tab5">
									<div class="col-lg-12">
										<div class="operation">
											<p>Betrieblich</p>
											<div class="form-horizontal">
												<div class="form-group">
													<label class="control-label col-sm-2" for="email">Strasse und Hausnr</label>
													<div class="col-sm-6">
														<input type="text" class="form-control" id="name1" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">PLZ und Ort:</label>
													<div class="col-sm-2"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
													<div class="col-sm-4"> 
														<input type="text" class="form-control" id="firstname" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Land Land wählen:</label>
													<div class="col-sm-6">
														<select class="form-control">
															<option></option>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Bundesland: </label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
												</div>
												<div class="checkbox">
													<label><input type="checkbox">von Organisation übernehmen</label>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Telefon:</label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Handy:</label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">E-mail:</label>
													<div class="col-sm-6"> 
														<input type="email" class="form-control" id="email">
													</div>
												</div>
												<div class="checkbox">
													<label><input type="checkbox">von Organisation übernehmen</label>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="tab6">
									<div class="col-lg-12">
										<div class="image info-fa">
											<div class="row">
												<p>Fahrschüler-Info</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2">Filiale:</label>
														<div class="col-sm-6">
															<span>Fahrschule Ment...</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Volljährig:</label>
														<div class="col-sm-6">
															<span>ja</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Forderungen:</label>
														<div class="col-sm-6">
															<span>0.00$<span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Mahnung:</label>
														<div class="col-sm-6">
															<span>0</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Zuletzt aktiv:</label>
														<div class="col-sm-6">
															<span></span>
														</div>
													</div>
													<br>
													<table id="index" class="table table-responsive">
														<thead>
														   <tr>
															  <th>Klasse</th>
															  <th>TU</th>
															  <th>TS</th>
															  <th>ÜST</th>
															  <th>AB</th>
															  <th>ÜL</th>
															  <th>NF</th>
															  <th>GF</th>
															  <th>UW</th>
															  <th>TP</th>
															  <th>PF</th>
															  <th>T1</th>
															  <th>T2</th>
															  <th>T3</th>
														   </tr>
														</thead>
														<tbody>
															<tr class="even">
																<td style="text-align: center;">B</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
															</tr>
														</tbody>
													</table>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Vertrag: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Agreement Ezb.: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im1.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">vision test: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im2.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">First aid course: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
														   <img src="images/im3.png">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-3">
							<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
								<li role="presentation" class="brand-nav active"><a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab">Allgemein</a></li>
								<li role="presentation" class="brand-nav"><a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Bild</a></li>
								<li role="presentation" class="brand-nav"><a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">Notiz</a></li>
								<li role="presentation" class="brand-nav"><a href="#tab4" aria-controls="tab4" role="tab" data-toggle="tab">Privat</a></li>
								<li role="presentation" class="brand-nav"><a href="#tab5" aria-controls="tab5" role="tab" data-toggle="tab">Betrieblich</a></li>
								<li role="presentation" class="brand-nav"><a href="#tab6" aria-controls="tab6" role="tab" data-toggle="tab">Fahrschüler-Info</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	 </div>
	 <div id="menu1" class="tab-pane fade">
		<div class="section1">
			<div class="container">
				<div class="row">
					<div role="tabpanel">
						<div class="col-sm-9">
							<div class="tab-content">
								<div role="tabpanel" class="tab-pane active" id="ta1">
									<div class="row">
										<div class="col-lg-12">
											<div class="general">
												<p>Sonstige Schülerdaten</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Geburtsname:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Geburtsland:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Staatsangehörigkeit:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-3" for="pwd">Einwilligung Ezb: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-3" for="pwd">Erste Hilfe Kurs: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-3" for="pwd">Körperliche und geistige Mängel: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-3" for="pwd">Sehtest: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-3" for="pwd">Sehhilfe erforderlich: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="ta2">
									<div class="row">
										<div class="col-lg-12">
											<div class="general">
												<p>Erziehungsberechtigter</p>
												<button  class="btn btn-primary" id="show_form">Erziehungsberechtigter löschen</button>
												<div class="form-horizontal">
													<div class="box-body" id="hide_form" style="display: none;">
													<br>
														<div class="form-group">
															<label class="control-label col-sm-2" for="email">Anrede/Titel:</label>
															<div class="col-sm-2">
																<select class="form-control">
																	<option>sir</option>
																	<option>Mrs</option>
																</select>
															</div>
															<div class="col-sm-4">
																<input type="text" class="form-control" id="name1" >
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">Vorname:</label>
															<div class="col-sm-6"> 
																<input type="text" class="form-control" id="firstname" >
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">Nachname:</label>
															<div class="col-sm-6"> 
																<input type="text" class="form-control" id="Surename" >
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">Kürzel: </label>
															<div class="col-sm-6"> 
																<input type="text" class="form-control" id="Surename">
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">Geburtsdatum:</label>
															<div class="col-sm-6"> 
																<input type="text" class="form-control" id="Surename">
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="email">Strasse und Hausnr*:</label>
															<div class="col-sm-6">
																<input type="text" class="form-control" id="name1" >
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">PLZ und Ort:</label>
															<div class="col-sm-2"> 
																<input type="text" class="form-control" id="Surename" >
															</div>
															<div class="col-sm-4"> 
																<input type="text" class="form-control" id="firstname" >
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">Land:</label>
															<div class="col-sm-6">
																<select class="form-control">
																	<option></option>
																</select>
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">Bundesland: </label>
															<div class="col-sm-6"> 
																<input type="text" class="form-control" id="Surename" >
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">Telefon:</label>
															<div class="col-sm-6"> 
																<input type="text" class="form-control" id="Surename" >
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">Handy:</label>
															<div class="col-sm-6"> 
																<input type="text" class="form-control" id="Surename">
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2" for="pwd">E-mail:</label>
															<div class="col-sm-6"> 
																<input type="email" class="form-control" id="email">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="ta3">
									<div class="col-lg-12">
										<div class="image info-fa">
											<div class="row">
												<p>Fahrschüler-Info</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2">Filiale:</label>
														<div class="col-sm-6">
															<span>Fahrschule Ment...</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Volljährig:</label>
														<div class="col-sm-6">
															<span>ja</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Forderungen:</label>
														<div class="col-sm-6">
															<span>0.00$<span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Mahnung:</label>
														<div class="col-sm-6">
															<span>0</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Zuletzt aktiv:</label>
														<div class="col-sm-6">
															<span></span>
														</div>
													</div>
													<br>
													<table id="index" class="table table-responsive">
														<thead>
															<tr>
																<th>Klasse</th>
																<th>TU</th>
																<th>TS</th>
																<th>ÜST</th>
																<th>AB</th>
																<th>ÜL</th>
																<th>NF</th>
																<th>GF</th>
																<th>UW</th>
																<th>TP</th>
																<th>PF</th>
																<th>T1</th>
																<th>T2</th>
																<th>T3</th>
															</tr>
														</thead>
														<tbody>
															<tr class="even">
																<td style="text-align: center;">B</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
															</tr>
														</tbody>
													</table>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Vertrag: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Agreement Ezb.: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im1.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">vision test: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im2.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">First aid course: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im3.png">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-3">
							<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
								<li role="presentation" class="brand-nav active"><a href="#ta1" aria-controls="ta1" role="tab" data-toggle="tab">Sonstige Schülerdaten</a></li>
								<li role="presentation" class="brand-nav"><a href="#ta2" aria-controls="ta2" role="tab" data-toggle="tab">Erziehungsberechtigter</a></li>
								<li role="presentation" class="brand-nav"><a href="#ta3" aria-controls="ta3" role="tab" data-toggle="tab">Fahrschüler-Info</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="menu2" class="tab-pane fade">
		<div class="section1">
			<div class="container">
				<div class="row">
					<div role="tabpanel">
						<div class="col-sm-9">
							<div class="tab-content">
								<div role="tabpanel" class="tab-pane active" id="tas1">
									<div class="row">
										<div class="col-lg-12">
											<div class="general">
												<p>Ausbildung</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Zuteilungsart:</label>
														<div class="col-sm-6">
															<select class="form-control">
																<option>Ersterwerb</option>
																<option>Erweiterung</option>
																<option>Nachschulung</option>
																<option>Wiedererlangung</option>
																<option>Nachschulung ASK</option>
																<option>Nachschulung FAP</option>
																<option>Umschreibung</option>
															</select>
														</div>
													</div>
													<div class="form-group">
														<div class="col-lg-3">
															<div class="class">
																<h4>B</h4>
																<span>PKM</span>
															</div>
															<br>
															<button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal">Klassenauswahl</button>
															<!-- Modal -->
															<div class="modal fade" id="myModal" role="dialog">
																<div class="modal-dialog modal-lg">
																	<div class="modal-content">
																		<div class="modal-header">
																			<button type="button" class="close" data-dismiss="modal">&times;</button>
																			<h4 class="modal-title">Klassenauswahl</h4>
																		</div>
																		<div class="modal-body">
																			<p>This is a large modal.</p>
																		</div>
																		<div class="modal-footer">
																			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="tas2">
									<div class="row">
										<div class="col-lg-12">
											<div class="general">
												<p>Zweitsprache</p>
												<div class="form-horizontal">
													<fieldset>
														<a href="#;" class="language_link" id="language_link_de">
															<img alt="" border="0" class="selected_btn language_image" id="language_de" src="images/l1.jpg">
														</a>
														<a href="#;" class="language_link" id="language_link_gr">
															<img alt="" border="0" class="language_image" id="language_gr" src="images/l2.jpg">
														</a>
														<a href="#;" class="language_link" id="language_link_ro">
															<img alt="" border="0" class="language_image" id="language_ro" src="images/l3.jpg">
														</a>
														<a href="#;" class="language_link" id="language_link_pl">
															<img alt="" border="0" class="language_image" id="language_pl" src="images/l4.jpg">
														</a>
														<a href="#;" class="language_link" id="language_link_uk">
															<img alt="" border="0" class="language_image" id="language_uk" src="images/l5.jpg">
														</a>
														<a href="#;" class="language_link" id="language_link_ru">
															<img alt="" border="0" class="language_image" id="language_ru" src="images/l6.jpg"></a><a href="#;" class="language_link" id="language_link_es">
															<img alt="" border="0" class="language_image" id="language_es" src="images/l7.jpg"></a><a href="#;" class="language_link" id="language_link_it">
															<img alt="" border="0" class="language_image" id="language_it" src="images/l8.jpg"></a><a href="#;" class="language_link" id="language_link_pt">
															<img alt="" border="0" class="language_image" id="language_pt" src="images/l9.jpg"></a><a href="#;" class="language_link" id="language_link_hr">
															<img alt="" border="0" class="language_image" id="language_hr" src="images/l10.jpg"></a><a href="#;" class="language_link" id="language_link_tr">
															<img alt="" border="0" class="language_image" id="language_tr" src="images/l11.jpg"></a><a href="#;" class="language_link" id="language_link_fr">
															<img alt="" border="0" class="language_image" id="language_fr" src="images/l12.jpg"></a><a href="#;" class="language_link" id="language_link_ar">
															<img alt="" border="0" class="language_image" id="language_ar" src="images/l13.jpg">
														</a>
														<input class="language_hidden_field" id="learner_setting_attributes_secondary_exam_language" name="learner[setting_attributes][secondary_exam_language]" type="hidden" value="de">
													</fieldset>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="tas3">
									<div class="row">
										<div class="col-lg-12">
											<div class="general">
												<p>Prüfungstermine</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Theorie:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Praxis:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="tas4">
									<div class="row">
										<div class="col-lg-12">
											<div class="general">
												<p>Sonstiges</p>
												<div class="form-horizontal">
													<div class="form-group">
														<div class="col-sm-1"> 
															<input type="checkbox" >
														</div>
														<label class="control-label col-sm-4" for="pwd">Theorie</label>
													</div>
													<div class="form-group">
														<div class="col-sm-1"> 
															<input type="checkbox">
														</div>
														<label class="control-label col-sm-4" for="pwd">B96</label>
													</div>
													<div class="form-group">
														<div class="col-sm-1"> 
															<input type="checkbox">
														</div>
														<label class="control-label col-sm-4" for="pwd">GQ - Grundqualifikation</label>
													</div>
													<div class="form-group">
														<div class="col-sm-1"> 
															<input type="checkbox">
														</div>
														<label class="control-label col-sm-4" for="pwd">Beschleunigte GQ §2 BKrFQV - 140 x 60 Min. Check_off</label>
													</div>
													<div class="form-group">
														<div class="col-sm-1"> 
															<input type="checkbox">
														</div>
														<label class="control-label col-sm-4" for="pwd">GQ - Quereinsteiger §2 Abs. 7 BKrFQV - 96 x 60 Min. Check_off</label>
													</div>
													<div class="form-group">
														<div class="col-sm-1"> 
															<input type="checkbox">
														</div>
														<label class="control-label col-sm-4" for="pwd">GQ - Umsteiger §3 BKrFQV - 35 x 60 Min. Check_off</label>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Zuteilungsart:</label>
														<div class="col-sm-6">
														<select class="form-control">
															<option>Fahrschule Mentor George Sood</option>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Fahrlehrer:</label>
													<div class="col-sm-6">
														<select class="form-control">
															<option> George Sood </option>
													   </select>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div role="tabpanel" class="tab-pane" id="tas5">
								<div class="row">
									<div class="col-lg-12">
									   <div class="general">
											<p>Antrag auf Erteilung einer Fahrerlaubnis nach § 21 FeV</p>
											<div class="form-horizontal">
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Beantragt am:</label>
													<div class="col-sm-2"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
													<div class="col-sm-4"> 
														<input type="text" class="form-control" id="firstname" >
													</div>
													<div class="col-sm-4"> 
														<input type="checkbox" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Art des Ausweises:</label>
													<div class="col-sm-6">
														<input type="text" class="form-control" id="firstname" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">STVA-Nr: </label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">TÜV-Nr (Rücklaufnummer):</label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Rücklaufdatum:</label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename" >
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div role="tabpanel" class="tab-pane" id="tas6">
								<div class="row">
									<div class="col-lg-12">
										<div class="image info-fa">
											<div class="row">
												<p>Fahrschüler-Info</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2">Filiale:</label>
														<div class="col-sm-6">
															<span>Fahrschule Ment...</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Volljährig:</label>
														<div class="col-sm-6">
															<span>ja</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Forderungen:</label>
														<div class="col-sm-6">
															<span>0.00$<span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Mahnung:</label>
														<div class="col-sm-6">
															<span>0</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Zuletzt aktiv:</label>
														<div class="col-sm-6">
															<span></span>
														</div>
													</div>
													<br>
													<table id="index" class="table table-responsive">
														<thead>
															<tr>
																<th>Klasse</th>
																<th>TU</th>
																<th>TS</th>
																<th>ÜST</th>
																<th>AB</th>
																<th>ÜL</th>
																<th>NF</th>
																<th>GF</th>
																<th>UW</th>
																<th>TP</th>
																<th>PF</th>
																<th>T1</th>
																<th>T2</th>
																<th>T3</th>
															</tr>
														</thead>
														<tbody>
															<tr class="even">
																<td style="text-align: center;">B</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
															</tr>
														</tbody>
													</table>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Vertrag: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Agreement Ezb.: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im1.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">vision test: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im2.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">First aid course: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im3.png">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
							<li role="presentation" class="brand-nav active"><a href="#tas1" aria-controls="tas1" role="tab" data-toggle="tab">Ausbildung</a></li>
							<li role="presentation" class="brand-nav"><a href="#tas2" aria-controls="tas2" role="tab" data-toggle="tab">Zweitsprache</a></li>
							<li role="presentation" class="brand-nav"><a href="#tas3" aria-controls="tas3" role="tab" data-toggle="tab">Sonstiges</a></li>
							<li role="presentation" class="brand-nav"><a href="#tas4" aria-controls="tas4" role="tab" data-toggle="tab">Prüfungstermine</a></li>
							<li role="presentation" class="brand-nav"><a href="#tas5" aria-controls="tas5" role="tab" data-toggle="tab">Antrag auf Erteilung einer Fahrerlaubnis nach § 21 FeV</a></li>
							<li role="presentation" class="brand-nav"><a href="#tas6" aria-controls="tas6" role="tab" data-toggle="tab">Fahrschüler-Info</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="menu3" class="tab-pane fade">
	<div class="section1">
		<div class="container">
			<div class="row">
				<div role="tabpanel">
					<div class="col-sm-9">
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="task1">
								<div class="row">
									<div class="col-lg-12">
										<div class="general">
											<p>Abweichender Rechnungsempfänger</p>
											<div class="form-horizontal">
												<div class="form-group">
													<label class="control-label col-sm-6" for="pwd">Rechnungsempfänger von Profil übernehmen</label>
													<div class="col-sm-2"> 
														<input type="checkbox">
													</div>
												 </div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div role="tabpanel" class="tab-pane" id="task2">
								<div class="row">
									<div class="col-lg-12">
										<div class="general">
											<p>Bankverbindung</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Kreditinstitut:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Bankleitzahl:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Kontonummer:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">IBAN:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Swift-BIC:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Kontoinhaber:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="task3">
									<div class="row">
										<div class="col-lg-12">
											<div class="general">
												<p>Sonstiges</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Bankeinzug:</label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Mahnsperre:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Mahnsperre:</label>
														<div class="col-sm-1"> 
															<input type="number" class="form-control" id="Surename" value="0">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="task4">
									<div class="row">
										<div class="col-lg-12">
											<div class="image info-fa">
												<div class="row">
													<p>Fahrschüler-Info</p>
													<div class="form-horizontal">
														<div class="form-group">
															<label class="control-label col-sm-2">Filiale:</label>
															<div class="col-sm-6">
																<span>Fahrschule Ment...</span>
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2">Volljährig:</label>
															<div class="col-sm-6">
																<span>ja</span>
															</div>
														</div>
														<div class="form-group">
															<label class="control-label col-sm-2">Forderungen:</label>
															<div class="col-sm-6">
																<span>0.00$<span>
															</div>
														</div>
														<div class="form-group">
														<label class="control-label col-sm-2">Mahnung:</label>
														<div class="col-sm-6">
															<span>0</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Zuletzt aktiv:</label>
														<div class="col-sm-6">
															<span></span>
														</div>
													</div>
													<br>
													<table id="index" class="table table-responsive">
														<thead>
															<tr>
																<th>Klasse</th>
																<th>TU</th>
																<th>TS</th>
																<th>ÜST</th>
																<th>AB</th>
																<th>ÜL</th>
																<th>NF</th>
																<th>GF</th>
																<th>UW</th>
																<th>TP</th>
																<th>PF</th>
																<th>T1</th>
																<th>T2</th>
																<th>T3</th>
															</tr>
														</thead>
														<tbody>
															<tr class="even">
																<td style="text-align: center;">B</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
															</tr>
														</tbody>
													</table>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Vertrag: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Agreement Ezb.: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im1.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">vision test: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im2.png">
													   </div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">First aid course: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im3.png">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
							<li role="presentation" class="brand-nav active"><a href="#task1" aria-controls="task1" role="tab" data-toggle="tab">Abweichender Rechnungsempfänger</a></li>
							<li role="presentation" class="brand-nav"><a href="#task2" aria-controls="task2" role="tab" data-toggle="tab">Bankverbindung</a></li>
							<li role="presentation" class="brand-nav"><a href="#task3" aria-controls="task3" role="tab" data-toggle="tab">Sonstiges</a></li>
							<li role="presentation" class="brand-nav"><a href="#task4" aria-controls="task4" role="tab" data-toggle="tab">Fahrschüler-Info</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="menu4" class="tab-pane fade">
	<div class="section1">
		<div class="container">
			<div class="row">
				<div role="tabpanel">
					<div class="col-sm-9">
						<div class="tab-content">
							<div class="col-lg-3">
								<button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModals">Ausbildungsvertrag erstellen</button>
								<!-- Modal -->
								<div class="modal fade" id="myModals" role="dialog">
									<div class="modal-dialog modal-lg">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="modal-title">Achtung!</h4>
											</div>
											<div class="modal-body">
												<span>Bitte vergewissern Sie sich, dass Sie Ihre Änderungen vorher gespeichert haben.</span>
												<span>Nicht gespeicherte Änderungen aus den anderen Tabs (Allgemein, Details, Führerschein, Zahlungsinfo …) werden verworfen. </span>
												<span>Möchten Sie wirklich fortfahren? </span>
												<br>
												<div class="col-sm-4 text-right">
													<button type="submit" class="btn btn-warning btn-sm">Abbrechen</button>
												</div>
												<div class="col-sm-4">
													<button type="submit" class="btn btn-success btn-sm">Fortfahren</button>
												</div>
												<br>
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="taskmi4">
								<div class="row">
									<div class="col-lg-12">
										<div class="image info-fa">
											<div class="row">
												<p>Fahrschüler-Info</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2">Filiale:</label>
														<div class="col-sm-6">
															<span>Fahrschule Ment...</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Volljährig:</label>
														<div class="col-sm-6">
															<span>ja</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Forderungen:</label>
														<div class="col-sm-6">
															<span>0.00$<span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Mahnung:</label>
														<div class="col-sm-6">
															<span>0</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Zuletzt aktiv:</label>
														<div class="col-sm-6">
															<span></span>
														</div>
													</div>
													<br>
													<table id="index" class="table table-responsive">
														<thead>
															<tr>
																<th>Klasse</th>
																<th>TU</th>
																<th>TS</th>
																<th>ÜST</th>
																<th>AB</th>
																<th>ÜL</th>
																<th>NF</th>
																<th>GF</th>
																<th>UW</th>
																<th>TP</th>
																<th>PF</th>
																<th>T1</th>
																<th>T2</th>
																<th>T3</th>
															</tr>
														</thead>
														<tbody>
															<tr class="even">
																<td style="text-align: center;">B</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
															</tr>
														</tbody>
													</table>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Vertrag: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Agreement Ezb.: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im1.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">vision test: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im2.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">First aid course: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im3.png">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="menu5" class="tab-pane fade">
	<div class="section1">
		<div class="container">
			<div class="row">
				<div role="tabpanel">
					<div class="col-sm-9">
						<div class="tab-content">
							<button type="button" id="servicepopup" onclick="div_show()" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModaling">Leistung erfassen </button>
<!--
							<div role="tabpanel" class="tab-pane active" id="tasking1">
								<div class="row">
									<div class="col-lg-12">
										<div class="general">
											<p>Logbuch</p>
											<div class="col-lg-12">
												<button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModaling">Leistung erfassen </button>
												<br>
												<br>
												
												<div class="modal fade" id="myModaling" role="dialog">
													<div class="modal-dialog modal-lg">
														<div class="modal-content">
															<div class="modal-header">
																<button type="button" class="close" data-dismiss="modal">&times;</button>
																<h4 class="modal-title">Achtung!</h4>
															</div>
															<div class="modal-body">
																<span>Bitte vergewissern Sie sich, dass Sie Ihre Änderungen vorher gespeichert haben.</span>
																<span>Nicht gespeicherte Änderungen aus den anderen Tabs (Allgemein, Details, Führerschein, Zahlungsinfo …) werden verworfen. </span>
																<span>Möchten Sie wirklich fortfahren? </span>
																<br>
																<div class="col-sm-4 text-right">
																	<button type="submit" class="btn btn-warning btn-sm">Abbrechen</button>
																</div>
																<div class="col-sm-4">
																	<button type="submit" class="btn btn-success btn-sm">Fortfahren</button>
																</div>
																<br>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="form-horizontal">
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Sortieren nach:</label>
													<div class="col-sm-6">
														<select class="form-control">
															<option>datum</option>
															<option>Fahrlehrer</option>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Datum suchen von:</label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Kontonummer:</label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">bis::</label>
													<div class="col-sm-6"> 
														<input type="text" class="form-control" id="Surename">
													</div>
												</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Fahrschüler:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename">
														</div>
														<div class="col-sm-1"> 
															<a href=""><i class="fa fa-search"></i></a>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Fahrschüler:</label>
														<div class="col-sm-6"> 
															<input type="text" class="form-control" id="Surename"> 
														</div>
														<div class="col-sm-1"> 
															<a href=""><i class="fa fa-search"></i></a>
														</div>
													</div>-->
													<table class="table table-bordered student_servicelist_tbl" id="table-services" style="margin-bottom: 10px">
														<thead>
															<tr>
																<th>No</th>
																<th>Leistung</th>
																<th>Datum</th>
																<th>Von</th>
																<th>Bis</th>
																<th>Fahrlehrer</th>
																<th>Fahrzeug</th>
																<th>Kl.</th>
																<th>Betrag</th>
															</tr>
														</thead>
														<tbody>
														</tbody>
														</table>
<!--
													<table id="index" class="table table-responsive">
														<thead>
															<tr>
																<th>Leistung</th>
																<th>Datum</th>
																<th>Von</th>
																<th>Bis</th>
																<th>Fahrlehrer</th>
																<th>Fahrzeug</th>
																<th>Kl.</th>
																<th>Thema</th>
																<th>Betrag</th>
																<th>Rechnung</th>
																<th>&nbsp;</th>
															</tr>
														</thead>
														<tbody>
															<?php /*foreach($studservicemgmt as $student_services_mgmt) {  ?>
															<tr>
																<td style="text-align:left" colspan=""><?php echo $student_services_mgmt->servicetype_name; ?></td>
																<td style="text-align:left" colspan=""><?php echo $student_services_mgmt->date; ?></td>
																<td style="text-align:left" colspan=""><?php echo $student_services_mgmt->from_time; ?></td>
																<td style="text-align:left" colspan=""><?php echo $student_services_mgmt->to_time; ?></td>
																<td style="text-align:left" colspan=""><?php echo $student_services_mgmt->username; ?></td>
																<td style="text-align:left" colspan=""><?php echo $student_services_mgmt->vehicle_name; ?></td>
																<td style="text-align:left" colspan=""><?php echo $student_services_mgmt->surname; ?></td>
																<td style="text-align:left" colspan=""><?php //echo $student_services_mgmt->surname; ?></td>
																<td style="text-align:left" colspan=""><?php echo $student_services_mgmt->amount; ?></td>
																<td style="text-align:left" colspan=""><?php //echo $student_services_mgmt->amount; ?></td>
															</tr>
															<?php }*/  ?>
														</tbody>
													</table>
-->
												<!--</div>
											</div>
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane" id="tasking2">
									<div class="row">
										<div class="col-lg-12">
											<div class="image info-fa">
												<div class="row">
													<p>Fahrschüler-Info</p>
													<div class="form-horizontal">
														<div class="form-group">
															<label class="control-label col-sm-2">Filiale:</label>
															<div class="col-sm-6">
																<span>Fahrschule Ment...</span>
															</div>
														</div>
														<div class="form-group">
														<label class="control-label col-sm-2">Volljährig:</label>
														<div class="col-sm-6">
															<span>ja</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Forderungen:</label>
														<div class="col-sm-6">
															<span>0.00$<span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Mahnung:</label>
														<div class="col-sm-6">
															<span>0</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Zuletzt aktiv:</label>
														<div class="col-sm-6">
															<span></span>
														</div>
													</div>
													<br>
													<table id="index" class="table table-responsive">
														<thead>
															<tr>
																<th>Klasse</th>
																<th>TU</th>
																<th>TS</th>
																<th>ÜST</th>
																<th>AB</th>
																<th>ÜL</th>
																<th>NF</th>
																<th>GF</th>
																<th>UW</th>
																<th>TP</th>
																<th>PF</th>
																<th>T1</th>
																<th>T2</th>
																<th>T3</th>
															</tr>
														</thead>
														<tbody>
															<tr class="even">
																<td style="text-align: center;">B</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
															</tr>
														</tbody>
													</table>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Vertrag: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Agreement Ezb.: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im1.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">vision test: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im2.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">First aid course: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im3.png">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
-->
						</div>
					</div>
					<div class="col-sm-3">
						<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
							<li role="presentation" class="brand-nav active"><a href="#tasking1" aria-controls="tasking1" role="tab" data-toggle="tab">Logbuch</a></li>
							<li role="presentation" class="brand-nav"><a href="#tasking2" aria-controls="tasking2" role="tab" data-toggle="tab">Fahrschüler-Info</a></li>
					   </ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="menu6" class="tab-pane fade">
	<div class="section1">
		<div class="container">
			<div class="row">
				<div role="tabpanel">
					<div class="col-sm-9">
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="masking1">
								<div class="row">
									<div class="col-lg-12">
										<div class="general">
											<p>Rechnungen</p>
											<div class="col-lg-12">
												<div class="col-lg-3 text-right">
													<button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModalings">Leistungen fakturieren</button>
												</div>
												<div class="col-lg-6 text-left">
													<button type="button" class="btn btn-warning btn-sm"><i class="fa fa-print"></i> Drucken</button>
												</div>
												<br>
												<br>
												<hr>
												<!-- Modal -->
												<div class="modal fade" id="myModalings" role="dialog">
													<div class="modal-dialog modal-lg">
														<div class="modal-content">
															<div class="modal-header">
																<button type="button" class="close" data-dismiss="modal">&times;</button>
																<h4 class="modal-title">Leistungen auswählen </h4>
															</div>
															<div class="modal-body">
																<input type="tetx" name="name" class="col-sm-6 text-center">
																<br>
																<div class="col-sm-12 text-right">
																	<button type="submit" class="btn btn-warning btn-sm">Schließen</button>
																</div>
																<br>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="form-horizontal">
												<div class="form-group">
													<div class="col-sm-2">
														<select class="form-control">
															<option>datum</option>
															<option>Fahrlehrer</option>
														</select>
													</div>
													<div class="col-sm-2">
														<select class="form-control">
															<option>2017</option>
															<option>2016</option>
														</select>
													</div>
													<div class="col-sm-3"> 
														<input type="text" class="form-control" id="Surename">
													</div>
													<div class="col-sm-1"> 
														<a href=""><i class="fa fa-search"></i></a>
													</div>
												</div>
												<table id="index" class="table table-responsive">
													<thead>
														<tr>
															<th><input type="checkbox"></th>
															<th>Rech-Nr</th>
															<th>Datum</th>
															<th>Betrag</th>
															<th>fällig</th>
															<th>Gedruckt</th>
															<th>Stornieren</th>
														</tr>
													</thead>
													<tbody>
														<tr>
															<td style="text-align:left" colspan="7">Keine Rechnungen vorhanden</td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div role="tabpanel" class="tab-pane" id="masking2">
								<div class="row">
									<div class="col-lg-12">
										<div class="image info-fa">
											<div class="row">
												<p>Fahrschüler-Info</p>
												<div class="form-horizontal">
													<div class="form-group">
														<label class="control-label col-sm-2">Filiale:</label>
														<div class="col-sm-6">
															<span>Fahrschule Ment...</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Volljährig:</label>
														<div class="col-sm-6">
															<span>ja</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Forderungen:</label>
														<div class="col-sm-6">
															<span>0.00$<span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Mahnung:</label>
														<div class="col-sm-6">
															<span>0</span>
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2">Zuletzt aktiv:</label>
														<div class="col-sm-6">
															<span></span>
														</div>
													</div>
													<br>
													<table id="index" class="table table-responsive">
														<thead>
															<tr>
																<th>Klasse</th>
																<th>TU</th>
																<th>TS</th>
																<th>ÜST</th>
																<th>AB</th>
																<th>ÜL</th>
																<th>NF</th>
																<th>GF</th>
																<th>UW</th>
																<th>TP</th>
																<th>PF</th>
																<th>T1</th>
																<th>T2</th>
																<th>T3</th>
															</tr>
														</thead>
														<tbody>
															<tr class="even">
																<td style="text-align: center;">B</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;">&nbsp;</td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
																<td style="text-align: center;"><span style="color:#f00"></span></td>
															</tr>
														</tbody>
													</table>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Vertrag: </label>
														<div class="col-sm-6"> 
															<input type="checkbox">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">Agreement Ezb.: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im1.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">vision test: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im2.png">
														</div>
													</div>
													<div class="form-group">
														<label class="control-label col-sm-2" for="pwd">First aid course: </label>
														<div class="col-sm-2"> 
															<input type="checkbox">
														</div>
														<div class="col-sm-4"> 
															<img src="images/im3.png">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
							<li role="presentation" class="brand-nav active"><a href="#masking1" aria-controls="masking1" role="tab" data-toggle="tab">Rechnungen</a></li>
							<li role="presentation" class="brand-nav"><a href="#masking2" aria-controls="masking2" role="tab" data-toggle="tab">Fahrschüler-Info</a></li>
					   </ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="menu7" class="tab-pane fade">
	<div class="section1">
		<div class="container">
			<div class="row">
				<div role="tabpanel">
					<div class="col-sm-9">
						<div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="fasking1">
								<div class="row">
									<div class="col-lg-12">
										<div class="general">
											<p>Zahlungen</p>
											<div class="col-lg-12">
												<div class="col-lg-3 text-right">
													<button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#Modalings">€ Zahlungseingang</button>
												</div>
												<br>
												<hr>
												<!-- Modal -->
												<div class="modal fade" id="Modalings" role="dialog">
													<div class="modal-dialog modal-lg">
														<div class="modal-content">
															<div class="modal-header">
																<button type="button" class="close" data-dismiss="modal">&times;</button>
																<h4 class="modal-title">Zahlungseingang</h4>
															</div>
															<div class="modal-body">
																<div class="form-horizontal">
																	<div class="form-group">
																		<label class="control-label col-sm-2 text-right" for="pwd">Datum:</label>
																	<div class="col-sm-6"> 
																		<input type="text" class="form-control" id="Surename">
																	</div>
																</div>
																<div class="form-group">
																	<label class="control-label col-sm-2 text-right" for="pwd">Bank:</label>
																	<div class="col-sm-6">
																		<select class="form-control">
																			<option>kasse</option>
																			<option>ABC BANK GMBH</option>
																		</select>
																	</div>
																</div>
																<div class="form-group">
																	<label class="control-label col-sm-2 text-right" for="pwd">Fahrschüler:</label>
																	<div class="col-sm-6"> 
																		<input type="text" class="form-control" id="Surename">
																	</div>
																</div>
																<div class="form-group">
																	<label class="control-label col-sm-2 text-right" for="pwd">Einzahlung:</label>
																	<div class="col-sm-6"> 
																		<input type="text" class="form-control" id="Surename">
																	</div>
																</div>
																<table id="index" class="table table-responsive">
																	<thead>
																		<tr>
																			<th>MwSt.</th>
																			<th>Leistung</th>
																			<th>gezahlt</th>
																			<th>Zahlung</th>
																			<th >Saldo</th>
																		</tr>
																	</thead>
																	<tbody>
																		<tr class="even">
																			<td >Voll</td>
																			<td>
																				<div data-achievement-value="" id="payment-achievement-value" >0,00 €</div>
																			</td>
																			<td>
																				<div data-payed-value="0.0" id="payment-payed-value">0,00 €</div>
																			</td>
																			<td style="width: 85px">
																				<div class="field clearfix  dynamic">
																					<div class="label ">
																					</div>
																					<div class="input">
																						<input class="convert_float right_align" id="payment_amount" name="payment[amount]" style="width: 75px" type="text" value="">
																					</div>
																				</div>
																			</td>
																			<td>
																				<div data-account_balance-value="" id="payment-account_balance-value" >0,00 €</div>
																			</td>
																		</tr>
																		<tr class="odd">
																			<td >Ermäßigt</td>
																			<td>
																				<div data-achievement-value="" id="payment_reduced-achievement-value" >0,00 €</div>
																			</td>
																			<td>
																				<div data-payed-value="0.0" id="payment_reduced-payed-value" >0,00 €</div>
																			</td>
																			<td style="width: 85px">
																				<div class="field clearfix  dynamic">
																					<div class="label ">
																					</div>
																					<div class="input">
																						<input class="convert_float right_align" id="payment_reduced_amount" name="payment_reduced[amount]" style="width: 75px" type="text" value="">
																					</div>
																				</div>
																			</td>
																			<td>
																				<div data-account_balance-value="" id="payment_reduced-account_balance-value" >0,00 €</div>
																			</td>
																		</tr>
																		<tr class="even">
																			<td>Durchlaufend</td>
																			<td>
																				<div data-achievement-value="" id="payment_sequential-achievement-value" >0,00 €</div>
																			</td>
																			<td>
																				<div data-payed-value="0.0" id="payment_sequential-payed-value" >0,00 €</div>
																			</td>
																			<td style="width: 85px">
																				<div class="field clearfix  dynamic">
																					<div class="label ">
																					</div>
																					<div class="input">
																						<input class="convert_float right_align" id="payment_sequential_amount" name="payment_sequential[amount]" style="width: 75px" type="text" value="">
																					</div>
																				</div>
																			</td>
																			<td>
																				<div data-account_balance-value="" id="payment_sequential-account_balance-value" >0,00 €</div>
																			</td>
																		</tr>
																		<tr class="odd">
																			<td >Steuerfrei</td>
																			<td>
																				<div data-achievement-value="" id="payment_none-achievement-value">0,00 €</div>
																			</td>
																			<td>
																				<div data-payed-value="0.0" id="payment_none-payed-value">0,00 €</div>
																			</td>
																			<td style="width: 85px">
																				<div class="field clearfix  dynamic">
																					<div class="label ">
																					</div>
																					<div class="input">
																						<input class="convert_float right_align" id="payment_none_amount" name="payment_none[amount]" style="width: 75px" type="text" value="">
																					</div>
																				</div>
																			</td>
																			<td>
																				<div data-account_balance-value="" id="payment_none-account_balance-value">0,00 €</div>
																			</td>
																		</tr>
																	</tbody>
																</table>
																<div class="form-group">
																	<label class="control-label col-sm-2 text-right" for="pwd">Bemerkung:</label>
																	<div class="col-sm-6"> 
																		<textarea class="form-control"></textarea>
																	</div>
																</div>
																<br>
																<div class="col-sm-4 text-right">
																	<button type="submit" class="btn btn-warning btn-sm">Abbrechen</button>
																</div>
																<div class="col-sm-4">
																	<button type="submit" class="btn btn-success btn-sm">Speichern</button>
																</div>
																<div class="col-sm-3">
																	<input type="checkbox" name=""> Quittung drucken
																</div>
															</div>
															<br>
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
														</div>
													</div>
												</div>
											</div>
										</div>
										<div class="form-horizontal">
											<div class="form-group">
												<div class="col-sm-2">
													<select class="form-control">
														<option>datum</option>
														<option>belgum-Nr</option>
													</select>
												</div>
												<div class="col-sm-3"> 
													<input type="text" class="form-control" id="Surename">
												</div>
												<div class="col-sm-1"> 
													<a href=""><i class="fa fa-search"></i></a>
												</div>
											</div>
											<table id="index" class="table table-responsive">
												<thead>
													<tr>
														<th>Beleg-Nr.</th>
														<th>Datum</th>
														<th>Kd-Nr.</th>
														<th>Fahrschüler</th>
														<th>Betrag</th>
														<th>MwSt.</th>
														<th>Konto</th>
														<th>&nbsp;</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td style="text-align:left" colspan="8">Keine Zahlungseingänge vorhanden</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="fasking2">
							<div class="row">
								<div class="col-lg-12">
									<div class="image info-fa">
										<div class="row">
											<p>Fahrschüler-Info</p>
											 <div class="form-horizontal">
												<div class="form-group">
													<label class="control-label col-sm-2">Filiale:</label>
													<div class="col-sm-6">
														<span>Fahrschule Ment...</span>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2">Volljährig:</label>
													<div class="col-sm-6">
														<span>ja</span>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2">Forderungen:</label>
													<div class="col-sm-6">
														<span>0.00$<span>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2">Mahnung:</label>
													<div class="col-sm-6">
														<span>0</span>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2">Zuletzt aktiv:</label>
													<div class="col-sm-6">
														<span></span>
													</div>
												</div>
												<br>
												<table id="index" class="table table-responsive">
													<thead>
														<tr>
															<th>Klasse</th>
															<th>TU</th>
															<th>TS</th>
															<th>ÜST</th>
															<th>AB</th>
															<th>ÜL</th>
															<th>NF</th>
															<th>GF</th>
															<th>UW</th>
															<th>TP</th>
															<th>PF</th>
															<th>T1</th>
															<th>T2</th>
															<th>T3</th>
														</tr>
													</thead>
													<tbody>
														<tr class="even">
															<td style="text-align: center;">B</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
														</tr>
													</tbody>
												</table>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Vertrag: </label>
													<div class="col-sm-6"> 
														<input type="checkbox">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Agreement Ezb.: </label>
													<div class="col-sm-2"> 
														<input type="checkbox">
													</div>
													<div class="col-sm-4"> 
														<img src="images/im1.png">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">vision test: </label>
													<div class="col-sm-2"> 
														<input type="checkbox">
													</div>
													<div class="col-sm-4"> 
														<img src="images/im2.png">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">First aid course: </label>
													<div class="col-sm-2"> 
														<input type="checkbox">
													</div>
													<div class="col-sm-4"> 
														<img src="images/im3.png">
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-3">
					<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
						<li role="presentation" class="brand-nav active"><a href="#fasking1" aria-controls="fasking1" role="tab" data-toggle="tab">Zahlungen</a></li>
						<li role="presentation" class="brand-nav"><a href="#fasking2" aria-controls="fasking2" role="tab" data-toggle="tab">Fahrschüler-Info</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
<div id="menu8" class="tab-pane fade">
<div class="section1">
	<div class="container">
		<div class="row">
			<div role="tabpanel">
				<div class="col-sm-9">
					<div class="tab-content">
						<div role="tabpanel" class="tab-pane active" id="lasking1">
							<div class="row">
								<div class="col-lg-12">
									<div class="general">
										<p>Offene Posten</p>
										<div class="col-lg-12">
											<div class="Offene" style="width: 100%;background: white;border: 1px solid black;text-align: center;padding: 20px;">
												<span>Summe offene posten: -0,00$</span>
											</div>
											<br>
											<div class="col-lg-3 text-right">
												<button type="button" class="btn btn-warning btn-sm" ><i class="fa fa-print"></i> Offene Posten Liste drucken</button>
											</div>
											<br>
											<hr>
										</div>
										<div class="form-horizontal">
											<div class="form-group">
												<div class="col-sm-2">
													<select class="form-control">
														<option>Belegnummer</option>
														<option>Datum</option>
														<option>Fälligkeit</option>
													</select>
												</div>
												<div class="col-sm-2">
													<select class="form-control">
														<option>alle</option>
														<option>Rechnung</option>
														<option>Zahlung</option>
														<option>Gutschrift</option>
													</select>
												</div>
												<div class="col-sm-3"> 
													<input type="text" class="form-control" id="Surename">
												</div>
												<div class="col-sm-1"> 
													<a href=""><i class="fa fa-search"></i></a>
												</div>
											</div>
											<table id="index" class="table table-responsive">
												<thead>
													<tr>
														<th>Belegnummer</th>
														<th>Datum</th>
														<th>Betrag in €</th>
														<th>Fälligkeit</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td style="text-align:left" colspan="4">Keine Offene Posten vorhanden</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="lasking2">
							<div class="row">
								<div class="col-lg-12">
									<div class="image info-fa">
										<div class="row">
											<p>Fahrschüler-Info</p>
											<div class="form-horizontal">
												<div class="form-group">
													<label class="control-label col-sm-2">Filiale:</label>
													<div class="col-sm-6">
														<span>Fahrschule Ment...</span>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2">Volljährig:</label>
													<div class="col-sm-6">
														<span>ja</span>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2">Forderungen:</label>
													<div class="col-sm-6">
														<span>0.00$<span>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2">Mahnung:</label>
													<div class="col-sm-6">
														<span>0</span>
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2">Zuletzt aktiv:</label>
													<div class="col-sm-6">
														<span></span>
													</div>
												</div>
												<br>
												<table id="index" class="table table-responsive">
													<thead>
														<tr>
															<th>Klasse</th>
															<th>TU</th>
															<th>TS</th>
															<th>ÜST</th>
															<th>AB</th>
															<th>ÜL</th>
															<th>NF</th>
															<th>GF</th>
															<th>UW</th>
															<th>TP</th>
															<th>PF</th>
															<th>T1</th>
															<th>T2</th>
															<th>T3</th>
														</tr>
													</thead>
													<tbody>
														<tr class="even">
															<td style="text-align: center;">B</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;">&nbsp;</td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
															<td style="text-align: center;"><span style="color:#f00"></span></td>
														</tr>
													</tbody>
												</table>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Vertrag: </label>
													<div class="col-sm-6"> 
														<input type="checkbox">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">Agreement Ezb.: </label>
													<div class="col-sm-2"> 
														<input type="checkbox">
													</div>
													<div class="col-sm-4"> 
														<img src="images/im1.png">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">vision test: </label>
													<div class="col-sm-2"> 
														<input type="checkbox">
													</div>
													<div class="col-sm-4"> 
														<img src="images/im2.png">
													</div>
												</div>
												<div class="form-group">
													<label class="control-label col-sm-2" for="pwd">First aid course: </label>
													<div class="col-sm-2"> 
														<input type="checkbox">
													</div>
													<div class="col-sm-4"> 
														<img src="images/im3.png">
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-3">
					<ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
						<li role="presentation" class="brand-nav active"><a href="#lasking1" aria-controls="lasking1" role="tab" data-toggle="tab">Offene Posten</a></li>
						<li role="presentation" class="brand-nav"><a href="#lasking2" aria-controls="lasking2" role="tab" data-toggle="tab">Fahrschüler-Info</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>
	   <div id="student2" class="tab-pane">
		  <div class="container">
			 <div class="row">
				<div class="col-md-12">
				   <!-- Tab panes -->
				   <div class="tab-content faq-cat-content">
					  <div class="tab-pane active in fade" id="faq-cat-1">
						 <div class="panel-group" id="accordion-cat-1">
							<div class="panel panel-default panel-faq">
							   <div class="panel-heading">
								  <a data-toggle="collapse" data-parent="#accordion-cat-1" href="#faq-cat-1-sub-1">
									 <h5 class="panel-title">
										Führerscheinanträge
										<span class="pull-right"><i class="glyphicon glyphicon-plus"></i></span>
									 </h5>
								  </a>
							   </div>
							   <div id="faq-cat-1-sub-1" class="panel-collapse collapse">
								  <div class="panel-body">
									 <h6>Anzeigeoptionen</h6>
									 <div class="col-sm-4">
										<select class="form-control">
										   <option>Alen</option>
										   <option>Mrs</option>
										</select>
									 </div>
									 <div class="col-lg-6 text-left">
										<button type="button" class="btn btn-warning btn-sm"><i class="fa fa-print"></i> Drucken
										</button>
									 </div>
								  </div>
							   </div>
							</div>
							<div class="panel panel-default panel-faq">
							   <div class="panel-heading">
								  <a data-toggle="collapse" data-parent="#accordion-cat-1" href="#faq-cat-1-sub-2">
									 <h5 class="panel-title">
										Ausbildungsnachweis
										<span class="pull-right"><i class="glyphicon glyphicon-plus"></i></span>
									 </h5>
								  </a>
							   </div>
							   <div id="faq-cat-1-sub-2" class="panel-collapse collapse">
								  <div class="panel-body">
									 <h6>Anzeigeoptionen</h6>
									 <div class="form-horizontal">
										<br>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Voraussichtliches Abschlußdatum: </label>
										   <div class="col-sm-3"> 
											  <input type="text" class="form-control ">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Klassen ausgeben
										   : </label>
										   <div class="col-sm-3">
											  <select class="form-control">
												 <option>Alen</option>
												 <option>Mrs</option>
											  </select>
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Beträge ausgeben: </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Praxis ab der letzten Prüfung ausgeben: </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">ohne Leistungen </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Einzeldokumente </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="col-lg-6 text-center">
										   <button type="button" class="btn btn-warning btn-sm"><i class="fa fa-print"></i> Drucken
										   </button>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
							<div class="panel panel-default panel-faq">
							   <div class="panel-heading">
								  <a data-toggle="collapse" data-parent="#accordion-cat-1" href="#faq-cat-3-sub-3">
									 <h5 class="panel-title">
										Ausbildungsbescheinigung - Theorie
										<span class="pull-right"><i class="glyphicon glyphicon-plus"></i></span>
									 </h5>
								  </a>
							   </div>
							   <div id="faq-cat-3-sub-3" class="panel-collapse collapse">
								  <div class="panel-body">
									 <h6>Anzeigeoptionen</h6>
									 <div class="form-horizontal">
										<br>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Voraussichtliches Abschlußdatum: </label>
										   <div class="col-sm-3"> 
											  <input type="text" class="form-control ">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Datum der Bescheinigung
										   : </label>
										   <div class="col-sm-3"> 
											  <input type="text" class="form-control ">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Klassen ausgeben
										   : </label>
										   <div class="col-sm-3">
											  <select class="form-control">
												 <option>Alen</option>
												 <option>Mrs</option>
											  </select>
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Beträge ausgeben: </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Praxis ab der letzten Prüfung ausgeben: </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">ohne Leistungen </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Einzeldokumente </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="col-lg-6 text-center">
										   <button type="button" class="btn btn-warning btn-sm"><i class="fa fa-print"></i> Drucken
										   </button>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
							<div class="panel panel-default panel-faq">
							   <div class="panel-heading">
								  <a data-toggle="collapse" data-parent="#accordion-cat-1" href="#faq-cat-4-sub-4">
									 <h5 class="panel-title">
										Ausbildungsbescheinigung - Praxis
										<span class="pull-right"><i class="glyphicon glyphicon-plus"></i></span>
									 </h5>
								  </a>
							   </div>
							   <div id="faq-cat-4-sub-4" class="panel-collapse collapse">
								  <div class="panel-body">
									 <h6>Anzeigeoptionen</h6>
									 <div class="form-horizontal">
										<br>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Voraussichtliches Abschlußdatum: </label>
										   <div class="col-sm-3"> 
											  <input type="text" class="form-control ">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Datum der Bescheinigung
										   : </label>
										   <div class="col-sm-3"> 
											  <input type="text" class="form-control ">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Klassen ausgeben
										   : </label>
										   <div class="col-sm-3">
											  <select class="form-control">
												 <option>Alen</option>
												 <option>Mrs</option>
											  </select>
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Beträge ausgeben: </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Praxis ab der letzten Prüfung ausgeben: </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">ohne Leistungen </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Einzeldokumente </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="col-lg-6 text-center">
										   <button type="button" class="btn btn-warning btn-sm"><i class="fa fa-print"></i> Drucken
										   </button>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
							<div class="panel panel-default panel-faq">
							   <div class="panel-heading">
								  <a data-toggle="collapse" data-parent="#accordion-cat-1" href="#faq-cat-5-sub-5">
									 <h5 class="panel-title">
										Antrag zur Teilnahme am Begleiteten Fahren
										<span class="pull-right"><i class="glyphicon glyphicon-plus"></i></span>
									 </h5>
								  </a>
							   </div>
							   <div id="faq-cat-5-sub-5" class="panel-collapse collapse">
								  <div class="panel-body">
									 <h6>Anzeigeoptionen</h6>
									 <div class="col-lg-6 text-left">
										<button type="button" class="btn btn-warning btn-sm"><i class="fa fa-print"></i> Drucken
										</button>
									 </div>
								  </div>
							   </div>
							</div>
							<div class="panel panel-default panel-faq">
							   <div class="panel-heading">
								  <a data-toggle="collapse" data-parent="#accordion-cat-1" href="#faq-cat-6-sub-6">
									 <h5 class="panel-title">
										Anlage zur Teilnahme am Begleiteten Fahren
										<span class="pull-right"><i class="glyphicon glyphicon-plus"></i></span>
									 </h5>
								  </a>
							   </div>
							   <div id="faq-cat-6-sub-6" class="panel-collapse collapse">
								  <div class="panel-body">
									 <h6>Anzeigeoptionen</h6>
									 <div class="col-lg-6 text-left">
										<button type="button" class="btn btn-warning btn-sm"><i class="fa fa-print"></i> Drucken
										</button>
									 </div>
								  </div>
							   </div>
							</div>
							<div class="panel panel-default panel-faq">
							   <div class="panel-heading">
								  <a data-toggle="collapse" data-parent="#accordion-cat-1" href="#faq-cat-7-sub-7">
									 <h5 class="panel-title">
										Ausbildungsbescheinigung - Praxis
										<span class="pull-right"><i class="glyphicon glyphicon-plus"></i></span>
									 </h5>
								  </a>
							   </div>
							   <div id="faq-cat-7-sub-7" class="panel-collapse collapse">
								  <div class="panel-body">
									 <h6>Anzeigeoptionen</h6>
									 <div class="form-horizontal">
										<br>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Datum:</label>
										   <div class="col-sm-3"> 
											  <input type="text" class="form-control ">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">von
										   : </label>
										   <div class="col-sm-3"> 
											  <input type="text" class="form-control ">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">bis
										   : </label>
										   <div class="col-sm-3"> 
											  <input type="text" class="form-control ">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Grund
										   : </label>
										   <div class="col-sm-3">
											  <select class="form-control">
												 Theorieprüfung</option>
												 <option value="1">Praktische Prüfung</option>
												 <option value="2">Theoretische und Praktische Prüfung</option>
												 <option value="3">Theorieunterricht</option>
												 <option value="4">Fahrstunde</option>
												 <option value="5">Sonstiges</option>
											  </select>
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Klassen ausgeben
										   : </label>
										   <div class="col-sm-3">
											  <select class="form-control">
												 <option>Alen</option>
												 <option>Mrs</option>
											  </select>
										   </div>
										</div>
										<div class="form-group">
										   <div class="col-sm-10"> 
											  <input type="tex" class="form-control">
										   </div>
										</div>
										<div class="form-group">
										   <label class="control-label col-sm-2" for="pwd">Einzeldokumente </label>
										   <div class="col-sm-6"> 
											  <input type="checkbox">
										   </div>
										</div>
										<div class="col-lg-6 text-center">
										   <button type="button" class="btn btn-warning btn-sm"><i class="fa fa-print"></i> Drucken
										   </button>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
						 </div>
					  </div>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	   <div id="student3" class="tab-pane fade">
	   </div>
		<div id="student4" class="tab-pane fade">
			<h3>Benutzerkonto alxe alxe</h3>
			<hr>
			<div class="Benutzerkonto" style="line-height: 3;padding-bottom: 123px;">
			  <label>Zugangsdaten für die YOU-DRIVE Schüler-App</label>
			  <br>
			  <input type="checkbox" name="you">
			  <span>Der Schüler kann die YOU-DRIVE Schüler-App nutzen</span>
			  <span></span>
			  <br>
			  <button type="submit" class="btn btn-warning">Zugang zum Lernsystem onlineTEACHER24 aktivieren!</button>
			</div>
		</div>
	</div>
 </div>
</div>
</div>
</form>
</div>
</div>
<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<script  src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<div class="row">
	<div class="col-md-6">
		<a href="#" class="btn btn-primary">Total Record : <?php echo $total_rows ?></a>
</div>
	<div class="col-md-6 text-right">
		<?php echo $pagination ?>
	</div>
</div>


<div id="studservice">
<!-- Popup Div Starts Here -->
	<div id="popupService">
		<div class="general">
			<p>Datenerfassung</p>
			<form action="<?php echo site_url('student_services/create_action'); ?>" method="post">
			<img id="servicepopclose" src="assets/images/close.png" onclick ="div_hide()">
				<div class="form-horizontal">
					<div class="form-group">
						<label class="control-label col-sm-2">Leistung <br>( * = Auswahl )</label>
						<div class="col-sm-6">
							<input type="text" class="form-control" id="powercode" value="">
							<input type="hidden" class="form-control" id="powercodeval" name="power_id" value="" >
							<?php echo form_error('power_id') ?>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="pwd">Betrag:</label>
						<div class="col-sm-6"> 
							<input type="text" class="form-control"  id="firstname" name="amount" value="">
							<?php echo form_error('amount') ?>
						</div>
						<div class="col-sm-2 text-left"> 
							<span>€</span>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="pwd">Fahrschüler <br>( * = Auswahl )</label>
						<div class="col-sm-4"> 
							<input type="text" class="form-control" id="student_val" >
							<input type="hidden" class="form-control" id="student_id" name="student_id" value="" >
							<?php echo form_error('student_id') ?>
						</div>
						<label class="control-label col-sm-3" for="pwd">Nur aktive FS anzeigen Check_on</label>
						<div class="col-sm-2"> 
							<input type="checkbox"  id="Surename" >
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="pwd">Bemerkung: </label>
						<div class="col-sm-6"> 
							<textarea class="form-control" name="comment" value=""></textarea>
							<?php echo form_error('comment') ?>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="pwd">Datum:</label>
						<div class="col-sm-2"> 
							<input class="datepicker form-control" data-date-format="mm/dd/yyyy" name="date" value="">
							<?php echo form_error('date') ?>
						</div>
						<label class="control-label col-sm-1" for="pwd">Von:</label>
						<div class="col-sm-2"> 
							<input type="text" class="form-control" id="Surename" name="from_time" value="">
							<?php echo form_error('from_time') ?>
						</div>
						<label class="control-label col-sm-1" for="pwd">Bis:</label>
						<div class="col-sm-2"> 
							<input type="text" class="form-control" id="Surename" name="to_time" value="">
							<?php echo form_error('to_time') ?>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="pwd">Fahrlehrer <br>( * = Auswahl )</label>
						<div class="col-sm-6"> 
							<input type="text" class="form-control" id="instrutor_val" >
							<input type="hidden" class="form-control" id="instrutor_id" name="instrutor_id" value="" >
							<?php echo form_error('instrutor_id') ?>
						</div>
					 </div>
					 <div class="form-group">
						<label class="control-label col-sm-2" for="pwd">Fahrzeug <br>( * = Auswahl )</label>
						<div class="col-sm-6"> 

							<select class="form-control" id="vehicle_id" name="vehicle_id">
								<?php foreach($vehiclelist as $key => $value) { ?>
									 <option value="<?php echo $value->id; ?>"><?php echo $value->vehicle_name; ?></option>
								 <?php } ?>
							</select>
							<?php echo form_error('vehicle_id') ?>
						</div>
					 </div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="pwd">Klasse</label>
						<div class="col-sm-6">
							<select class="form-control" name="class_id">
								<?php foreach($classlist as $key => $value) { ?>
									 <option value="<?php echo $value->id; ?>"><?php echo $value->surname; ?></option>
								 <?php } ?>
							</select>
							<?php echo form_error('class_id') ?>
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="pwd">Lektion</label>
						<div class="col-sm-6"> 
							<input type="text" class="form-control" id="Surename" name="lesson" value="" >
							<?php echo form_error('lesson') ?>
						</div>
					</div>
					<div class="form-group">
						<input type="hidden" name="id" value="<?php echo $id; ?>" /> 
						<input type="hidden" name="student_id" value="<?php echo $id; ?>" /> 
						<input type="hidden" value="studentservice-popup" name="studentservice-popup">
						<button class="studservice-save" type="submit" class="btn">Save</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<script type="text/javascript">

 
jQuery(document).ready(function() {
  
var table;
    //datatables
    table = jQuery('#table-services').DataTable({ 
 
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.
 
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('student/ajax_list')?>",
            "type": "POST"
        },
 
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": [ 0 ], //first column / numbering column
            "orderable": false, //set not orderable
        },
        ],
 
    });
 
});
</script>
<script>
$(function(){
	$("#powercode").autocomplete({
		source: "student_services/get_powermgmt", // path to the get_powermgmt method
		select: function(event, ui){
			$('#powercodeval').val(ui.item.id);
		}
	});
	$("#student_val").autocomplete({
		source: "student_services/get_studentinfo", // path to the get_studentinfo method
		select: function(event, ui){
			$('#student_id').val(ui.item.id);
		}
	});
	$("#instrutor_val").autocomplete({
		source: "student_services/get_instructorinfo", // path to the get_studentinfo method
		select: function(event, ui){
			$('#instrutor_id').val(ui.item.id);
		}
	});
	$("#vehicle_val").autocomplete({
		source: "student_services/get_vehicleinfo", // path to the get_studentinfo method
		select: function(event, ui){
			$('#vehicle_id').val(ui.item.id);
		}
	});
});

// Validating Empty Field
/*function check_empty() {
if (document.getElementById('name').value == "" || document.getElementById('email').value == "" || document.getElementById('msg').value == "") {
alert("Fill All Fields !");
} else {
document.getElementById('form').submit();
alert("Form Submitted Successfully...");
}
}*/
//Function To Display Popup
function div_show() {
document.getElementById('studservice').style.display = "block";
}
//Function to Hide Popup
function div_hide(){
document.getElementById('studservice').style.display = "none";
}
</script>
<style>
.footer .container-fluid {
	z-index: -1
}	
#studservice {
width:100%;
height:100%;
opacity:1;
top:0;
left:0;
display:none;
position:fixed;
background-color:#313131;
overflow:auto
}
#studservice img#servicepopclose {
position:absolute;
right:-14px;
top:0;
cursor:pointer
}
div#popupService {
position:relative;
display:table;
margin: 0 auto;
top:17%;
/*margin-left:-202px;*/
}
.studservice-save {
	margin: 0 auto;
	display: table;
}
#menu5 .section1 .col-sm-3 {
	z-index: 0;
}
.student_servicelist_tbl {
	margin-top: 3em;
}
</style>
