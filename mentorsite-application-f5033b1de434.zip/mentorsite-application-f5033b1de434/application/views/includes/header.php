<!DOCTYPE html> 
<html lang="en-US">
<head>
  <title><?php echo $title; ?></title>
  <meta charset="utf-8">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url(); ?>assets/datatables/css/datatables.min.css" rel="stylesheet" type="text/css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url(); ?>assets/admin/css/base.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url(); ?>assets/admin/css/style.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url(); ?>assets/admin/css/service_trans.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url(); ?>assets/admin/css/bootstrap_changes.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url(); ?>assets/admin/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url(); ?>assets/admin/css/responsive.css" rel="stylesheet" type="text/css">
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.2.1.min.js"></script>
   <script  src="<?php echo base_url(); ?>assets/js/jquery-ui.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/main.js"></script>
   <script src="<?php echo base_url('assets/datatables/js/datatables.min.js')?>"></script>
  
   <script src="<?php echo base_url('assets/datatables/dataTables.select.min.js')?>"></script>
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap-datepicker.js')?>"></script>
    
    <!-- include summernote css/js-->
   <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.css" rel="stylesheet">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.js"></script>
</head>
<body>
<div class="instructor_pos">
 <div class="instructor">
    <div class="container-fluid">
       <ul class="header1">
          <li class="active"><a href="#"><img src="images/cars_logo.png" width="30px"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> MENTOR</font></font></a></li>
      
          <li><a href=""><i class="fa fa-bell-o"></i><span class="label label-danger"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">8th</font></font></span></a></li>
        
          
          <li><a href=""><i class="fa fa-envelope-o"></i><span class="label label-success"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">4</font></font></span></a></li>
                       
          <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-plus"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> New</font></font></a>
          <ul class="dropdown-menu">
             <li>
                <?php echo anchor(site_url('users'),'Manage users', 'class="mgntlink"'); ?>
              </li>
             <li>
               <?php echo anchor(site_url('instructors'),'Manage Instructors ', 'class="mgntlink"'); ?>
             </li>
             <li>
               <?php echo anchor(site_url('student'),'Manage Student', 'class="mgntlink"'); ?>
             </li>
             
          </ul>
        </li>  
       <li><a href=""><i class="fa fa-cog"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Setting</font></font></a></li>
                       
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">My account </font></font><i class="fa fa-user-o"></i></a>
                    <ul class="dropdown-menu my_acc_drop" style="color: black;">
                <li>
                    <div class="navbar-login">
                        <div class="row">
                            <div class="col-lg-4">
                                <p class="text-center">
                                   <img src="images/user.png" width="100px;">
                                </p>
                            </div>
                            <div class="col-lg-8">
                                <p class="text-left"><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">John Doe</font></font></strong></p>
                                <p class="text-left small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Johndoe@email.com</font></font></p>
                                <br>
                                <p class="text-left">
                                    <a href="#" class="btn btn-primary btn-block btn-sm"><i class="fa fa-edit"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> EDIT</font></font></a>
                                </p>
                            </div>
                        </div>
                    </div>
                </li>
                <li style="padding:0px;">
                    <div class="navbar-login navbar-login-session">
                        <div class="row text-center">

                            <div class="col-lg-12">
                               <hr>
                                <p>
                                    <a href="#" class="btn btn-danger btn-block"><i class="fa fa-power-off"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> LOG OUT</font></font></a>
                                </p>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
          </li>
           
          <li class="dropdown">
			<a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-plus"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> New</font></font></a>
			  <ul class="dropdown-menu">
				 <li>
					<?php echo anchor(site_url('services'),'Services', 'class="mgntlink"'); ?>
				  </li>
				 <li>
				   <?php echo anchor(site_url('finances'),'Finances', 'class="mgntlink"'); ?>
				 </li>
				 <li>
				   <?php echo anchor(site_url('calendar'),'Calendar', 'class="mgntlink"'); ?>
				 </li>
			  </ul>
			</li>
          <li class="dropdown">
			<a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-plus"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> New</font></font></a>
			  <ul class="dropdown-menu">
				  <li>
					<?php echo anchor(site_url('branches'),'Manage Branches', 'class="mgntlink"'); ?>
				  </li>
				   <li>
					<?php echo anchor(site_url('classes'),'Manage Classes', 'class="mgntlink"'); ?>
				  </li>
				   <li>
					<?php echo anchor(site_url('pricegroup'),'Manage Pricegroup', 'class="mgntlink"'); ?>
				  </li>
					<li>
					<?php echo anchor(site_url('vehicle'),'Manage Vehicle', 'class="mgntlink"'); ?>
				  </li>
				  <li>
					<?php echo anchor(site_url('vehicletype'),'Manage Vehicle Type', 'class="mgntlink"'); ?>
				  </li>
			  </ul>
			</li>
          
         
         
      
         
       </ul>
       <div class="clear"></div>
    </div>
 </div>
 
<div class="show_id" id="show" style="display: none;">
   <div class="instructor instructor2">
 <div class="container-fluid">
    <ul class="header1 header2">
       <li class="active"><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Menu</font></font></a></li>
       <li><a href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Manage</font></font></a></li>
       <li><a href=""><i class="fa fa-pencil"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Edit</font></font></a></li>
       <li><a href=""><i class="fa fa-eye"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> View</font></font></a></li>
       <li><a href=""><i class="fa fa-cog"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Setting</font></font></a></li>
    </ul>
    <div class="clear"></div>
 </div>
</div>

<div class="instructor instructor3">
 <div class="container-fluid">
    <ul class="header1 header2">
     
       <li><a href="#"><i class="fa fa-ban"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Cancel</font></font></a></li>
       <li><label></label></li>
       <li><label></label></li>
       <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-plus"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> New</font></font></a>
          <ul class="dropdown-menu">
             <li><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Page 1-1</font></font></a></li>
             <li><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Page 1-2</font></font></a></li>
             <li><a href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Page 1-3</font></font></a></li>
          </ul>
       </li>
 
    </ul>
    <div class="clear"></div>
 </div>
</div>
</div>
<div class="hide_id" id="hide" style="display: none;">
<h4 id="down"><i class="fa fa-arrow-down"></i></h4>
<h4 id="up" style="display: none;"><i class="fa fa-arrow-up"></i></h4>
</div>
</div>
