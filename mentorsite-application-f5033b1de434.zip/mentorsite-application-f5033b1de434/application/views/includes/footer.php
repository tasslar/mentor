	<div class="footer">
         <div class="container-fluid">
            <ul class="header1">
               <li class="active"><a href="#"><img src="images/cars_logo.png" class="logo" width="30px"></a></li>
               <li><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">© YOU-DRIVE GmbH 2017 All rights reserved</font></font></li>
               <li><a href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">contact</font></font></a></li>
               <li><a href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">terms and conditions</font></font></a></li>
            </ul>
            <div class="clear"></div>
         </div>
      </div>
</body>
</html>
