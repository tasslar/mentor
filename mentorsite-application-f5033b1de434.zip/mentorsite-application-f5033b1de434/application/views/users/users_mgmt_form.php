
<h2 style="margin-top:0px">Users_mgmt <?php echo $button ?></h2>
<div class="tab-pill">
	<form action="<?php echo $action; ?>" method="post">
	
	<div class="container">
		<div class="create_new">
			<div class="row">
				<div class="col-lg-12">
					<div class="col-lg-2">
						<h5><i class="fa fa-arrow-right"></i> Mein Konto</h5>
					</div>
					<div class="col-lg-8">
						 <?php echo form_error('firstname') ?>
						 <?php echo form_error('last_name') ?>
						 <?php echo form_error('rule') ?>
						 <?php echo form_error('primary_email') ?>
					</div>
					<div class="col-lg-1 text-right">						
						<button type="submit" class="btn btn-success"><i class="fa fa-hdd-o"></i> <?php echo $button ?></button> 
					</div>
                    <div class="col-lg-1">
						<a href="<?php echo site_url('users') ?>" class="btn btn-danger"><i class="fa fa-ban"></i> Cancel</a>
					</div>
				</div>
            </div>
		</div>
	
		<div class="section1">
			<div class="container">
				<div class="row">
					<br>
					<ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#home">Allgemein</a></li>
						<li><a data-toggle="tab" href="#menu1">Konteneinstellungen</a></li>
						<li><a data-toggle="tab" href="#menu2">Rechteverwaltung</a></li>
					</ul>
					<br>
					<div class="tab-content">
						<div id="home" class="tab-pane fade in active">
							<div class="section1">
								<div class="container">
									<div class="row">
									   <div role="tabpanel">
										  <div class="col-sm-9">
											 <div class="tab-content">
												<div role="tabpanel" class="tab-pane active" id="tab1">
												   <div class="row">
													  <div class="col-lg-12">
														 <div class="general">
															<p>Allgemein</p>
															<div class="form-horizontal">
															   <div class="form-group hide">
																  <label class="control-label col-sm-2" for="name1">Anrede/Titel:</label>
																  <div class="col-sm-2">
																	 <select class="form-control">
																		<option>sir</option>
																		<option>Mrs</option>
																	 </select>
																  </div>
																  <div class="col-sm-4">
																	 <input type="text" class="form-control" id="name1" >
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="firstname">Vorname:</label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $firstname; ?>" > 
																	 <?php echo form_error('firstname') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="last_name">Nachname: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $last_name; ?>">
																	 <?php echo form_error('last_name') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="nickname">Kürzel: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control" id="nickname" name="nickname" value="<?php echo $nickname; ?>">
																	 <?php echo form_error('nickname') ?>
																  </div>
															   </div>
															   <div class="form-group">
																  <label class="control-label col-sm-2" for="dob">Geburtsdatum: </label>
																  <div class="col-sm-6"> 
																	 <input type="text" class="form-control datepicker " data-date-format="dd-mm-yyyy" id="dob" name="dob" value="<?php echo $dob; ?>">
																	 <?php echo form_error('dob') ?>
																  </div>
															   </div>
															
															</div>
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane" id="tab2">
												   <div class="col-lg-12">
													  <div class="image">
														 <div class="row">
															<p>Bild</p>
															<div>
															   <div class="col-sm-6"> 
																  <span></span><input type="file" multiple name="photo" class="form-control"/>
															   </div>
															   <div class="col-sm-6 text-center"> 
																  <br>
																  <img src="images/im.png" width="55%">
															   </div>
																<?php echo form_error('photo') ?>
															</div>
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane" id="tab3">
												   <div class="col-lg-12">
													  <div class="image">
														 <div class="row">
															<p>Notiz</p>
															<div>
															   <div class="col-lg-8">
																  <textarea class="form-control" name="note" value="<?php echo $note; ?>" rows="5"><?php echo $note; ?></textarea>
																  <?php echo form_error('note') ?>
																  <br>
															   </div>
															  
															</div>
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane" id="tab4">
												   <div class="col-lg-12">
													  <div class="private">
														 <p>Privat</p>
														 <div class="form-horizontal">
															<div class="form-group">
															   <label class="control-label col-sm-2" for="address">Strasse und Hausnr*
															   :</label>
															   <div class="col-sm-6">
																  <input type="text" class="form-control" id="address" name="address" value="<?php echo $address; ?>">
																  <?php echo form_error('address') ?>
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="postalcode">PLZ und Ort:</label>
															   <div class="col-sm-2"> 
																  <input type="text" class="form-control" id="postalcode" name="postalcode"  value="<?php echo $postalcode; ?>">
																  <?php echo form_error('postalcode') ?>
															   </div>
															   <div class="col-sm-4"> 
																  <input type="text" class="form-control" id="city" name="city" value="<?php echo $city; ?>">
																  <?php echo form_error('city') ?>
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="country_id">Land:</label>
															   <div class="col-sm-6">
																  <select name="country_id" class="form-control">
																  	<?php 
																		foreach($country as $dd){
																			$selected =($dd->id==$country_id) ? 'selected="selected"':' ' ;
																			echo "<option ". $selected. " value='". $dd->id ."'>". $dd->name ."</option>";
																		}
																	?>
																  </select>
																  <?php echo form_error('country_id') ?>
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="state">Bundesland: </label>
															   <div class="col-sm-6"> 
																  <input type="text" class="form-control" id="state" name="state" value="<?php echo $state; ?>">
																  <?php echo form_error('state') ?>
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="phone">Telefon:</label>
															   <div class="col-sm-6"> 
																  <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $phone; ?>">
																  <?php echo form_error('phone') ?>
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="mobile">Handy:</label>
															   <div class="col-sm-6"> 
																  <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $mobile; ?>">
																  <?php echo form_error('mobile') ?>
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="email">E-mail:</label>
															   <div class="col-sm-6"> 
																  <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
																  <?php echo form_error('email') ?>
															   </div>
															</div>
														
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane" id="tab5">
												   <div class="col-lg-12">
													  <div class="operation">
														 <p>Betrieblich</p>
														 <div class="form-horizontal">
															<div class="form-group">
															   <label class="control-label col-sm-2" for="op_address">Strasse und Hausnr
															   </label>
															   <div class="col-sm-6">
																  <input type="text" class="form-control" id="op_address" name="op_address" value="<?php echo $op_address; ?>">
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="op_postalcode">PLZ und Ort
															   :</label>
															   <div class="col-sm-2"> 
																  <input type="text" class="form-control" id="op_postalcode" name="op_postalcode" value="<?php echo $op_postalcode; ?>">
															   </div>
															   <div class="col-sm-4"> 
																  <input type="text" class="form-control" id="op_city" name="op_city" value="<?php echo $op_city; ?>">
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="op_country_id">Land
															   Land wählen
															   :</label>
															   <div class="col-sm-6" >
																  <select class="form-control" name="op_country_id">
																  	<?php 
																		foreach($country as $dd){
																			$selected =($dd->id==$op_country_id) ? 'selected="selected"':' ' ;
																			echo "<option ". $selected. " value='". $dd->id ."'>". $dd->name ."</option>";
																		}
																	?>
																  </select>
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="op_state">Bundesland: </label>
															   <div class="col-sm-6"> 
																  <input type="text" class="form-control" id="op_state"  name="op_state" value="<?php echo $op_state; ?>">
															   </div>
															</div>
															<div class="checkbox hide">
															   <label><input type="checkbox">von Organisation übernehmen</label>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="op_phone">Telefon:</label>
															   <div class="col-sm-6"> 
																  <input type="text" class="form-control" id="op_phone" name="op_phone" value="<?php echo $op_phone; ?>">
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="op_mobile">Handy:</label>
															   <div class="col-sm-6"> 
																  <input type="text" class="form-control" id="op_mobile" name="op_mobile" value="<?php echo $op_mobile; ?>">
															   </div>
															</div>
															<div class="form-group">
															   <label class="control-label col-sm-2" for="op_email">E-mail:</label>
															   <div class="col-sm-6"> 
																  <input type="email" class="form-control" id="op_email" name="op_email" value="<?php echo $op_email; ?>">
															   </div>
															</div>
															<div class="checkbox hide">
															   <label><input type="checkbox">von Organisation übernehmen
															   </label>
															</div>
														  
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane  hide" id="tab6">
												   <div class="col-lg-12">
													  <div class="image">
														 <div class="row">
															<p>Klassen</p>
															<div>
															   <div class="col-lg-3">
																  <div class="class">
																	 <h4>B</h4>
																	 <span>PKM</span>
																  </div>
																  <br>
																  <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#myModal">Klassenauswahl
																  </button>
																  <!-- Modal -->
																  <div class="modal fade" id="myModal" role="dialog">
																	 <div class="modal-dialog modal-lg">
																		<div class="modal-content">
																		   <div class="modal-header">
																			  <button type="button" class="close" data-dismiss="modal">&times;</button>
																			  <h4 class="modal-title">Klassenauswahl
																			  </h4>
																		   </div>
																		   <div class="modal-body">
																			  <p>This is a large modal.</p>
																		   </div>
																		   <div class="modal-footer">
																			  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
																		   </div>
																		</div>
																	 </div>
																  </div>
															   </div>
															   
															</div>
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane  hide" id="tab7">
												   <div class="col-lg-12">
													  <div class="image">
														 <div class="row">
															<p>Fahrzeuge ( * = Auswahl )</p>
															<div>
															   <div class="form-group">
																  <div class="col-lg-8">
																	 <input type="text" class="form-control" id="Fahrzeuge" placeholder="Enter Fahrzeuge">
																	 <br>
																  </div>
															   </div>
															   
															</div>
														 </div>
													  </div>
												   </div>
												</div>
												<div role="tabpanel" class="tab-pane  hide" id="tab8">
												   <div class="col-lg-12">
													  <div class="image">
														 <p>Filialen</p>
														 <div class="row">
															<div>
															   <div class="form-group">
																  <div class="col-lg-8">
																	 <div class="checkbox">
																		<label><input type="checkbox">Fahrschule Mentor George Sood</label>
																	 </div>
																  </div>
															   </div>
															   
															</div>
														 </div>
													  </div>
												   </div>
												</div>
											 </div>
										  </div>
										  <div class="col-sm-3">
											 <ul class="nav nav-pills brand-pills nav-stacked nav_create" role="tablist">
												<li role="presentation" class="brand-nav active"><a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab">Allgemein</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Bild</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">Notiz</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab4" aria-controls="tab4" role="tab" data-toggle="tab">Privat</a></li>
												<li role="presentation" class="brand-nav"><a href="#tab5" aria-controls="tab5" role="tab" data-toggle="tab">Betrieblich</a></li>
												<li role="presentation" class="brand-nav hide"><a href="#tab6" aria-controls="tab6" role="tab" data-toggle="tab">Klassen</a></li>
												<li role="presentation" class="brand-nav hide"><a href="#tab7" aria-controls="tab7" role="tab" data-toggle="tab">Fahrzeuge ( * = Auswahl )</a></li>
												<li role="presentation" class="brand-nav hide"><a href="#tab8" aria-controls="tab8" role="tab" data-toggle="tab">Filialen</a></li>
											 </ul>
										  </div>
									   </div>
									</div>
								</div>
							</div>
						</div>
						<div id="menu1" class="tab-pane fade">
							<div class="row">
								<div class="col-lg-6">
									<div class="account">
										<div class="form-horizontal">
											<div class="form-group">
												<label class="control-label col-sm-3" for="primary_email">E-Mailadresse*: </label>
												<div class="col-sm-6"> 
												   <input type="email" class="form-control" id="primary_email" name="primary_email" placeholder="Enter email addres" value="<?php echo $primary_email; ?>">
												    <?php echo form_error('primary_email') ?>
												</div>
												<div class="col-sm-10 hide">
												   <div class="checkbox">
													  <label><input type="checkbox">E-Mailadresse automatisch generieren</label>
												   </div>
												</div>
											 </div>
											<div class="form-group">
												<label class="control-label col-sm-3" for="username">Username*:</label>
												<div class="col-sm-6"> 
													<?php echo $username; ?>
												   	<input type="hidden" class="form-control" id="username" name="username"  value="<?php echo $username; ?>" readonly>
												</div>
												<div class="col-sm-10 text-center  hide">
												   <div class="checkbox">
													  <label><input type="checkbox">Nickname automatisch generieren</label>
												   </div>
												</div>
											</div>
											<div class="form-group">
												<label class="control-label col-sm-3" for="password">Password*:</label>
												<div class="col-sm-6"> 
													<?php echo $password; ?>
												   	<input type="hidden" class="form-control" id="password" name="password"  value="<?php echo $password; ?>" readonly>
												</div>
												<div class="col-sm-10 text-center  hide">
												   <div class="checkbox">
													  <label><input type="checkbox">Nickname automatisch generieren</label>
												   </div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div id="menu2" class="tab-pane fade">
							<div class="row">
								<div class="col-lg-6">
								   <div class="roll">
									  <div class="form-horizontal">
										 <div class="form-group">
											<label class="control-label col-sm-2" for="role_id">Rollentyp: </label>
											<div class="col-sm-10">
											   <select class="form-control" name="role_id" id="role_id">
												   <?php 
														foreach($roles as $dd){
															$selected =($dd->id==$role_id) ? 'selected="selected"':' ' ;
															echo "<option ". $selected. " value='". $dd->id ."'>". $dd->role_name ."</option>";
														}
													?>
											   </select>
											</div>
										 </div>
										 <div class="form-group hide">
											<label class="control-label col-sm-6" for="pwd">Mobile Client </label>
											<div class="col-sm-4">
											   <div class="checkbox">
												  <label><input type="checkbox"></label>
											   </div>
											</div>
										 </div>
										 <div class="form-group hide">
											<label class="control-label col-sm-6" for="pwd">OP's auf Mobile Client anzeigen </label>
											<div class="col-sm-4">
											   <div class="checkbox">
												  <label><input type="checkbox"></label>
											   </div>
											</div>
										 </div>
										 <div class="form-group hide">
											<label class="control-label col-sm-6" for="pwd">In der FL-Übersicht anzeigen</label>
											<div class="col-sm-4">
											   <div class="checkbox">
												  <label><input type="checkbox"></label>
											   </div>
											</div>
										 </div>
									  </div>
								   </div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	</form>
	
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('#dob').datepicker({dateFormat: 'yyyy-mm-dd'});
	});

</script>