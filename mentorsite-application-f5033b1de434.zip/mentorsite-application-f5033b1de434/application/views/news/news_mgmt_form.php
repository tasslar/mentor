<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">News_mgmt <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="char">News Title <?php echo form_error('news_title') ?></label>
            <input type="text" class="form-control" name="news_title" id="news_title" placeholder="News Title" value="<?php echo $news_title; ?>" />
        </div>
	    <div class="form-group">
            <label for="news_content">News Content <?php echo form_error('news_content') ?></label>
            <textarea class="form-control" rows="3" name="news_content" id="news_content" placeholder="News Content"><?php echo $news_content; ?></textarea>
        </div>
	    <div class="form-group">
            <label for="date">Created On <?php echo form_error('created_on') ?></label>
            <input type="text" class="form-control" name="created_on" id="created_on" placeholder="Created On" value="<?php echo $created_on; ?>" />
        </div>
	    <div class="form-group">
            <label for="enum">Status <?php echo form_error('status') ?></label>
            <input type="text" class="form-control" name="status" id="status" placeholder="Status" value="<?php echo $status; ?>" />
        </div>
	    <input type="hidden" name="id" value="<?php echo $id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('news') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>